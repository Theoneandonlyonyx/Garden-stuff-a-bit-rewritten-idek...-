"""Makes pot_shapes.json: the collision shape of the china pot and the amphora, cut from their own models so the
hitbox follows the vase (nothing walkable behind a narrow neck). Run from the project root: python3 tools/gen_pot_shapes.py"""
import json, os
A = "src/main/resources/assets/mikexxx_flowerbeds/"
M = A + "models/block/"
SETS = {"china": "china_large_pot", "amphora": "quartz_amphora_pot"}
BITS = (("north", 1), ("east", 2), ("south", 4), ("west", 8), ("northeast", 16), ("southeast", 32), ("southwest", 64), ("northwest", 128))
ROUND = ["nw", "n", "ne", "w", "c", "e", "sw", "s", "se"]

_cache = {}
def voxels(model):
    """16x16x16 solid cells: a cell is solid when the model fills at least a quarter of it."""
    if model in _cache: return _cache[model]
    import math
    import numpy as np
    sub = np.zeros((32, 32, 32), dtype=bool)  # [y][z][x] in half pixels
    for e in json.load(open(M + model + ".json"))["elements"]:
        f, t = e["from"], e["to"]
        lo = [max(0, math.ceil(2 * f[i] - 0.5)) for i in range(3)]
        hi = [min(32, math.ceil(2 * t[i] - 0.5)) for i in range(3)]
        if all(hi[i] > lo[i] for i in range(3)):
            sub[lo[1]:hi[1], lo[2]:hi[2], lo[0]:hi[0]] = True
    cnt = sub.reshape(16, 2, 16, 2, 16, 2).sum(axis=(1, 3, 5))
    _cache[model] = (cnt >= 2).tolist()
    return _cache[model]

def boxes(v):
    """Greedy merge: rectangles per layer, then stacked while identical."""
    layers = []
    for y in range(16):
        used = [[False] * 16 for _ in range(16)]; rects = []
        for z in range(16):
            for x in range(16):
                if v[y][z][x] and not used[z][x]:
                    x1 = x
                    while x1 + 1 < 16 and v[y][z][x1 + 1] and not used[z][x1 + 1]: x1 += 1
                    z1 = z
                    while z1 + 1 < 16 and all(v[y][z1 + 1][i] and not used[z1 + 1][i] for i in range(x, x1 + 1)): z1 += 1
                    for zz in range(z, z1 + 1):
                        for xx in range(x, x1 + 1): used[zz][xx] = True
                    rects.append((x, z, x1 + 1, z1 + 1))
        layers.append(rects)
    out = []; open_ = {}
    for y in range(17):
        cur = set(layers[y]) if y < 16 else set()
        for r in list(open_):
            if r not in cur: out.append([r[0], open_[r], r[1], r[2], y, r[3]]); del open_[r]
        for r in cur:
            if r not in open_: open_[r] = y
    return out

result = {}
for key, state in SETS.items():
    bs = json.load(open(A + "blockstates/%s.json" % state))["multipart"]
    def resolve(props):
        for p in bs:
            if all(props.get(k) in str(v).split("|") for k, v in p["when"].items()):
                return p["apply"]["model"].split("/")[-1]
    table = {}
    for mask in range(256):
        props = {k: str(bool(mask & b)).lower() for k, b in BITS}; props["round3"] = "none"
        m = resolve(props)
        if m: table["m:%d" % mask] = boxes(voxels(m))
    for r in ROUND:
        props = {k: "true" for k, _ in BITS}; props["round3"] = r
        m = resolve(props)
        if m and ("round3" in str(bs) and r != "none"): table["r:" + r] = boxes(voxels(m))
    result[key] = table
    print(key, len(table), "shapes, boxes in m:0 =", len(table.get("m:0", [])), "total", sum(len(v) for v in table.values()))
json.dump(result, open(A + "pot_shapes.json", "w"), separators=(",", ":"))
print(os.path.getsize(A + "pot_shapes.json"), "bytes")
