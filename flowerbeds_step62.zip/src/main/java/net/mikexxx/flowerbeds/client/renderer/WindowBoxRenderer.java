package net.mikexxx.flowerbeds.client.renderer;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.WindowBoxBlock;
import net.mikexxx.flowerbeds.block.entity.WindowBoxBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.RenderTypeHelper;
import net.minecraftforge.client.model.data.ModelData;

import java.lang.reflect.Field;
import java.util.List;

/**
 * Draws the five places of a window box. Slots 0-2 are the classic three, evenly spaced; slots 3 and 4 sit in the
 * gaps beside the middle one, a little smaller and nudged forward and back so the box looks full without the
 * plants lying on top of each other. Vines are not drawn as blocks: they hang down over both long sides in a
 * tapering, roughly triangular drape.
 */
public class WindowBoxRenderer implements BlockEntityRenderer<WindowBoxBlockEntity> {

    /** Position along the box (0..1) of each slot. */
    private static final float[] ALONG = {0.20F, 0.50F, 0.80F, 0.35F, 0.65F};
    /** Plant scale per slot. The classic three keep the original size; the gap plants are a tad smaller. */
    private static final float[] SCALE = {0.50F, 0.50F, 0.50F, 0.45F, 0.45F};
    /** Sideways nudge per slot, toward the back of the box (+, against the wall) or the front (-). */
    private static final float[] NUDGE = {0.0F, 0.0F, 0.0F, 0.075F, 0.075F};
    /** A little turn per slot so neighbouring plants do not look stamped from one mould. */
    private static final float[] YAW = {0.0F, 12.0F, -9.0F, 24.0F, -20.0F};
    private static final ResourceLocation VINE = new ResourceLocation("mikexxx_flowerbeds", "block/window_vine");
    private static final ResourceLocation WATER_SPRITE = new ResourceLocation("minecraft", "block/water_still");
    private static final ResourceLocation LAVA_SPRITE = new ResourceLocation("minecraft", "block/lava_still");

    @Override
    public int getViewDistance() {
        return 32;
    }

    public WindowBoxRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(WindowBoxBlockEntity box, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffers, int packedLight, int packedOverlay) {
        Level level = box.getLevel();
        BlockState hostState = box.getBlockState();
        if (level == null || !(hostState.getBlock() instanceof WindowBoxBlock)) {
            return;
        }
        BlockPos pos = box.getBlockPos();
        Direction facing = hostState.getValue(WindowBoxBlock.FACING);
        boolean alongX = facing.getAxis() == Direction.Axis.Z;
        boolean outwardIsPositive = facing == Direction.SOUTH || facing == Direction.EAST;
        float across = outwardIsPositive ? 0.81F : 0.19F;
        float baseY = box.bedHeight();
        int light = LevelRenderer.getLightColor(level, pos.above());

        BlockState substrate = box.substrateState();
        if (substrate != null) {
            float a0 = outwardIsPositive ? 11.0F / 16.0F : 1.0F / 16.0F;
            float a1 = a0 + 4.0F / 16.0F;
            float x0 = alongX ? 1.0F / 16.0F : a0;
            float x1 = alongX ? 15.0F / 16.0F : a1;
            float z0 = alongX ? a0 : 1.0F / 16.0F;
            float z1 = alongX ? a1 : 15.0F / 16.0F;
            renderSubstrate(substrate, level, pos, poseStack, buffers, x0, z0, x1, z1, 5.0F / 16.0F + 0.002F,
                    light, packedOverlay);
        }

        if (box.getLiquid() != LargePotBlock.Liquid.NONE) {
            float a0 = outwardIsPositive ? 11.0F / 16.0F : 1.0F / 16.0F;
            float a1 = a0 + 4.0F / 16.0F;
            renderLiquid(box.getLiquid(), level, pos, poseStack, buffers,
                    alongX ? 1.0F / 16.0F : a0, alongX ? a0 : 1.0F / 16.0F,
                    alongX ? 15.0F / 16.0F : a1, alongX ? a1 : 15.0F / 16.0F, light, packedOverlay);
        }

        int vines = 0;
        int vineAge = 0;
        for (int i = 0; i < WindowBoxBlockEntity.SLOTS; i++) {
            ItemStack stack = box.getSlot(i);
            if (stack.isEmpty()) {
                continue;
            }
            BlockState plant = PlantStates.stateFor(stack, box.getAge(i));
            if (WindowBoxBlock.isTrailing(plant)) {
                vines++;
                vineAge = Math.max(vineAge, box.getAge(i));
                continue;
            }
            List<BlockState> column = box.getColumn(i);
            float nudge = outwardIsPositive ? NUDGE[i] : -NUDGE[i];
            float cx = alongX ? ALONG[i] : across + nudge;
            float cz = alongX ? across + nudge : ALONG[i];
            boolean fruit = GardenLayout.isScaled(stack);
            float scale = fruit ? GardenLayout.WINDOW_FRUIT_SCALE : SCALE[i];
            for (int k = 0; k < column.size(); k++) {
                poseStack.pushPose();
                poseStack.translate(cx, baseY, cz);
                BlockState drawn = column.get(k);
                if (fruit) {
                    drawn = PlantStates.orient(drawn, box.getRotation(i));
                }
                if (!(fruit && PlantStates.hasFront(drawn))) {
                    poseStack.mulPose(Axis.YP.rotationDegrees(fruit ? box.getRotation(i) * 90.0F : YAW[i]));
                }
                poseStack.scale(scale, scale, scale);
                poseStack.translate(-0.5, k, -0.5);
                renderState(drawn, level, pos, poseStack, buffers, light, packedOverlay);
                poseStack.popPose();
            }
        }
        if (vines > 0) {
            renderTrail(vines, vineAge, level, pos, poseStack, buffers, alongX, light, packedOverlay);
        }
    }


    /** How far the drape starts inside the box, measured from the long side it hangs over. */
    private static final float DRAPE_REACH = 3.0F / 16.0F;
    /** Rim height of the box. */
    private static final float RIM = 6.0F / 16.0F;

    /**
     * One vine drape per long side of the box, like trailing plants on a real window box. Each drape is a single
     * continuous strip that starts inside the box above the soil, runs flat over the rim, bends over the edge
     * and hangs down the outside of the box, so it really goes over the edge instead of being pasted on the
     * outside face. It starts as wide as the box and tapers to a point. More vines in the box make it longer and
     * add shorter, narrower layers on top of it for a fuller look, and every bone meal makes it hang longer.
     * The side against a wall gets no drape when that wall is solid, so nothing pokes into it. The strip is cut
     * into one-pixel rows, so the vine texture is laid down without stretching along the whole way.
     */
    private void renderTrail(int vines, int age, Level level, BlockPos pos, PoseStack poseStack,
                             MultiBufferSource buffers, boolean alongX, int light, int overlay) {
        TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(VINE);
        int rgb = PlantTint.color(Blocks.VINE.defaultBlockState(), level, pos, 0);
        float r = (rgb >> 16 & 255) / 255.0F * 0.95F;
        float g = (rgb >> 8 & 255) / 255.0F * 0.95F;
        float b = (rgb & 255) / 255.0F * 0.95F;
        VertexConsumer consumer = buffers.getBuffer(RenderType.cutout());
        PoseStack.Pose pose = poseStack.last();
        BlockState host = level.getBlockState(pos);
        Direction facing = host.getValue(WindowBoxBlock.FACING);
        boolean outwardIsPositive = facing == Direction.SOUTH || facing == Direction.EAST;

        // Box walls along the depth axis: the side away from the wall is the front, the one against it the back.
        float boxLo = outwardIsPositive ? 10.0F / 16.0F : 0.0F;
        float boxHi = boxLo + 6.0F / 16.0F;
        float frontFace = outwardIsPositive ? boxLo : boxHi;
        float frontIn = outwardIsPositive ? 1.0F : -1.0F;
        float backFace = outwardIsPositive ? boxHi : boxLo;
        BlockPos wall = pos.relative(facing);
        boolean wallSolid = level.getBlockState(wall).isFaceSturdy(level, wall, facing.getOpposite());

        float baseLength = (0.7F + 0.12F * (vines - 1)) * (0.6F + 0.4F * age / WindowBoxBlockEntity.MAX_TRAIL_AGE);
        int layers = Math.min(3, vines);
        for (int layer = 0; layer < layers; layer++) {
            float length = baseLength * (1.0F - 0.2F * layer);
            float halfTop = 0.46F - 0.06F * layer;
            // Each layer sits a hair further out than the one below it, so layers never fight for the same spot.
            float lift = 0.010F + layer * 0.006F;
            drape(consumer, pose, sprite, r, g, b, overlay, light, alongX, frontFace, frontIn, length, halfTop, lift,
                    layer);
            if (!wallSolid) {
                drape(consumer, pose, sprite, r, g, b, overlay, light, alongX, backFace, -frontIn, length, halfTop,
                        lift, layer + 3);
            }
        }
    }

    /**
     * One drape over one long side. {@code face} is where that side's outer face sits on the depth axis and
     * {@code inward} the direction (+1 or -1) from that face into the box. The path is a list of one-pixel rows:
     * first {@link #DRAPE_REACH} across the rim toward the outside, then down the outer face.
     * <p>
     * The window-box vine texture is dense (only four tiny holes). Where the drape gets narrow, a row can land entirely on a
     * hole and the vine seems to break off, leaving a bare gap and a lonely tip. So every row looks up which
     * texels of the texture are opaque and reads from the nearest ones (first sliding sideways, then to a
     * neighbouring row). Shape, width and texture stay the same; only the gap is closed.
     */
    private void drape(VertexConsumer consumer, PoseStack.Pose pose, TextureAtlasSprite sprite, float r, float g,
                       float b, int overlay, int light, boolean alongX, float face, float inward, float length,
                       float halfTop, float lift, int seed) {
        final float row = 1.0F / 16.0F;
        int flatRows = Math.round(DRAPE_REACH / row);
        int hangRows = Math.max(3, Math.round(length * 16.0F));
        int total = flatRows + hangRows;
        float yFlat = RIM + lift;
        float sOut = -lift;
        int[] mask = rowMask(sprite);
        for (int i = 0; i < total; i++) {
            // Tapers to a point; a slight wobble keeps the edge from looking ruled with a straight edge.
            float taper = 1.0F - (i + 0.5F) / total;
            float wobble = 1.0F + 0.08F * (float) Math.sin(i * 1.7F + seed * 2.0F);
            // Never thinner than two texels, so the tip stays a clear strand instead of breaking into single dots.
            float halfWidth = Math.max(1.0F * row, halfTop * taper * wobble);
            float a0 = 0.5F - halfWidth;
            float a1 = 0.5F + halfWidth;
            int c0 = Math.max(0, (int) Math.floor(a0 * 16.0F));
            int c1 = Math.min(16, (int) Math.ceil(a1 * 16.0F));
            if (c1 <= c0) {
                c1 = Math.min(16, c0 + 1);
            }
            int[] pick = pickTexels(mask, i % 16, c0, c1);
            float u0 = sprite.getU(pick[1]);
            float u1 = sprite.getU(pick[2]);
            float v0 = sprite.getV(pick[0]);
            float v1 = sprite.getV(pick[0] + 1.0F);
            if (i < flatRows) {
                // Flat over the rim: depth s runs from DRAPE_REACH inside the box out to the face; the last
                // flat row is stretched a hair past the face so it meets the hanging part with no crack.
                float sA = DRAPE_REACH - i * row;
                float sB = i == flatRows - 1 ? sOut : sA - row;
                quad(consumer, pose, r, g, b, u0, u1, v0, v1, overlay, light, alongX, face, inward,
                        a0, a1, sA, yFlat, sB, yFlat, 0.0F, 1.0F);
            } else {
                float yA = yFlat - (i - flatRows) * row;
                float yB = yA - row;
                quad(consumer, pose, r, g, b, u0, u1, v0, v1, overlay, light, alongX, face, inward,
                        a0, a1, sOut, yA, sOut, yB, -inward, 0.0F);
            }
        }
    }

    private static TextureAtlasSprite maskSprite;
    private static int[] rowMask;

    /** For each of the 16 texture rows, a bit mask of the opaque texels (null if the texture cannot be read). */
    private static int[] rowMask(TextureAtlasSprite sprite) {
        if (sprite != maskSprite) {
            maskSprite = sprite;
            rowMask = readMask(sprite);
        }
        return rowMask;
    }

    private static int[] readMask(TextureAtlasSprite sprite) {
        try {
            Object contents = sprite.contents();
            NativeImage image = null;
            Class<?> type = contents.getClass();
            while (type != null && image == null) {
                for (Field field : type.getDeclaredFields()) {
                    field.setAccessible(true);
                    Object value = field.get(contents);
                    if (value instanceof NativeImage nativeImage) {
                        image = nativeImage;
                        break;
                    }
                    if (value instanceof NativeImage[] images && images.length > 0 && images[0] != null) {
                        image = images[0];
                        break;
                    }
                }
                type = type.getSuperclass();
            }
            if (image == null) {
                return null;
            }
            int w = image.getWidth();
            int h = image.getHeight();
            int[] mask = new int[16];
            for (int y = 0; y < 16; y++) {
                for (int x = 0; x < 16; x++) {
                    int pixel = image.getPixelRGBA(x * w / 16, y * h / 16);
                    if (((pixel >>> 24) & 255) > 32) {
                        mask[y] |= 1 << x;
                    }
                }
            }
            return mask;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static boolean hits(int rowBits, int c0, int c1) {
        return (rowBits & (((1 << (c1 - c0)) - 1) << c0)) != 0;
    }

    /**
     * Picks the texture row and the texel window {row, c0, c1} to draw one strip row from: the wanted one if it
     * has an opaque texel, otherwise the same row slid a little sideways, otherwise a neighbouring row.
     */
    private static int[] pickTexels(int[] mask, int vTop, int c0, int c1) {
        if (mask == null || hits(mask[vTop], c0, c1)) {
            return new int[] {vTop, c0, c1};
        }
        int width = c1 - c0;
        for (int shift = 1; shift <= 5; shift++) {
            for (int dir = -1; dir <= 1; dir += 2) {
                int n0 = c0 + dir * shift;
                int n1 = n0 + width;
                if (n0 >= 0 && n1 <= 16 && hits(mask[vTop], n0, n1)) {
                    return new int[] {vTop, n0, n1};
                }
            }
        }
        for (int d = 1; d <= 4; d++) {
            for (int dir = -1; dir <= 1; dir += 2) {
                int rr = ((vTop + dir * d) % 16 + 16) % 16;
                if (hits(mask[rr], c0, c1)) {
                    return new int[] {rr, c0, c1};
                }
                for (int shift = 1; shift <= 5; shift++) {
                    for (int sd = -1; sd <= 1; sd += 2) {
                        int n0 = c0 + sd * shift;
                        int n1 = n0 + width;
                        if (n0 >= 0 && n1 <= 16 && hits(mask[rr], n0, n1)) {
                            return new int[] {rr, n0, n1};
                        }
                    }
                }
            }
        }
        return new int[] {vTop, c0, c1};
    }

    /**
     * Emits one strip row, both sides. The row spans a0..a1 along the box; its near edge is at depth sA, height
     * yA and its far edge at depth sB, height yB. Depth is measured from the face into the box. The normal is
     * given as its depth-axis part and its vertical part; it is only used for lighting.
     */
    private static void quad(VertexConsumer consumer, PoseStack.Pose pose, float r, float g, float b,
                             float u0, float u1, float v0, float v1, int overlay, int light, boolean alongX,
                             float face, float inward, float a0, float a1, float sA, float yA, float sB, float yB,
                             float normalDepth, float normalUp) {
        // Corner order: near-left, far-left, far-right, near-right; the back side runs the same corners reversed.
        float[] as = {a0, a0, a1, a1};
        float[] ss = {sA, sB, sB, sA};
        float[] ys = {yA, yB, yB, yA};
        float[] us = {u0, u0, u1, u1};
        float[] vs = {v0, v1, v1, v0};
        for (int side = 0; side < 2; side++) {
            float sign = side == 0 ? 1.0F : -1.0F;
            for (int k = 0; k < 4; k++) {
                int c = side == 0 ? k : 3 - k;
                float depth = face + inward * ss[c];
                float x = alongX ? as[c] : depth;
                float z = alongX ? depth : as[c];
                float nx = alongX ? 0.0F : normalDepth * sign;
                float nz = alongX ? normalDepth * sign : 0.0F;
                consumer.vertex(pose.pose(), x, ys[c], z).color(r, g, b, 1.0F).uv(us[c], vs[c])
                        .overlayCoords(overlay).uv2(light)
                        .normal(pose.normal(), nx, normalUp * sign, nz).endVertex();
            }
        }
    }


    /** Biome-tinted block drawing, same as the other beds. */
    private void renderState(BlockState state, Level level, BlockPos tintPos, PoseStack poseStack,
                             MultiBufferSource buffers, int light, int overlay) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        if (state.getRenderShape() != RenderShape.MODEL) {
            dispatcher.renderSingleBlock(state, poseStack, buffers, light, overlay);
            return;
        }
        BakedModel model = dispatcher.getBlockModel(state);
        int rgb = PlantTint.color(state, level, tintPos, 0);
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        for (RenderType renderType : model.getRenderTypes(state, RandomSource.create(42L), ModelData.EMPTY)) {
            dispatcher.getModelRenderer().renderModel(poseStack.last(),
                    buffers.getBuffer(renderType),
                    state, model, r, g, b, light, overlay, ModelData.EMPTY, renderType);
        }
    }

    /** Water (biome tinted), milk (untinted water texture) or lava, as a flat surface a little below the rim of the soil level. */
    private void renderLiquid(LargePotBlock.Liquid liquid, Level level, BlockPos pos, PoseStack poseStack,
                              MultiBufferSource buffers, float x0, float z0, float x1, float z1,
                              int light, int overlay) {
        boolean lava = liquid == LargePotBlock.Liquid.LAVA;
        TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS)
                .apply(lava ? LAVA_SPRITE : WATER_SPRITE);
        int rgb = liquid == LargePotBlock.Liquid.WATER
                ? PlantTint.color(Blocks.WATER.defaultBlockState(), level, pos, 0) : 0xFFFFFF;
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        float alpha = lava ? 1.0F : 0.85F;
        int lit = lava ? LightTexture.FULL_BRIGHT : light;
        VertexConsumer consumer = buffers.getBuffer(RenderType.translucent());
        PoseStack.Pose pose = poseStack.last();
        float y = 4.5F / 16.0F;
        float u0 = sprite.getU(x0 * 16.0F);
        float u1 = sprite.getU(x1 * 16.0F);
        float v0 = sprite.getV(z0 * 16.0F);
        float v1 = sprite.getV(z1 * 16.0F);
        liquidVertex(consumer, pose, x0, y, z0, r, g, b, alpha, u0, v0, overlay, lit);
        liquidVertex(consumer, pose, x0, y, z1, r, g, b, alpha, u0, v1, overlay, lit);
        liquidVertex(consumer, pose, x1, y, z1, r, g, b, alpha, u1, v1, overlay, lit);
        liquidVertex(consumer, pose, x1, y, z0, r, g, b, alpha, u1, v0, overlay, lit);
    }

    private static void liquidVertex(VertexConsumer consumer, PoseStack.Pose pose, float x, float y, float z,
                                     float r, float g, float b, float a, float u, float v, int overlay, int light) {
        consumer.vertex(pose.pose(), x, y, z).color(r, g, b, a).uv(u, v).overlayCoords(overlay)
                .uv2(light).normal(pose.normal(), 0.0F, 1.0F, 0.0F).endVertex();
    }

    /** The top face of the custom substrate, laid over the box's own soil. */
    private void renderSubstrate(BlockState substrate, Level level, BlockPos pos, PoseStack poseStack,
                                 MultiBufferSource buffers, float x0, float z0, float x1, float z1, float y,
                                 int light, int overlay) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        BakedModel model = dispatcher.getBlockModel(substrate);
        List<BakedQuad> quads = model.getQuads(substrate, Direction.UP, RandomSource.create(42L), ModelData.EMPTY, null);
        TextureAtlasSprite sprite;
        int tint = -1;
        if (quads.isEmpty()) {
            sprite = model.getParticleIcon(ModelData.EMPTY);
        } else {
            sprite = quads.get(0).getSprite();
            tint = quads.get(0).getTintIndex();
        }
        int rgb = PlantTint.color(substrate, level, pos, tint);
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        VertexConsumer consumer = buffers.getBuffer(RenderType.cutout());
        PoseStack.Pose pose = poseStack.last();
        float u0 = sprite.getU(x0 * 16.0F);
        float u1 = sprite.getU(x1 * 16.0F);
        float v0 = sprite.getV(z0 * 16.0F);
        float v1 = sprite.getV(z1 * 16.0F);
        vertex(consumer, pose, x0, y, z0, r, g, b, u0, v0, overlay, light, 0.0F, 0.0F, 1.0F);
        vertex(consumer, pose, x0, y, z1, r, g, b, u0, v1, overlay, light, 0.0F, 0.0F, 1.0F);
        vertex(consumer, pose, x1, y, z1, r, g, b, u1, v1, overlay, light, 0.0F, 0.0F, 1.0F);
        vertex(consumer, pose, x1, y, z0, r, g, b, u1, v0, overlay, light, 0.0F, 0.0F, 1.0F);
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, float x, float y, float z,
                               float r, float g, float b, float u, float v, int overlay, int light,
                               float nx, float ny, float nz) {
        consumer.vertex(pose.pose(), x, y, z).color(r, g, b, 1.0F).uv(u, v).overlayCoords(overlay)
                .uv2(light).normal(pose.normal(), nx, ny, nz).endVertex();
    }
}
