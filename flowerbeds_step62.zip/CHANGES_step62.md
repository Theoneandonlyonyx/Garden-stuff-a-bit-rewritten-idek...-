# Step 62 (on step 61)
- Bathbombs are now true circles: 12x12 pixels exactly in the middle of the 16x16 icon (columns and rows 2..13), so they sit centred in the item slot. Your artwork's pixels and colours are stretched onto the circle; yellow bit gone; two sparkles opposite each other (upper left, lower right) touch the bomb, so the icon stays balanced.
- Earlier steps kept: china pot / amphora hitboxes (tools/gen_pot_shapes.py), viola odorata designs (designs/viola_odorata/, not in the game yet).
