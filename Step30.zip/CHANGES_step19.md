# Step 19 (on step 18)
- Fish, salmon, pufferfish, tropical fish, axolotls and tadpoles can live in a glass tank: right-click a glass pot that holds water with the mob bucket. You get the empty bucket back. Up to 6 swimmers per tank.
- They are the real entity models (tropical fish keep their pattern and colours, axolotls their colour), swimming loops inside the water, up through all the joined glass pots.
- An empty bucket on a tank that has swimmers takes one back out (as the same mob bucket). With none left it takes the water as before.
- Swimmers drop as buckets when the bottom pot is broken. They are saved with the pot.
