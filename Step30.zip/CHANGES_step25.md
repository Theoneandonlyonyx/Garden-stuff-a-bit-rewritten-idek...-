# Step 25 (on step 24)
- A finished 4x4 square of birdbaths now turns into one round bowl, like the 3x3. 16 new cell models (`silver_birdbath_round4_<x><z>`), built as a stepped round bowl of 64 px across with the same rim, steps and floor as the 3x3. One shared foot stands under the middle (seam of the four middle blocks) with the fountain nozzle on top.
- Water follows the round inside of the bowl (new `q:xz` entries in birdbath_water.json).
- New group states `q_00` .. `q_33` (BathGroup). Hitbox: the bowl is the full block in every cell; only the middle holder block has the foot hitbox.
- Single-row and other group rules from step 24 are unchanged.
