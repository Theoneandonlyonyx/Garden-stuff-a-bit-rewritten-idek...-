# Step 23 (on step 22)
- Diagonal pots no longer connect. A corner flag is only kept when both sides beside it are connected (inner corner of a filled 2x2). Before, a pot with a diagonal neighbour in an L shape got a state without a model and vanished partly or fully. Pots placed diagonally (like a staircase) now stay separate, normal pots.
- Applies to china pot, quartz amphora and birdbath (all Large Pot blocks).
