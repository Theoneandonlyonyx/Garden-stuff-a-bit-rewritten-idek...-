# Step 29 (on step 28)
- Checked every model of the amphora, china pot and birdbath: all walls are closed, all 47 shapes and the 9 round cells exist for each, and every blockstate entry points at a real file.
- Made the three blockstates (quartz amphora, china pot, birdbath) cover all 256 possible neighbour combinations, not only the 47 shapes. Even a leftover or odd state (from old test worlds or a missed update) now shows its closest real shape instead of nothing.
- Redstone chain checked: power -> neighborChanged/onPlace/onRemove -> whole network -> POWERED -> fountain on the foot holder of the top bowl with water.
- Recipes checked: all 32 shaped recipes have even rows and known keys.
