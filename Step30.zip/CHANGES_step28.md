# Step 28 (on step 27) - final
- Aromatized water: it was already in and works in every Large Pot block, so the Quartz Large Pot has it too (pink water + pink petals; glint, bubble and petal particles). Nothing to switch on.
- Small fix: in the amphora and the china pot, the aroma particles are now spawned inside the curved water (from the pot_fill outline), not in the box that used to poke through the wall.
