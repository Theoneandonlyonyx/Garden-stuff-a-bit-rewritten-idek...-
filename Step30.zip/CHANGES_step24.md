# Step 24 (on step 23)
- Birdbaths in a single row (one wide, any length, joined or not as a double): every block keeps its own small normal foot. No shared big foot any more. Only groups at least two wide share a foot.
- Birdbath hitbox follows the real model: the bowl is always the full block, so filling is easy everywhere, and a pillar hitbox exists only on blocks that really have a foot, as wide as that foot (no floating pillar under round-bath corners or foot-less blocks). Stacked baths use the thin stacked foot.
