# Step 20 (on step 19)
- Glass tanks: every block of a tank now opens the plant menu (trowel), not just the bottom one. It arranges the plants of the tank's bottom pot, and stays open while you are near the block you clicked.
- Two-block plants in a water pot (small dripleaf, tall flowers, tall seagrass, modded tall plants) stand on the pot floor: the bottom part is in the water (waterlogged where the block has that state), the top part sticks out above it.
- Floating plants (lily pad, and modded lilies, lotus, duckweed) ride the water line in pots and tanks. Everything above the pad, such as a flower, is drawn with it.
- Water is now drawn last, so plants, fish and the floor layer show through it instead of hiding behind its faces.
- Water pots and tanks: right-click with any substrate (dirt, sand, gravel, clay, soul sand, coarse dirt, mud, concrete powder ...) to lay a thin, visible layer on the floor under the water. The water stays. Plants stand on the layer. The side of the layer is textured, and it joins neighbouring pots.
  - Sneak + empty hand lifts the layer out again. Emptying the water, or breaking the pot, gives it back.
  - Packs can add blocks with the item tag `bottom_layers`.
