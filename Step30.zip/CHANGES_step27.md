# Step 27 (on step 26)
- Birdbath redstone: one powered birdbath powers every birdbath it is connected to (side by side or stacked, up to 1024 blocks). All their fountains play together, and all stop when the last power is gone. Breaking a bath re-checks the pieces left over, so a split network does not stay on by mistake.
- The fountain itself was already in (spray from the foot of the group, only on the top bowl, only with water in it; a single-row bath fountains on every block, as each has its own foot).
