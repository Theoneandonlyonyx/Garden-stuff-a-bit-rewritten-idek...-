package net.mikexxx.flowerbeds.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** A drop of fountain water: shot up, falls in an arc and vanishes when it is back at the height it started. */
public class FountainParticle extends TextureSheetParticle {
    private final double startY;

    private FountainParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz,
                             SpriteSet sprites) {
        super(level, x, y, z, vx, vy, vz);
        this.startY = y;
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.hasPhysics = false;
        this.lifetime = 40;
        this.quadSize = 0.07F + random.nextFloat() * 0.05F;
        setColor(0.78F, 0.9F, 1.0F);
        setAlpha(0.85F);
        pickSprite(sprites);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime || (this.yd < 0 && this.y <= this.startY - 0.02)) {
            this.remove();
            return;
        }
        this.yd -= 0.04;
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.99;
        this.zd *= 0.99;
    }

    @Override
    protected int getLightColor(float partialTick) {
        int base = super.getLightColor(partialTick);
        return (base & 0xFFFF0000) | Math.max(base & 0xFFFF, 0xA0);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new FountainParticle(level, x, y, z, vx, vy, vz, sprites);
        }
    }
}
