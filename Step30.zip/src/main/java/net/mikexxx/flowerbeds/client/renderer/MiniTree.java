package net.mikexxx.flowerbeds.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.mikexxx.flowerbeds.garden.OrnamentalTrees;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Draws an Ornamental Trees tree small, as two crossed planes of its own texture, standing in a pot. */
final class MiniTree {

    private MiniTree() {
    }

    static void render(ItemStack stack, float x, float y, float z, PoseStack poseStack, MultiBufferSource buffers,
                       int light, int overlay) {
        String name = OrnamentalTrees.nameOf(stack);
        ResourceLocation texture = new ResourceLocation(OrnamentalTrees.MOD_ID, "textures/block/" + name + ".png");
        float width = OrnamentalTrees.widthOf(name) * OrnamentalTrees.POT_SCALE;
        float height = OrnamentalTrees.heightOf(name) * OrnamentalTrees.POT_SCALE;
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(texture));
        for (int plane = 0; plane < 2; plane++) {
            poseStack.pushPose();
            poseStack.translate(x, y, z);
            poseStack.mulPose(Axis.YP.rotationDegrees(45.0F + plane * 90.0F));
            PoseStack.Pose pose = poseStack.last();
            Matrix4f matrix = pose.pose();
            Matrix3f normal = pose.normal();
            float h = width / 2.0F;
            quad(consumer, matrix, normal, -h, 0.0F, h, height, light, overlay);
            poseStack.popPose();
        }
    }

    private static void quad(VertexConsumer c, Matrix4f m, Matrix3f n, float x0, float y0, float x1, float y1,
                             int light, int overlay) {
        vertex(c, m, n, x0, y0, 0.0F, 0.0F, 1.0F, light, overlay);
        vertex(c, m, n, x1, y0, 0.0F, 1.0F, 1.0F, light, overlay);
        vertex(c, m, n, x1, y1, 0.0F, 1.0F, 0.0F, light, overlay);
        vertex(c, m, n, x0, y1, 0.0F, 0.0F, 0.0F, light, overlay);
    }

    private static void vertex(VertexConsumer c, Matrix4f m, Matrix3f n, float x, float y, float z, float u, float v,
                               int light, int overlay) {
        c.vertex(m, x, y, z).color(255, 255, 255, 255).uv(u, v).overlayCoords(overlay).uv2(light)
                .normal(n, 0.0F, 1.0F, 0.0F).endVertex();
    }
}
