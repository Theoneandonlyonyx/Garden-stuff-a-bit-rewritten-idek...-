package net.mikexxx.flowerbeds.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

/** One particle class for the glint, the bubble and the petal of aromatized water. */
public class AromaParticle extends TextureSheetParticle {

    public enum Kind { GLINT, BUBBLE, PETAL }

    private final Kind kind;
    private final float baseSize;
    private final float phase;

    private AromaParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz,
                          SpriteSet sprites, Kind kind) {
        super(level, x, y, z, vx, vy, vz);
        this.kind = kind;
        this.xd = vx + (random.nextDouble() - 0.5) * 0.004;
        this.yd = vy;
        this.zd = vz + (random.nextDouble() - 0.5) * 0.004;
        this.phase = random.nextFloat() * 6.2831855F;
        this.hasPhysics = false;
        pickSprite(sprites);
        switch (kind) {
            case GLINT -> {
                // Rosy pinks, from soft pink to a deeper rose.
                setColor(1.0F, 0.42F + random.nextFloat() * 0.32F, 0.62F + random.nextFloat() * 0.26F);
                this.baseSize = 0.10F + random.nextFloat() * 0.07F;
                this.lifetime = 22 + random.nextInt(18);
                setAlpha(0.95F);
            }
            case BUBBLE -> {
                // Lighter, paler pink than the glint.
                setColor(1.0F, 0.80F + random.nextFloat() * 0.12F, 0.86F + random.nextFloat() * 0.10F);
                this.baseSize = 0.05F + random.nextFloat() * 0.09F;
                this.lifetime = 24 + random.nextInt(26);
                setAlpha(0.8F);
            }
            default -> {
                setColor(1.0F, 0.92F + random.nextFloat() * 0.08F, 0.95F);
                this.baseSize = 0.06F + random.nextFloat() * 0.16F;
                this.lifetime = 40 + random.nextInt(40);
                setAlpha(0.95F);
            }
        }
        this.quadSize = baseSize;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        if (kind == Kind.PETAL) {
            // A gentle sway while it drifts.
            this.xd += Mth.sin(age * 0.25F + phase) * 0.0007;
            this.zd += Mth.cos(age * 0.21F + phase) * 0.0007;
        } else if (kind == Kind.BUBBLE) {
            this.xd += Mth.sin(age * 0.3F + phase) * 0.0003;
        }
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.96;
        this.zd *= 0.96;
        this.yd *= kind == Kind.PETAL ? 0.97 : 0.985;
    }

    @Override
    public float getQuadSize(float partialTick) {
        float t = Mth.clamp((age + partialTick) / lifetime, 0.0F, 1.0F);
        return switch (kind) {
            // Full size at first, then smaller and smaller until it is gone.
            case GLINT -> baseSize * (1.0F - t * t);
            case BUBBLE -> baseSize * (t < 0.2F ? 0.6F + 2.0F * t : Mth.clamp(1.0F - (t - 0.2F) * 1.1F, 0.0F, 1.0F));
            case PETAL -> baseSize * (t < 0.15F ? t / 0.15F : t > 0.7F ? (1.0F - t) / 0.3F : 1.0F);
        };
    }

    @Override
    protected int getLightColor(float partialTick) {
        int base = super.getLightColor(partialTick);
        return (base & 0xFFFF0000) | Math.max(base & 0xFFFF, 0xB0);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final Kind kind;

        public Provider(SpriteSet sprites, Kind kind) {
            this.sprites = sprites;
            this.kind = kind;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new AromaParticle(level, x, y, z, vx, vy, vz, sprites, kind);
        }
    }
}
