package net.mikexxx.flowerbeds.garden;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Support for the Mikexxx Ornamental Trees mod. Nothing here needs that mod to be installed: its trees are
 * recognised by name, and drawn in pots and beds as small crossed-plane trees using its own textures.
 */
public final class OrnamentalTrees {
    public static final String MOD_ID = "mikexxx_ornamental_trees";
    /** How big a tree of the mod is in blocks, per 16 texture pixels of its picture, in a pot. */
    public static final float POT_SCALE = 0.15F;

    private OrnamentalTrees() {
    }

    public static boolean isTree(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return key != null && key.getNamespace().equals(MOD_ID) && key.getPath().endsWith("_tree");
    }

    /** The registry path of the tree ("cherry_tree"). */
    public static String nameOf(ItemStack stack) {
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return key == null ? "" : key.getPath();
    }

    /** Width of the tree's picture in blocks. */
    public static int widthOf(String name) {
        return switch (name) {
            case "cherry_tree" -> 7;
            default -> 5;
        };
    }

    /** Height of the tree's picture in blocks. */
    public static int heightOf(String name) {
        return switch (name) {
            case "cherry_tree" -> 7;
            case "hydrangea_tree" -> 5;
            default -> 7;
        };
    }
}
