package net.mikexxx.flowerbeds.block;

import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * The inside of the china pot and the quartz amphora, one slice per sixteenth of height, made from their bowl
 * models (pot_fill.json). Substrate and liquid are drawn slice by slice inside this outline, so they follow the
 * curved silhouette of the pot instead of filling a full box that pokes through its wall.
 */
public final class PotFill {
    /** One horizontal slice from y to y + 1 (in sixteenths): the area, the parts not covered by the slice above, the
     * parts not covered by the slice below, and the side edges. All coordinates in sixteenths of the block. */
    public record Slice(int y, float[][] rects, float[][] up, float[][] down, Edge[] edges) {}

    /** A vertical wall of the fill. alongX: the wall stands at x = pos and runs along z; positive: it faces +x / +z. */
    public record Edge(boolean alongX, float pos, float a0, float a1, boolean positive) {}

    private static Map<String, Slice[]> table;

    private PotFill() {
    }

    /** The first slice is y = 2 (the pot floor). Null for a pot that keeps its plain box. */
    public static Slice[] slices(BlockState state) {
        String variant = variantOf(state);
        if (variant == null) {
            return null;
        }
        String key;
        if (state.hasProperty(RoundPotBlock.ROUND3) && state.getValue(RoundPotBlock.ROUND3) != Round3.NONE) {
            key = "round_" + state.getValue(RoundPotBlock.ROUND3).getSerializedName();
        } else {
            key = bits(state, LargePotBlock.NORTH, LargePotBlock.EAST, LargePotBlock.SOUTH, LargePotBlock.WEST) + "_"
                    + bits(state, LargePotBlock.NORTH_EAST, LargePotBlock.SOUTH_EAST, LargePotBlock.SOUTH_WEST,
                    LargePotBlock.NORTH_WEST);
        }
        return load().get(variant + "/" + key);
    }

    private static String bits(BlockState state, net.minecraft.world.level.block.state.properties.BooleanProperty... props) {
        StringBuilder sb = new StringBuilder();
        for (net.minecraft.world.level.block.state.properties.BooleanProperty p : props) {
            sb.append(state.getValue(p) ? '1' : '0');
        }
        return sb.toString();
    }

    private static String variantOf(BlockState state) {
        var id = ForgeRegistries.BLOCKS.getKey(state.getBlock());
        if (id == null) {
            return null;
        }
        return switch (id.getPath()) {
            case "quartz_amphora_pot" -> "quartz_pot";
            case "china_large_pot" -> "china_pot";
            default -> null;
        };
    }

    private static float[][] rects(JsonArray list) {
        float[][] out = new float[list.size()][4];
        for (int i = 0; i < list.size(); i++) {
            JsonArray q = list.get(i).getAsJsonArray();
            for (int k = 0; k < 4; k++) {
                out[i][k] = q.get(k).getAsFloat();
            }
        }
        return out;
    }

    private static synchronized Map<String, Slice[]> load() {
        if (table != null) {
            return table;
        }
        Map<String, Slice[]> map = new HashMap<>();
        try (Reader reader = new InputStreamReader(
                PotFill.class.getResourceAsStream("/assets/mikexxx_flowerbeds/pot_fill.json"), StandardCharsets.UTF_8)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
                JsonArray list = entry.getValue().getAsJsonArray();
                Slice[] slices = new Slice[list.size()];
                for (int i = 0; i < slices.length; i++) {
                    JsonArray s = list.get(i).getAsJsonArray();
                    JsonArray es = s.get(4).getAsJsonArray();
                    Edge[] edges = new Edge[es.size()];
                    for (int k = 0; k < edges.length; k++) {
                        JsonArray e = es.get(k).getAsJsonArray();
                        edges[k] = new Edge(e.get(0).getAsString().equals("x"), e.get(1).getAsFloat(),
                                e.get(2).getAsFloat(), e.get(3).getAsFloat(), e.get(4).getAsInt() > 0);
                    }
                    slices[i] = new Slice(s.get(0).getAsInt(), rects(s.get(1).getAsJsonArray()),
                            rects(s.get(2).getAsJsonArray()), rects(s.get(3).getAsJsonArray()), edges);
                }
                map.put(entry.getKey(), slices);
            }
        } catch (Exception e) {
            // No table: the renderer falls back to the plain box.
        }
        table = map;
        return map;
    }
}
