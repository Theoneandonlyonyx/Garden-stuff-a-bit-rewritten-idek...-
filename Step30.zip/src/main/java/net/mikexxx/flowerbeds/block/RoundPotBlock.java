package net.mikexxx.flowerbeds.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/**
 * A pot that turns round when it is part of a connected group that is exactly a 3x3 square: the china pot, and
 * the birdbath. Any other group (2x2, 3x4, an L ...) keeps the ordinary connected shapes.
 */
public class RoundPotBlock extends LargePotBlock {

    public static final EnumProperty<Round3> ROUND3 = EnumProperty.create("round3", Round3.class);

    /** Quartz uses this class too, but stays square. */
    private final boolean roundable;

    public RoundPotBlock(BlockBehaviour.Properties properties, boolean particlesPass, boolean roundable) {
        super(properties, particlesPass);
        this.roundable = roundable;
        if (hasRoundProperty()) {
            registerDefaultState(this.defaultBlockState().setValue(ROUND3, Round3.NONE));
        }
    }

    /** A subclass that keeps its own group state (the birdbath) turns this off. */
    protected boolean hasRoundProperty() {
        return true;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        if (hasRoundProperty()) {
            builder.add(ROUND3);
        }
    }

    @Override
    protected int refreshRadius() {
        return 3;
    }

    @Override
    protected BlockState finishState(LevelAccessor level, BlockPos pos, BlockState state) {
        return hasRoundProperty() ? state.setValue(ROUND3, roundable ? roundOf(level, pos) : Round3.NONE) : state;
    }

    /** Flood fills the group this pot belongs to, giving up above nine pots. */
    private Round3 roundOf(LevelAccessor level, BlockPos pos) {
        Set<BlockPos> group = new HashSet<>();
        ArrayDeque<BlockPos> open = new ArrayDeque<>();
        group.add(pos);
        open.add(pos);
        while (!open.isEmpty()) {
            BlockPos current = open.poll();
            for (BlockPos next : new BlockPos[] {current.north(), current.east(), current.south(), current.west()}) {
                if (!group.contains(next) && connects(level.getBlockState(next))) {
                    group.add(next);
                    if (group.size() > 9) {
                        return Round3.NONE;
                    }
                    open.add(next);
                }
            }
        }
        if (group.size() != 9) {
            return Round3.NONE;
        }
        int minX = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxZ = Integer.MIN_VALUE;
        for (BlockPos p : group) {
            minX = Math.min(minX, p.getX());
            maxX = Math.max(maxX, p.getX());
            minZ = Math.min(minZ, p.getZ());
            maxZ = Math.max(maxZ, p.getZ());
        }
        if (maxX - minX != 2 || maxZ - minZ != 2) {
            return Round3.NONE;
        }
        return Round3.at(pos.getX() - minX, pos.getZ() - minZ);
    }
}
