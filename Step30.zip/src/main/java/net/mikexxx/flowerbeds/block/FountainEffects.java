package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** The spray of a powered birdbath that has no birdbath on top: drops shot up from the middle of its group. */
public final class FountainEffects {
    private static final double RANGE = 32.0;
    /** Top of the nozzle, in blocks above the block. */
    private static final double NOZZLE_TOP = 14.8 / 16.0;

    private FountainEffects() {
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, LargePotBlockEntity pot) {
        if (!(state.getBlock() instanceof BirdbathBlock) || !state.getValue(BirdbathBlock.POWERED)
                || state.getValue(BirdbathBlock.UP) || !state.getValue(BirdbathBlock.GROUP).holdsFoot()
                || pot.effectiveLiquid() != LargePotBlock.Liquid.WATER) {
            return;
        }
        if (level.getNearestPlayer(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, RANGE, false) == null) {
            return;
        }
        BathGroup group = state.getValue(BirdbathBlock.GROUP);
        double x = pos.getX() + (group.evenX() ? 1.0 : 0.5);
        double z = pos.getZ() + (group.evenZ() ? 1.0 : 0.5);
        double y = pos.getY() + NOZZLE_TOP;
        RandomSource random = level.random;
        int count = 2 + random.nextInt(2);
        for (int i = 0; i < count; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double spread = random.nextDouble() * 0.03;
            level.addParticle(ModParticles.FOUNTAIN_DROP.get(), x, y, z,
                    Math.cos(angle) * spread, 0.30 + random.nextDouble() * 0.10, Math.sin(angle) * spread);
        }
    }
}
