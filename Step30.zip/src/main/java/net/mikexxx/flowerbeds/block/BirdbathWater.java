package net.mikexxx.flowerbeds.block;

import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Where the water of a birdbath is, in sixteenths: the floor of the bowl inside the rim, so the water follows the
 * round outline of the bowl models. The table (birdbath_water.json) is made from the bowl models themselves.
 * Keys: "r:nw" .. "r:se" for a cell of a round 3x3 bath, "m:N" for the neighbour mask N of any other block.
 */
public final class BirdbathWater {
    private static Map<String, float[][]> table;

    private BirdbathWater() {
    }

    /** Rectangles {x0, z0, x1, z1} of water in this block, or null when the table has none for the state. */
    public static float[][] rects(BlockState state) {
        return load().get(BirdbathBlock.waterKey(state));
    }

    private static synchronized Map<String, float[][]> load() {
        if (table != null) {
            return table;
        }
        Map<String, float[][]> map = new HashMap<>();
        try (Reader reader = new InputStreamReader(
                BirdbathWater.class.getResourceAsStream("/assets/mikexxx_flowerbeds/birdbath_water.json"),
                StandardCharsets.UTF_8)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
                JsonArray list = entry.getValue().getAsJsonArray();
                float[][] rects = new float[list.size()][4];
                for (int i = 0; i < list.size(); i++) {
                    JsonArray q = list.get(i).getAsJsonArray();
                    for (int k = 0; k < 4; k++) {
                        rects[i][k] = q.get(k).getAsFloat();
                    }
                }
                map.put(entry.getKey(), rects);
            }
        } catch (Exception e) {
            // No table: the renderer falls back to its plain shape.
        }
        table = map;
        return map;
    }
}
