package net.mikexxx.flowerbeds.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Glass Large Pot: a pot that also joins glass pots above and below it, like an aquarium. A pot with another
 * glass pot under it has no floor of its own, so the stack is one tall tank that is closed at the very bottom.
 */
public class GlassPotBlock extends LargePotBlock {

    /** true = another glass pot sits on this side, so the pots are one tank. */
    public static final BooleanProperty UP = BlockStateProperties.UP;
    public static final BooleanProperty DOWN = BlockStateProperties.DOWN;

    /** Walls and posts run the full height when the floor is gone. Indexed like the pot shapes. */
    private static final VoxelShape[] TALL_SHAPES = new VoxelShape[256];

    static {
        VoxelShape north = Block.box(2, 0, 0, 14, 16, 2);
        VoxelShape east = Block.box(14, 0, 2, 16, 16, 14);
        VoxelShape south = Block.box(2, 0, 14, 14, 16, 16);
        VoxelShape west = Block.box(0, 0, 2, 2, 16, 14);
        VoxelShape ne = Block.box(14, 0, 0, 16, 16, 2);
        VoxelShape se = Block.box(14, 0, 14, 16, 16, 16);
        VoxelShape sw = Block.box(0, 0, 14, 2, 16, 16);
        VoxelShape nw = Block.box(0, 0, 0, 2, 16, 2);
        for (int mask = 0; mask < 256; mask++) {
            boolean n = (mask & 1) != 0;
            boolean e = (mask & 2) != 0;
            boolean s = (mask & 4) != 0;
            boolean w = (mask & 8) != 0;
            VoxelShape shape = Shapes.empty();
            if (!n) shape = Shapes.or(shape, north);
            if (!e) shape = Shapes.or(shape, east);
            if (!s) shape = Shapes.or(shape, south);
            if (!w) shape = Shapes.or(shape, west);
            if (!(n && e && (mask & 16) != 0)) shape = Shapes.or(shape, ne);
            if (!(s && e && (mask & 32) != 0)) shape = Shapes.or(shape, se);
            if (!(s && w && (mask & 64) != 0)) shape = Shapes.or(shape, sw);
            if (!(n && w && (mask & 128) != 0)) shape = Shapes.or(shape, nw);
            TALL_SHAPES[mask] = shape.optimize();
        }
    }

    public GlassPotBlock(BlockBehaviour.Properties properties) {
        super(properties, true);
        registerDefaultState(this.stateDefinition.any()
                .setValue(NORTH, false).setValue(EAST, false).setValue(SOUTH, false).setValue(WEST, false)
                .setValue(NORTH_EAST, false).setValue(SOUTH_EAST, false)
                .setValue(SOUTH_WEST, false).setValue(NORTH_WEST, false)
                .setValue(SUBSTRATE, false)
                .setValue(LIGHT, 0)
                .setValue(UP, false).setValue(DOWN, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(UP, DOWN);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState state = super.getStateForPlacement(context);
        if (state == null) {
            return null;
        }
        BlockGetter level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        return state.setValue(UP, level.getBlockState(pos.above()).is(this))
                .setValue(DOWN, level.getBlockState(pos.below()).is(this));
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                  LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (direction == Direction.UP) {
            return state.setValue(UP, neighborState.is(this));
        }
        if (direction == Direction.DOWN) {
            return state.setValue(DOWN, neighborState.is(this));
        }
        return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    protected VoxelShape baseShape(BlockState state) {
        return state.getValue(DOWN) ? TALL_SHAPES[maskOf(state)] : super.baseShape(state);
    }
}
