package net.mikexxx.flowerbeds.block;

import net.minecraft.util.StringRepresentable;

/** Where a pot sits inside a finished 3x3 square of its own kind, or NONE when it is not part of one. */
public enum Round3 implements StringRepresentable {
    NONE("none"), N("n"), NE("ne"), E("e"), SE("se"), S("s"), SW("sw"), W("w"), NW("nw"), C("c");

    private final String name;

    Round3(String name) {
        this.name = name;
    }

    @Override
    public String getSerializedName() {
        return name;
    }

    /** dx and dz are 0..2 across the square, x growing east and z growing south. */
    public static Round3 at(int dx, int dz) {
        if (dz == 0) return dx == 0 ? NW : dx == 1 ? N : NE;
        if (dz == 1) return dx == 0 ? W : dx == 1 ? C : E;
        return dx == 0 ? SW : dx == 1 ? S : SE;
    }
}
