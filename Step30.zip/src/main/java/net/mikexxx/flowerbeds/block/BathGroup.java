package net.mikexxx.flowerbeds.block;

import net.minecraft.util.StringRepresentable;

/**
 * What a birdbath is inside its group of joined birdbaths.
 * NONE: part of a group but not holding the foot. NW..SE: part of a finished 3x3 round bath (C also holds the foot).
 * THIN: a lone birdbath on a slim foot. M_xy / L_xy: the block that holds the one shared foot of a bigger group;
 * M is medium (2 or 3 wide), L is large (4 or more); x/y tell whether the group is odd (O) or even (E) wide in x / z,
 * Q_xz: a cell of a finished round 4x4 bath (x and z 0..3); Q_11 holds the foot on the middle seam.
 * because an even group has its foot on the seam between two blocks, so the foot is drawn half a block over.
 */
public enum BathGroup implements StringRepresentable {
    NONE("none"), NW("nw"), N("n"), NE("ne"), W("w"), C("c"), E("e"), SW("sw"), S("s"), SE("se"),
    THIN("thin"),
    M_OO("m_oo"), M_EO("m_eo"), M_OE("m_oe"), M_EE("m_ee"),
    L_OO("l_oo"), L_EO("l_eo"), L_OE("l_oe"), L_EE("l_ee"),
    Q_00("q_00"), Q_10("q_10"), Q_20("q_20"), Q_30("q_30"),
    Q_01("q_01"), Q_11("q_11"), Q_21("q_21"), Q_31("q_31"),
    Q_02("q_02"), Q_12("q_12"), Q_22("q_22"), Q_32("q_32"),
    Q_03("q_03"), Q_13("q_13"), Q_23("q_23"), Q_33("q_33");

    private final String name;

    BathGroup(String name) {
        this.name = name;
    }

    @Override
    public String getSerializedName() {
        return name;
    }

    /** The round-bowl position this stands for (NONE unless it is one of the 3x3 cells). */
    public Round3 round() {
        return ordinal() <= SE.ordinal() && this != NONE ? Round3.valueOf(name()) : Round3.NONE;
    }

    public static BathGroup ofRound(Round3 round) {
        return round == Round3.NONE ? NONE : valueOf(round.name());
    }

    /** True for the block that carries the shared foot (and so the fountain nozzle). */
    public boolean holdsFoot() {
        return this == THIN || this == C || this == Q_11 || (ordinal() >= M_OO.ordinal() && ordinal() <= L_EE.ordinal());
    }

    /** The foot sits half a block east of this block's middle (an even-wide group). */
    public boolean evenX() {
        if (this == Q_11) {
            return true;
        }
        return ordinal() >= M_OO.ordinal() && ordinal() <= L_EE.ordinal() && ((ordinal() - M_OO.ordinal()) & 1) != 0;
    }

    /** The foot sits half a block south of this block's middle (an even-deep group). */
    public boolean evenZ() {
        if (this == Q_11) {
            return true;
        }
        return ordinal() >= M_OO.ordinal() && ordinal() <= L_EE.ordinal() && (((ordinal() - M_OO.ordinal()) >> 1) & 1) != 0;
    }

    /** size: 0 = lone, 1 = medium, 2 = large. */
    public static BathGroup foot(int size, boolean evenX, boolean evenZ) {
        if (size == 0) {
            return THIN;
        }
        int i = (evenX ? 1 : 0) + (evenZ ? 2 : 0);
        return values()[(size == 1 ? M_OO : L_OO).ordinal() + i];
    }

    /** True for a cell of a round 4x4 bath. */
    public boolean isQuad() {
        return ordinal() >= Q_00.ordinal();
    }

    /** The cell of a round 4x4 bath: x and z in 0..3. */
    public static BathGroup ofQuad(int x, int z) {
        return values()[Q_00.ordinal() + z * 4 + x];
    }

    /** Index 0..15 inside a round 4x4 bath, x + 4 * z. */
    public int quadIndex() {
        return ordinal() - Q_00.ordinal();
    }
}
