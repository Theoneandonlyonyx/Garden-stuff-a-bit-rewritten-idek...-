package net.mikexxx.flowerbeds.registry;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** The three particles of aromatized water. Their look lives in assets/.../particles and the client class. */
public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, PmpMikexxx.MODID);

    /** A rosy twinkle that shrinks away, like the green happy-villager sparkle. */
    public static final RegistryObject<SimpleParticleType> AROMA_GLINT =
            PARTICLES.register("aroma_glint", () -> new SimpleParticleType(false));
    /** A pale pink bubble. */
    public static final RegistryObject<SimpleParticleType> AROMA_BUBBLE =
            PARTICLES.register("aroma_bubble", () -> new SimpleParticleType(false));
    /** A sakura petal of varying size. */
    public static final RegistryObject<SimpleParticleType> AROMA_PETAL =
            PARTICLES.register("aroma_petal", () -> new SimpleParticleType(false));
    /** A drop of the birdbath fountain. */
    public static final RegistryObject<SimpleParticleType> FOUNTAIN_DROP =
            PARTICLES.register("fountain_drop", () -> new SimpleParticleType(false));
}
