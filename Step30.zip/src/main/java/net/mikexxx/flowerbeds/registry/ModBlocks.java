package net.mikexxx.flowerbeds.registry;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.BeddingBlock;
import net.mikexxx.flowerbeds.block.BirdbathBlock;
import net.mikexxx.flowerbeds.block.RoundPotBlock;
import net.mikexxx.flowerbeds.block.GlassPotBlock;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.SoilBlock;
import net.mikexxx.flowerbeds.block.WindowBoxBlock;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, PmpMikexxx.MODID);

    /** Darker, richer soil. Mines like dirt. */
    public static final RegistryObject<SoilBlock> SOIL_BLOCK = BLOCKS.register("soil_block",
            () -> new SoilBlock(BlockBehaviour.Properties.copy(Blocks.DIRT)));

    /** A porcelain building block: white with a blue lattice and gold dots. The key ingredient of the china pot. */
    public static final RegistryObject<Block> FINE_CHINA = BLOCKS.register("fine_china",
            () -> new Block(BlockBehaviour.Properties.copy(Blocks.WHITE_TERRACOTTA)));

    /** What the trowel turns a dirt, sand or similar block into. It has no item; it drops the original block. */
    public static final RegistryObject<BeddingBlock> BEDDING_BLOCK = BLOCKS.register("bedding_block",
            () -> new BeddingBlock(BlockBehaviour.Properties.copy(Blocks.DIRT)));

    /** Window boxes: six woods, stone and brick. The boolean says whether the box is wooden. */
    public static final Map<String, RegistryObject<WindowBoxBlock>> WINDOW_BOXES = new LinkedHashMap<>();

    static {
        for (String wood : new String[] {"oak", "spruce", "birch", "jungle", "acacia", "dark_oak"}) {
            WINDOW_BOXES.put(wood, BLOCKS.register("window_box_" + wood, () -> new WindowBoxBlock(true)));
        }
        WINDOW_BOXES.put("stone", BLOCKS.register("window_box_stone", () -> new WindowBoxBlock(false)));
        WINDOW_BOXES.put("brick", BLOCKS.register("window_box_brick", () -> new WindowBoxBlock(false)));
    }

    /**
     * Every Large Pot variant, by name: the sixteen dye colours (made from stained terracotta), plain terracotta,
     * quartz and calcite. The name is also the prefix of the block, item, model and recipe files.
     */
    public static final List<String> POT_VARIANTS = new ArrayList<>();

    /** The birdbath is registered as "silver_birdbath", not "..._large_pot". */
    public static final String BIRDBATH = "silver_birdbath";

    /** The quartz amphora pot ("quartz_amphora_pot"): its own block, separate from the square quartz large pot. */
    public static final String AMPHORA = "quartz_amphora";

    /** The registry name of a pot variant's block and item. */
    public static String registryName(String variant) {
        if (variant.equals(BIRDBATH)) {
            return variant;
        }
        return variant.equals(AMPHORA) ? "quartz_amphora_pot" : variant + "_large_pot";
    }

    static {
        for (DyeColor color : DyeColor.values()) {
            POT_VARIANTS.add(color.getName());
        }
        POT_VARIANTS.add("terracotta");
        POT_VARIANTS.add("quartz");
        POT_VARIANTS.add(AMPHORA);
        POT_VARIANTS.add("calcite");
        POT_VARIANTS.add("glass");
        POT_VARIANTS.add("china");
        POT_VARIANTS.add(BIRDBATH);
    }

    /** One Large Pot per variant, keyed by variant name. */
    public static final Map<String, RegistryObject<LargePotBlock>> LARGE_POTS = new LinkedHashMap<>();

    private static Block materialOf(String variant) {
        return switch (variant) {
            case "quartz", AMPHORA -> Blocks.QUARTZ_BLOCK;
            case "calcite" -> Blocks.CALCITE;
            case "glass" -> Blocks.GLASS;
            case BIRDBATH -> Blocks.STONE;
            default -> Blocks.TERRACOTTA;
        };
    }

    static {
        for (String variant : POT_VARIANTS) {
            LARGE_POTS.put(variant, BLOCKS.register(registryName(variant), () -> {
                BlockBehaviour.Properties props = BlockBehaviour.Properties.copy(materialOf(variant));
                if (variant.equals(BIRDBATH)) {
                    return new BirdbathBlock(props);
                }
                if (variant.equals("china")) {
                    return new RoundPotBlock(props, false, true);
                }
                if (variant.equals(AMPHORA)) {
                    // The amphora keeps square corners: it has the round3 state but never uses it.
                    return new RoundPotBlock(props, true, false);
                }
                if (variant.equals("glass")) {
                    return new GlassPotBlock(props);
                }
                // Quartz and calcite pots let particles (bubbles, smoke, fire) through.
                return new LargePotBlock(props, variant.equals("quartz") || variant.equals("calcite"));
            }));
        }
    }
}
