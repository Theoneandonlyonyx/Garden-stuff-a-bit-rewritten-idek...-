# Step 22 (on step 21)
- Split: the Quartz Large Pot is back as its own block (`quartz_large_pot`, the old square pot with its old models, recipe T T / T T / TTT). The amphora is now a separate block, `quartz_amphora_pot` (recipe T T / TTT / T T). Both exist side by side.
- Note: the amphora's id changed from `quartz_large_pot` to `quartz_amphora_pot`, so amphoras placed in old test worlds turn into large pots.
- Aromatization was already in (no code change): see the answer in chat.
