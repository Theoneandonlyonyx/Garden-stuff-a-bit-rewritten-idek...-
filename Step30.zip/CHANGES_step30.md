# Step 30 (on step 29)
- New block **Fine China** (`fine_china`): porcelain white with a blue diamond lattice, small blue flowers in each diamond and gold dots where the lines cross. The pattern repeats every 8 px, so any size of wall, floor or pillar built from it is one seamless pattern, no seams and no stripes. Mines with a pickaxe, in the creative tab.
- Recipe: 2x2 crafting grid (a normal crafting table has no 4x4), 2 quartz + 2 lapis lazuli on the diagonals, gives 3 Fine China.
- Fine China is now the key ingredient of the Blue-White China Pot: `F F / F B F / F F F` (F = Fine China, B = blue dye).
- China pot textures: the wall texture is now the same seamless lattice (it was horizontal stripes, which showed up as stripes whenever pots joined). The front wall keeps a round gold-and-blue medallion in the middle. Joined pots now continue the lattice from pot to pot.
