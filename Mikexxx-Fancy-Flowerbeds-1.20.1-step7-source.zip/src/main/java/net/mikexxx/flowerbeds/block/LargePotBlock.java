package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Large Pot: a hollow, closed-bottom container with walls two units thick, the same as a glass pane.
 * A side connects to a neighbouring pot, a plantable block, or a solid face, so a 3x3 of pots has no gaps.
 */
public class LargePotBlock extends PlantBedBlock {

    public enum Liquid implements StringRepresentable {
        NONE("none"), WATER("water"), LAVA("lava"), MILK("milk");

        private final String serializedName;

        Liquid(String serializedName) {
            this.serializedName = serializedName;
        }

        @Override
        public String getSerializedName() {
            return serializedName;
        }
    }

    /** true = this side is open to a neighbour, so no wall is drawn. */
    public static final BooleanProperty NORTH = BlockStateProperties.NORTH;
    public static final BooleanProperty EAST = BlockStateProperties.EAST;
    public static final BooleanProperty SOUTH = BlockStateProperties.SOUTH;
    public static final BooleanProperty WEST = BlockStateProperties.WEST;
    /** true while the pot holds anything, which shows the soil surface. */
    public static final BooleanProperty SUBSTRATE = BooleanProperty.create("substrate");
    public static final EnumProperty<Liquid> LIQUID = EnumProperty.create("liquid", Liquid.class);

    /** Dye palette, indexed by DyeColor ordinal. Used to tint dyed water. */
    public static final int[] DYE_RGB = {
            0xF0F0F0, 0xF9801D, 0xC74EBD, 0x3AB3DA,
            0xFED83D, 0x80C71F, 0xF38BAA, 0x474F52,
            0x9D9D97, 0x169C9C, 0x8932B8, 0x3C44AA,
            0x835432, 0x5E7C16, 0xB02E26, 0x1D1D21
    };

    private static final VoxelShape BASE = Block.box(0, 0, 0, 16, 2, 16);
    private static final VoxelShape NORTH_WALL = Block.box(0, 0, 0, 16, 16, 2);
    private static final VoxelShape EAST_WALL = Block.box(14, 0, 0, 16, 16, 16);
    private static final VoxelShape SOUTH_WALL = Block.box(0, 0, 14, 16, 16, 16);
    private static final VoxelShape WEST_WALL = Block.box(0, 0, 0, 2, 16, 16);
    private static final VoxelShape[] SHAPES = new VoxelShape[16];

    static {
        for (int mask = 0; mask < 16; mask++) {
            VoxelShape shape = BASE;
            if ((mask & 1) == 0) shape = Shapes.or(shape, NORTH_WALL);
            if ((mask & 2) == 0) shape = Shapes.or(shape, EAST_WALL);
            if ((mask & 4) == 0) shape = Shapes.or(shape, SOUTH_WALL);
            if ((mask & 8) == 0) shape = Shapes.or(shape, WEST_WALL);
            SHAPES[mask] = shape.optimize();
        }
    }

    public LargePotBlock(BlockBehaviour.Properties properties) {
        super(properties.noOcclusion().lightLevel(state ->
                Math.max(state.getValue(LIGHT), state.getValue(LIQUID) == Liquid.LAVA ? 15 : 0)));
        registerDefaultState(this.stateDefinition.any()
                .setValue(NORTH, false)
                .setValue(EAST, false)
                .setValue(SOUTH, false)
                .setValue(WEST, false)
                .setValue(SUBSTRATE, false)
                .setValue(LIQUID, Liquid.NONE)
                .setValue(LIGHT, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(NORTH, EAST, SOUTH, WEST, SUBSTRATE, LIQUID);
    }

    /** A side connects to a pot, a plantable block, or any solid face. */
    private static boolean connects(BlockState neighbor, BlockGetter level, BlockPos neighborPos, Direction towardNeighbor) {
        if (neighbor.getBlock() instanceof LargePotBlock) {
            return true;
        }
        if (GardenLayout.isPlantableState(neighbor)) {
            return false; // pots never open their walls to plantable blocks; only soil does that
        }
        return neighbor.isFaceSturdy(level, neighborPos, towardNeighbor.getOpposite());
    }

    private static BooleanProperty propertyFor(Direction direction) {
        if (direction == Direction.NORTH) return NORTH;
        if (direction == Direction.EAST) return EAST;
        if (direction == Direction.SOUTH) return SOUTH;
        return WEST;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockPos pos = context.getClickedPos();
        BlockGetter level = context.getLevel();
        return this.defaultBlockState()
                .setValue(NORTH, connects(level.getBlockState(pos.north()), level, pos.north(), Direction.NORTH))
                .setValue(EAST, connects(level.getBlockState(pos.east()), level, pos.east(), Direction.EAST))
                .setValue(SOUTH, connects(level.getBlockState(pos.south()), level, pos.south(), Direction.SOUTH))
                .setValue(WEST, connects(level.getBlockState(pos.west()), level, pos.west(), Direction.WEST));
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                  LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (direction.getAxis().isHorizontal()) {
            return state.setValue(propertyFor(direction), connects(neighborState, level, neighborPos, direction));
        }
        return state;
    }

    private static int maskOf(BlockState state) {
        int mask = 0;
        if (state.getValue(NORTH)) mask |= 1;
        if (state.getValue(EAST)) mask |= 2;
        if (state.getValue(SOUTH)) mask |= 4;
        if (state.getValue(WEST)) mask |= 8;
        return mask;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPES[maskOf(state)];
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPES[maskOf(state)];
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new LargePotBlockEntity(pos, state);
    }

    @Override
    protected InteractionResult extraUse(BlockState state, Level level, BlockPos pos, Player player,
                                         InteractionHand hand, ItemStack held) {
        Liquid liquid = state.getValue(LIQUID);
        boolean creative = player.getAbilities().instabuild;

        // Fill an empty pot with a liquid bucket.
        if (held.is(Items.WATER_BUCKET) || held.is(Items.LAVA_BUCKET) || held.is(Items.MILK_BUCKET)) {
            if (liquid != Liquid.NONE) {
                return InteractionResult.SUCCESS;
            }
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof LargePotBlockEntity pot) {
                Liquid incoming = held.is(Items.WATER_BUCKET) ? Liquid.WATER
                        : held.is(Items.LAVA_BUCKET) ? Liquid.LAVA : Liquid.MILK;
                pot.setLiquid(incoming);
                if (!creative) {
                    player.setItemInHand(hand, new ItemStack(Items.BUCKET));
                }
                SoundEvent sound = incoming == Liquid.LAVA ? SoundEvents.BUCKET_EMPTY_LAVA : SoundEvents.BUCKET_EMPTY;
                level.playSound(null, pos, sound, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.SUCCESS;
        }

        // An empty bucket removes the liquid and gives back the matching bucket.
        if (held.is(Items.BUCKET)) {
            if (liquid == Liquid.NONE) {
                return InteractionResult.SUCCESS;
            }
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof LargePotBlockEntity pot) {
                ItemStack filled;
                SoundEvent sound;
                if (liquid == Liquid.WATER) {
                    filled = new ItemStack(Items.WATER_BUCKET);
                    sound = SoundEvents.BUCKET_FILL;
                } else if (liquid == Liquid.LAVA) {
                    filled = new ItemStack(Items.LAVA_BUCKET);
                    sound = SoundEvents.BUCKET_FILL_LAVA;
                } else {
                    filled = new ItemStack(Items.MILK_BUCKET);
                    sound = SoundEvents.BUCKET_FILL;
                }
                pot.setLiquid(Liquid.NONE);
                player.setItemInHand(hand, ItemUtils.createFilledResult(held, player, filled));
                level.playSound(null, pos, sound, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.SUCCESS;
        }

        // Dye tints water, the same way it tints water in a cauldron.
        if (held.getItem() instanceof DyeItem dye) {
            if (liquid != Liquid.WATER) {
                return InteractionResult.PASS;
            }
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof LargePotBlockEntity pot) {
                pot.setDyeColor(DYE_RGB[dye.getDyeColor().ordinal()]);
                if (!creative) {
                    held.shrink(1);
                }
            }
            return InteractionResult.SUCCESS;
        }

        return InteractionResult.PASS;
    }
}
