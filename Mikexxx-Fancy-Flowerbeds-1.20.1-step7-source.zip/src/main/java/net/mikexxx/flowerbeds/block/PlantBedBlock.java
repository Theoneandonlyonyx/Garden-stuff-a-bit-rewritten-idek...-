package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.PlantBedBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.menu.PlantBedMenu;
import net.mikexxx.flowerbeds.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.network.NetworkHooks;

/**
 * Shared behaviour of Soil Blocks and Large Pots: the trowel opens Arrange Plants, bone meal moves
 * the plants one growth stage, and neighbouring beds are told when a bed appears or disappears.
 */
public abstract class PlantBedBlock extends Block implements EntityBlock {

    /** Light level the bed gives off, from the lanterns and candles stored in it. */
    public static final IntegerProperty LIGHT = IntegerProperty.create("light", 0, 15);

    public PlantBedBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LIGHT);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);

        if (held.is(ModItems.TROWEL.get())) {
            if (!level.isClientSide
                    && level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed
                    && player instanceof ServerPlayer serverPlayer) {
                openPlantMenu(serverPlayer, bed);
            }
            return InteractionResult.SUCCESS;
        }

        if (held.is(Items.BONE_MEAL)) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            if (level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed && bed.growPlants()) {
                level.levelEvent(2005, pos, 0);
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        }

        return extraUse(state, level, pos, player, hand, held);
    }

    /** Hook for block-specific interaction (the Large Pot uses it for liquids and dye). */
    protected InteractionResult extraUse(BlockState state, Level level, BlockPos pos, Player player,
                                         InteractionHand hand, ItemStack held) {
        return InteractionResult.PASS;
    }

    private static void openPlantMenu(ServerPlayer player, PlantBedBlockEntity bed) {
        BlockPos pos = bed.getBlockPos();
        int mask = GardenLayout.activeMask(bed.getLevel(), pos);
        NetworkHooks.openScreen(player,
                new SimpleMenuProvider((id, inv, p) -> new PlantBedMenu(id, inv, bed),
                        Component.translatable("container.mikexxx_flowerbeds.plant_bed")),
                buf -> {
                    buf.writeBlockPos(pos);
                    buf.writeInt(mask);
                });
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);
        if (!level.isClientSide && !state.is(oldState.getBlock())) {
            reconcileAround(level, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock())) {
            if (level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed) {
                bed.dropContents();
            }
            level.removeBlockEntity(pos);
            if (!level.isClientSide) {
                reconcileAround(level, pos);
            }
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    private static void reconcileAround(Level level, BlockPos pos) {
        for (Direction side : GardenLayout.SIDES) {
            if (level.getBlockEntity(pos.relative(side)) instanceof PlantBedBlockEntity bed) {
                bed.reconcile();
            }
        }
    }
}
