package net.mikexxx.flowerbeds.block.entity;

import net.mikexxx.flowerbeds.block.PlantBedBlock;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/**
 * Stores the items of a bed. Only the bed that owns a slot stores its item, so a shared border slot
 * is never duplicated. Nothing here ticks, drops or grows by itself.
 */
public abstract class PlantBedBlockEntity extends BlockEntity {

    protected final NonNullList<ItemStack> slots = NonNullList.withSize(GardenLayout.SLOT_COUNT, ItemStack.EMPTY);
    /** Growth age per slot, used by plants with growth stages. */
    protected final int[] ages = new int[GardenLayout.SLOT_COUNT];
    /** Facing per slot, 0..3 quarter turns, used by scaled fruit. */
    protected final int[] rotations = new int[GardenLayout.SLOT_COUNT];

    protected PlantBedBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    /** Height of the planting surface within this block, in block units. */
    public abstract float bedHeight();

    public ItemStack getSlot(int index) {
        return slots.get(index);
    }

    public int getAge(int index) {
        return ages[index];
    }

    public int getRotation(int index) {
        return rotations[index];
    }

    public void setSlot(int index, ItemStack stack, int age, int rotation) {
        if (stack.isEmpty()) {
            slots.set(index, ItemStack.EMPTY);
            ages[index] = 0;
            rotations[index] = 0;
        } else {
            slots.set(index, stack.copyWithCount(1));
            ages[index] = age;
            rotations[index] = rotation & 3;
        }
        onSlotsChanged();
    }

    public boolean hasContents() {
        for (ItemStack stack : slots) {
            if (!stack.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /** Light this bed gives off: the strongest light of anything stored in it. */
    public int lightLevel() {
        int light = 0;
        for (ItemStack stack : slots) {
            light = Math.max(light, GardenLayout.lightOf(stack));
        }
        return Math.min(15, light);
    }

    /** Subclasses extend this to keep their own block state flags in step with the contents. */
    protected void updateBlockState() {
        if (level == null) {
            return;
        }
        BlockState state = level.getBlockState(worldPosition);
        if (!(state.getBlock() instanceof PlantBedBlock)) {
            return;
        }
        int light = lightLevel();
        if (state.getValue(PlantBedBlock.LIGHT) != light) {
            level.setBlock(worldPosition, state.setValue(PlantBedBlock.LIGHT, light), Block.UPDATE_ALL);
        }
    }

    protected void onSlotsChanged() {
        updateBlockState();
        setChanged();
        syncToClients();
    }

    protected void syncToClients() {
        if (level == null) {
            return;
        }
        BlockState state = level.getBlockState(worldPosition);
        level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
    }

    /**
     * Bone meal: every plant in the bed that has a growth stage moves on exactly one stage.
     * Returns true if at least one plant grew, which is when the bone meal is used up.
     */
    public boolean growPlants() {
        boolean grew = false;
        for (int i = 0; i < GardenLayout.SLOT_COUNT; i++) {
            ItemStack stack = slots.get(i);
            if (stack.isEmpty()) {
                continue;
            }
            if (!(stack.getItem() instanceof BlockItem blockItem)) {
                continue;
            }
            IntegerProperty growth = PlantStates.growthProperty(blockItem.getBlock().defaultBlockState());
            if (growth == null) {
                continue;
            }
            if (ages[i] < PlantStates.maxOf(growth)) {
                ages[i]++;
                grew = true;
            }
        }
        if (grew) {
            onSlotsChanged();
        }
        return grew;
    }

    /** Breaking the bed drops whatever it stores. */
    public void dropContents() {
        if (level == null || level.isClientSide) {
            return;
        }
        for (int i = 0; i < GardenLayout.SLOT_COUNT; i++) {
            ItemStack stack = slots.get(i);
            if (!stack.isEmpty()) {
                Block.popResource(level, worldPosition, stack);
                slots.set(i, ItemStack.EMPTY);
                ages[i] = 0;
                rotations[i] = 0;
            }
        }
    }

    /**
     * Called when a neighbouring bed appears or disappears. A border slot that this bed no longer owns
     * is handed to its new owner, or dropped if the owner's slot is occupied or the slot no longer exists.
     */
    public void reconcile() {
        if (level == null || level.isClientSide) {
            return;
        }
        boolean changed = false;
        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            ItemStack stack = slots.get(i);
            if (stack.isEmpty()) {
                continue;
            }
            GardenLayout.Owner owner = GardenLayout.resolve(level, worldPosition, i);
            if (owner.active() && owner.pos().equals(worldPosition)) {
                continue;
            }
            int age = ages[i];
            int rotation = rotations[i];
            slots.set(i, ItemStack.EMPTY);
            ages[i] = 0;
            rotations[i] = 0;
            changed = true;
            if (owner.active()
                    && level.getBlockEntity(owner.pos()) instanceof PlantBedBlockEntity other
                    && other.getSlot(owner.slot()).isEmpty()) {
                other.setSlot(owner.slot(), stack, age, rotation);
            } else {
                Block.popResource(level, worldPosition, stack);
            }
        }
        if (changed) {
            onSlotsChanged();
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, slots);
        tag.putIntArray("Ages", ages);
        tag.putIntArray("Rot", rotations);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        ContainerHelper.loadAllItems(tag, slots);
        int[] savedAges = tag.getIntArray("Ages");
        int[] savedRot = tag.getIntArray("Rot");
        for (int i = 0; i < ages.length; i++) {
            ages[i] = i < savedAges.length ? savedAges[i] : 0;
            rotations[i] = i < savedRot.length ? savedRot[i] : 0;
        }
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
