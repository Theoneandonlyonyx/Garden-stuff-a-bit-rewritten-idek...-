package net.mikexxx.flowerbeds.block.entity;

import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class LargePotBlockEntity extends PlantBedBlockEntity {

    /** Dyed water colour as RGB, or -1 when undyed. Only used while the pot holds water. */
    private int dyeColor = -1;

    public LargePotBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.LARGE_POT.get(), pos, state);
    }

    /** The soil surface sits 10/16 up inside the pot walls. */
    @Override
    public float bedHeight() {
        return 10.0F / 16.0F;
    }

    public int getDyeColor() {
        return dyeColor;
    }

    public void setDyeColor(int rgb) {
        this.dyeColor = rgb;
        onSlotsChanged();
    }

    public void setLiquid(LargePotBlock.Liquid liquid) {
        if (level == null) {
            return;
        }
        if (liquid != LargePotBlock.Liquid.WATER) {
            dyeColor = -1;
        }
        BlockState state = level.getBlockState(worldPosition);
        if (state.getBlock() instanceof LargePotBlock) {
            level.setBlock(worldPosition, state.setValue(LargePotBlock.LIQUID, liquid), Block.UPDATE_ALL);
        }
        onSlotsChanged();
    }

    @Override
    protected void updateBlockState() {
        super.updateBlockState();
        if (level == null) {
            return;
        }
        BlockState state = level.getBlockState(worldPosition);
        if (state.getBlock() instanceof LargePotBlock) {
            boolean substrate = hasContents();
            if (state.getValue(LargePotBlock.SUBSTRATE) != substrate) {
                level.setBlock(worldPosition, state.setValue(LargePotBlock.SUBSTRATE, substrate), Block.UPDATE_ALL);
            }
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("DyeColor", dyeColor);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        dyeColor = tag.contains("DyeColor") ? tag.getInt("DyeColor") : -1;
    }
}
