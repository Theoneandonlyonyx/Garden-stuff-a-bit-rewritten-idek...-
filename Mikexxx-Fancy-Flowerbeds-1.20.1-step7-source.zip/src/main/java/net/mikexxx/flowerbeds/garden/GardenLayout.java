package net.mikexxx.flowerbeds.garden;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.PlantBedBlock;
import net.mikexxx.flowerbeds.block.SoilBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Slot layout shared by Soil Blocks and Large Pots.
 *
 * Each bed has a 5x5 grid of quarter-block positions (0..4 in each direction).
 *   - 5 core slots: the centre and the four inner diagonals. They are always available.
 *   - 12 border slots: three per side. Each side's three slots sit on that side only, at the
 *     quarter points between its corners. A side's slots exist when a plantable block is on that
 *     side, and they are shared with that neighbour. Nothing is shared with a diagonal block.
 *   - 1 groundcover slot, drawn flat over the bed.
 */
public final class GardenLayout {
    private GardenLayout() {}

    public static final int CORE_SLOTS = 5;
    public static final int SIDE_SLOTS = 3;
    public static final int PLANT_SLOTS = CORE_SLOTS + 4 * SIDE_SLOTS;
    public static final int GROUNDCOVER_SLOT = PLANT_SLOTS;
    public static final int SLOT_COUNT = GROUNDCOVER_SLOT + 1;

    /** Grid position (0..4) of each plant slot, in slot order. Border slots: N, E, S, W, three each. */
    public static final int[] GRID_X = {2, 1, 3, 1, 3,   1, 2, 3,   4, 4, 4,   1, 2, 3,   0, 0, 0};
    public static final int[] GRID_Z = {2, 1, 1, 3, 3,   0, 0, 0,   1, 2, 3,   4, 4, 4,   1, 2, 3};

    /** Sides in slot order. The side index of a border slot is (slot - CORE_SLOTS) / SIDE_SLOTS. */
    public static final Direction[] SIDES = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

    /** Scaled fruit (pumpkins, melons, jack-o'-lanterns and modded fruit) is drawn at this size. */
    public static final float SCALED_FRUIT_SCALE = 0.5F;
    /** Light given by candles and lanterns that do not emit light themselves. */
    public static final int CANDLE_LIGHT = 12;
    public static final int LANTERN_LIGHT = 15;

    public static final TagKey<Block> PLANTABLE =
            TagKey.create(Registries.BLOCK, new ResourceLocation(PmpMikexxx.MODID, "plantable"));
    public static final TagKey<Item> LANTERNS =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "lanterns"));
    public static final TagKey<Item> CANDLES =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "candles"));
    public static final TagKey<Item> SCALED_FRUIT =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "scaled_fruit"));

    /** Result of resolving a slot: whether it exists, and which bed stores its item. */
    public record Owner(boolean active, BlockPos pos, int slot) {}

    public static int sideSlot(int side, int index) {
        return CORE_SLOTS + side * SIDE_SLOTS + index;
    }

    public static float localX(int slot) {
        return GRID_X[slot] / 4.0F;
    }

    public static float localZ(int slot) {
        return GRID_Z[slot] / 4.0F;
    }

    public static boolean isPlantableState(BlockState state) {
        return state.getBlock() instanceof PlantBedBlock || state.is(PLANTABLE);
    }

    /** Plants and groundcover: any block item. Non-block items have no world model to draw. */
    public static boolean isBlockItem(ItemStack stack) {
        return stack.getItem() instanceof BlockItem;
    }

    public static boolean isScaled(ItemStack stack) {
        return stack.getItem() instanceof BlockItem && stack.is(SCALED_FRUIT);
    }

    /** Light the item gives while it sits in a bed (0 if none). */
    public static int lightOf(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return 0;
        }
        int emitted = blockItem.getBlock().defaultBlockState().getLightEmission();
        if (stack.is(CANDLES)) {
            return Math.max(emitted, CANDLE_LIGHT);
        }
        if (stack.is(LANTERNS)) {
            return Math.max(emitted, LANTERN_LIGHT);
        }
        return emitted;
    }

    /**
     * Works out whether a slot of the bed at {@code bed} exists, and which bed stores it.
     * Core slots always belong to the bed. A border slot exists when the neighbour on its side is
     * plantable, and it is stored by whichever of the two beds has the smaller position.
     */
    public static Owner resolve(Level level, BlockPos bed, int slot) {
        if (slot < CORE_SLOTS) {
            return new Owner(true, bed, slot);
        }
        int rel = slot - CORE_SLOTS;
        int side = rel / SIDE_SLOTS;
        int index = rel % SIDE_SLOTS;

        BlockPos neighbor = bed.relative(SIDES[side]);
        if (!sharesSide(level, bed, neighbor)) {
            return new Owner(false, bed, slot);
        }
        if (level.getBlockState(neighbor).getBlock() instanceof PlantBedBlock && compare(neighbor, bed) < 0) {
            // The neighbour's slot on the opposite side covers the same boundary.
            return new Owner(true, neighbor, sideSlot((side + 2) % 4, index));
        }
        return new Owner(true, bed, slot);
    }

    /** Bit i is set when plant slot i of the bed exists. */
    public static int activeMask(Level level, BlockPos bed) {
        int mask = 0;
        for (int i = 0; i < PLANT_SLOTS; i++) {
            if (resolve(level, bed, i).active()) {
                mask |= 1 << i;
            }
        }
        return mask;
    }

    /** Whether a bed of this kind opens its side toward the other block. Soil opens to any plantable block; a pot only to other pots. */
    public static boolean bedOpensTo(BlockState bed, BlockState other) {
        if (bed.getBlock() instanceof SoilBlock) {
            return isPlantableState(other);
        }
        if (bed.getBlock() instanceof LargePotBlock) {
            return other.getBlock() instanceof LargePotBlock;
        }
        return false;
    }

    /**
     * A side has shared border slots only when the two blocks open toward each other. Two beds must both
     * open toward each other; a plain plantable block (dirt, grass, ...) only needs to be opened to by the bed.
     */
    public static boolean sharesSide(Level level, BlockPos bed, BlockPos neighbor) {
        BlockState self = level.getBlockState(bed);
        BlockState other = level.getBlockState(neighbor);
        if (other.getBlock() instanceof PlantBedBlock) {
            return bedOpensTo(self, other) && bedOpensTo(other, self);
        }
        return bedOpensTo(self, other);
    }

    private static int compare(BlockPos a, BlockPos b) {
        int c = Integer.compare(a.getX(), b.getX());
        return c != 0 ? c : Integer.compare(a.getZ(), b.getZ());
    }
}
