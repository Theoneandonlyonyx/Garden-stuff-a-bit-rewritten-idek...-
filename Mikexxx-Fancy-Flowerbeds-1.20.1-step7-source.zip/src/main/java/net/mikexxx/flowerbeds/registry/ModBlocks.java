package net.mikexxx.flowerbeds.registry;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.SoilBlock;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, PmpMikexxx.MODID);

    /** Darker, richer soil. Mines like dirt. */
    public static final RegistryObject<SoilBlock> SOIL_BLOCK = BLOCKS.register("soil_block",
            () -> new SoilBlock(BlockBehaviour.Properties.copy(Blocks.DIRT)));

    /** One Large Pot per dye colour, using the terracotta-style textures. */
    public static final Map<DyeColor, RegistryObject<LargePotBlock>> LARGE_POTS = new EnumMap<>(DyeColor.class);

    static {
        for (DyeColor color : DyeColor.values()) {
            LARGE_POTS.put(color, BLOCKS.register(color.getName() + "_large_pot",
                    () -> new LargePotBlock(BlockBehaviour.Properties.copy(Blocks.TERRACOTTA))));
        }
    }
}
