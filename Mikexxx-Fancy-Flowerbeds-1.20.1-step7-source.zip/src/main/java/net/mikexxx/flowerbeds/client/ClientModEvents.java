package net.mikexxx.flowerbeds.client;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.client.renderer.PlantBedRenderer;
import net.mikexxx.flowerbeds.client.screen.PlantBedScreen;
import net.mikexxx.flowerbeds.registry.ModBlockEntities;
import net.mikexxx.flowerbeds.registry.ModBlocks;
import net.mikexxx.flowerbeds.registry.ModMenus;
import net.minecraft.client.color.block.BlockColor;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = PmpMikexxx.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

    /**
     * Tints the water surface. Dyed water uses its dye colour, plain water uses the biome water colour,
     * milk is white, and lava is never tinted (it uses its own texture).
     */
    private static final BlockColor POT_TINT = (state, level, pos, tintIndex) -> {
        if (tintIndex != 0) return 0xFFFFFF;
        if (level == null || pos == null) return 0x3F76E4;
        LargePotBlock.Liquid liquid = state.getValue(LargePotBlock.LIQUID);
        if (liquid != LargePotBlock.Liquid.WATER) return 0xFFFFFF;
        if (level.getBlockEntity(pos) instanceof LargePotBlockEntity pot && pot.getDyeColor() != -1) {
            return pot.getDyeColor();
        }
        return BiomeColors.getAverageWaterColor(level, pos);
    };

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            for (RegistryObject<LargePotBlock> pot : ModBlocks.LARGE_POTS.values()) {
                ItemBlockRenderTypes.setRenderLayer(pot.get(), RenderType.translucent());
            }
            MenuScreens.register(ModMenus.PLANT_BED.get(), PlantBedScreen::new);
        });
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.SOIL.get(), context -> new PlantBedRenderer<>(context));
        event.registerBlockEntityRenderer(ModBlockEntities.LARGE_POT.get(), context -> new PlantBedRenderer<>(context));
    }

    @SubscribeEvent
    public static void onRegisterBlockColors(RegisterColorHandlersEvent.Block event) {
        event.register(POT_TINT,
                ModBlocks.LARGE_POTS.values().stream().map(RegistryObject::get).toArray(Block[]::new));
    }
}
