# Step 14 (on step 13)
- The single covering plane is gone completely: every plant is drawn with its real, normal model. Overlapping plants are only nudged apart by a hair to avoid flicker.
