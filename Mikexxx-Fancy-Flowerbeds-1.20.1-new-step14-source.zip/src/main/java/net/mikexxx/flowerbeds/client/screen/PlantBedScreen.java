package net.mikexxx.flowerbeds.client.screen;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.menu.PlantBedMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/**
 * Arrange Plants. Soil, bedding and pots all use this one layout: a centre place, four around it and a ring of
 * border places. A border place that has no connected block to share it is shown greyed out and unlocks when a
 * neighbour appears. The layout never turns; north is always at the top.
 */
public class PlantBedScreen extends AbstractContainerScreen<PlantBedMenu> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(PmpMikexxx.MODID, "textures/gui/plant_bed.png");

    /** Where the 18-pixel slot tile sits in the GUI texture. */
    private static final int TILE_U = 200;
    private static final int TILE_V = 0;
    private static final int TILE_SIZE = 18;
    /** Dark veil over a place that is locked until a neighbour shares it. */
    private static final int LOCKED_VEIL = 0xC0555555;

    public PlantBedScreen(PlantBedMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 204;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight, 256, 256);
        drawLinks(graphics);
        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            if (!GardenLayout.isUsed(i)) {
                continue;
            }
            Slot slot = menu.getSlot(i);
            int x = leftPos + slot.x;
            int y = topPos + slot.y;
            graphics.blit(TEXTURE, x - 1, y - 1, TILE_U, TILE_V, TILE_SIZE, TILE_SIZE, 256, 256);
            if (!slot.isActive()) {
                graphics.fill(x, y, x + 16, y + 16, LOCKED_VEIL);
            }
        }
        // The grid never turns, so say which way is north.
        int right = leftPos + PlantBedMenu.GRID_ORIGIN_X + PlantBedMenu.GRID_STEP * 5 + 4;
        graphics.drawString(this.font, "N", right, topPos + PlantBedMenu.GRID_ORIGIN_Y + 4, 0x404040, false);
        graphics.drawString(this.font, "^", right, topPos + PlantBedMenu.GRID_ORIGIN_Y + 13, 0x404040, false);
    }

    /** Ring of shared places: the border slots are joined by bars, lit when both ends are connected. */
    private static final int[][] RING = {
            {0, 0}, {2, 0}, {4, 0}, {4, 2}, {4, 4}, {2, 4}, {0, 4}, {0, 2}};

    private void drawLinks(GuiGraphics graphics) {
        for (int r = 0; r < RING.length; r++) {
            int[] a = RING[r];
            int[] b = RING[(r + 1) % RING.length];
            Slot sa = menu.getSlot(GardenLayout.slotAt(a[0], a[1]));
            Slot sb = menu.getSlot(GardenLayout.slotAt(b[0], b[1]));
            boolean lit = sa.isActive() && sb.isActive();
            int light = lit ? 0xFFC47A5C : 0xFF9C9C9C;
            int dark = lit ? 0xFF8F523B : 0xFF7A7A7A;
            int cx = leftPos + (sa.x + sb.x) / 2 + 8;
            int cy = topPos + (sa.y + sb.y) / 2 + 8;
            if (a[1] == b[1]) {
                graphics.fill(cx - 9, cy - 2, cx + 9, cy + 2, dark);
                graphics.fill(cx - 9, cy - 2, cx + 9, cy + 1, light);
            } else {
                graphics.fill(cx - 2, cy - 9, cx + 2, cy + 9, dark);
                graphics.fill(cx - 2, cy - 9, cx + 1, cy + 9, light);
            }
        }
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 0x404040, false);
        graphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY,
                0x404040, false);
    }
}
