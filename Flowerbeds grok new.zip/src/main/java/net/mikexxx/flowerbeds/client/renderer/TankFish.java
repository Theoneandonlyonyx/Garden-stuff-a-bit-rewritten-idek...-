package net.mikexxx.flowerbeds.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.mikexxx.flowerbeds.block.GlassPotBlock;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Bucketable;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

/**
 * Draws the fish, axolotls and tadpoles that live in a glass tank. They are real entity models, created on the
 * client only, never added to the world.
 *
 * Each swimmer wanders on its own: it picks a spot in the water of its pot, or in a joined glass pot next to,
 * above or below it, glides there with smooth turns and tilts its nose up or down as it climbs or dives, then
 * picks the next spot. Because every spot is in the same pot or in one that is joined to it, the straight line
 * to it never crosses glass. The state lives on the client only and is not saved.
 */
final class TankFish {
    private TankFish() {}

    /** How far from the pot that owns the fish (in blocks, each way) they may roam through joined pots. */
    private static final int ROAM = 6;

    private static final class Swimmer {
        final Entity entity;
        /** Half of the body size, which keeps the model clear of the glass. */
        final double half;
        final double baseSpeed;
        double x, y, z;
        double vx, vy, vz;
        double tx, ty, tz;
        BlockPos cell;
        BlockPos targetCell;
        double retargetAt;
        double speed;
        float yaw;
        float pitch;
        boolean placed;

        Swimmer(Entity entity) {
            this.entity = entity;
            this.half = Mth.clamp(entity.getBbWidth() * 0.5, 0.1, 0.25);
            String path = ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()) == null ? ""
                    : ForgeRegistries.ENTITY_TYPES.getKey(entity.getType()).getPath();
            this.baseSpeed = path.contains("axolotl") ? 0.3 : path.contains("tadpole") ? 0.25 : 0.5;
        }
    }

    private static final class Swimmers {
        int version = -1;
        double lastTime = -1;
        final List<Swimmer> list = new ArrayList<>();
        final Random random = new Random();
    }

    private static final Map<LargePotBlockEntity, Swimmers> CACHE = new WeakHashMap<>();
    private static Field waterFlag;
    private static boolean searchedWaterFlag;

    static void render(LargePotBlockEntity tank, Level level, BlockPos pos, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffers, int light) {
        List<ItemStack> buckets = tank.getFish();
        if (buckets.isEmpty() || tank.effectiveLiquid() != LargePotBlock.Liquid.WATER) {
            return;
        }
        Swimmers swimmers = CACHE.computeIfAbsent(tank, key -> new Swimmers());
        if (swimmers.version != tank.fishVersion()) {
            swimmers.version = tank.fishVersion();
            swimmers.list.clear();
            for (ItemStack bucket : buckets) {
                Entity entity = create(bucket, level);
                if (entity != null) {
                    swimmers.list.add(new Swimmer(entity));
                }
            }
        }
        double time = (level.getGameTime() + partialTick) / 20.0;
        double dt = swimmers.lastTime < 0 ? 0.0 : Mth.clamp(time - swimmers.lastTime, 0.0, 0.25);
        swimmers.lastTime = time;

        EntityRenderDispatcher dispatcher = Minecraft.getInstance().getEntityRenderDispatcher();
        dispatcher.setRenderShadow(false);
        int index = 0;
        for (Swimmer swimmer : swimmers.list) {
            step(level, pos, swimmer, swimmers.random, time, dt);
            draw(level, pos, swimmer, index++, partialTick, dt, dispatcher, poseStack, buffers);
        }
        dispatcher.setRenderShadow(true);
    }

    // ------------------------------------------------------------------------------------------ movement

    private static void step(Level level, BlockPos home, Swimmer s, Random random, double time, double dt) {
        if (!s.placed || s.cell == null || range(level, s.cell, s.half) == null) {
            place(level, home, s, random, time);
            if (!s.placed) {
                return;
            }
        }
        double[] rCell = range(level, s.cell, s.half);
        double[] rTarget = range(level, s.targetCell, s.half);
        if (rCell == null || rTarget == null) {
            s.placed = false;
            return;
        }
        double dx = s.tx - s.x;
        double dy = s.ty - s.y;
        double dz = s.tz - s.z;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 0.1 || time > s.retargetAt) {
            s.cell = s.targetCell;
            retarget(level, home, s, random, time);
            rCell = range(level, s.cell, s.half);
            rTarget = range(level, s.targetCell, s.half);
            if (rCell == null || rTarget == null) {
                s.placed = false;
                return;
            }
            dx = s.tx - s.x;
            dy = s.ty - s.y;
            dz = s.tz - s.z;
            dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        }
        if (dist > 1.0e-4 && dt > 0) {
            // Ease off a little when close to the spot, so the turn into the next leg is gentle.
            double cruise = s.speed * Mth.clamp(dist / 0.35, 0.45, 1.0);
            double blend = 1.0 - Math.exp(-dt * 1.7);
            s.vx += (dx / dist * cruise - s.vx) * blend;
            s.vy += (dy / dist * cruise - s.vy) * blend;
            s.vz += (dz / dist * cruise - s.vz) * blend;
            s.x += s.vx * dt;
            s.y += s.vy * dt;
            s.z += s.vz * dt;
        }
        double[] box = s.cell.equals(s.targetCell) ? rCell : transit(rCell, rTarget, axisOf(s.cell, s.targetCell));
        if (box != null) {
            s.x = Mth.clamp(s.x, box[0], box[1]);
            s.y = Mth.clamp(s.y, box[2], box[3]);
            s.z = Mth.clamp(s.z, box[4], box[5]);
        }
    }

    /** Puts a swimmer into its owner's pot at a random spot, or gives up if that pot has no water. */
    private static void place(Level level, BlockPos home, Swimmer s, Random random, double time) {
        double[] r = range(level, home, s.half);
        if (r == null) {
            s.placed = false;
            return;
        }
        s.cell = home;
        s.targetCell = home;
        s.x = between(random, r[0], r[1]);
        s.y = between(random, r[2], r[3]);
        s.z = between(random, r[4], r[5]);
        s.vx = s.vy = s.vz = 0;
        s.yaw = random.nextFloat() * 360.0F;
        s.pitch = 0.0F;
        s.placed = true;
        retarget(level, home, s, random, time);
    }

    /** Chooses the next spot: in this pot, or (most of the time when there is one) in a joined pot beside it. */
    private static void retarget(Level level, BlockPos home, Swimmer s, Random random, double time) {
        double[] rFrom = range(level, s.cell, s.half);
        if (rFrom == null) {
            return;
        }
        List<BlockPos> options = new ArrayList<>();
        for (BlockPos next : neighbours(level, s.cell)) {
            if (Math.abs(next.getX() - home.getX()) > ROAM || Math.abs(next.getY() - home.getY()) > ROAM
                    || Math.abs(next.getZ() - home.getZ()) > ROAM) {
                continue;
            }
            double[] rNext = range(level, next, s.half);
            if (rNext != null && transit(rFrom, rNext, axisOf(s.cell, next)) != null) {
                options.add(next);
            }
        }
        BlockPos chosen = s.cell;
        if (!options.isEmpty() && random.nextFloat() < 0.7F) {
            chosen = options.get(random.nextInt(options.size()));
        }
        double[] box;
        if (chosen.equals(s.cell)) {
            box = rFrom;
        } else {
            double[] rNext = range(level, chosen, s.half);
            int axis = axisOf(s.cell, chosen);
            double[] t = transit(rFrom, rNext, axis);
            box = new double[6];
            for (int a = 0; a < 3; a++) {
                box[2 * a] = a == axis ? rNext[2 * a] : t[2 * a];
                box[2 * a + 1] = a == axis ? rNext[2 * a + 1] : t[2 * a + 1];
            }
        }
        double nx = s.x;
        double ny = s.y;
        double nz = s.z;
        for (int attempt = 0; attempt < 5; attempt++) {
            nx = between(random, box[0], box[1]);
            ny = between(random, box[2], box[3]);
            nz = between(random, box[4], box[5]);
            double d = Math.sqrt((nx - s.x) * (nx - s.x) + (ny - s.y) * (ny - s.y) + (nz - s.z) * (nz - s.z));
            if (chosen.equals(s.cell) ? d > 0.3 : true) {
                break;
            }
        }
        s.tx = nx;
        s.ty = ny;
        s.tz = nz;
        s.targetCell = chosen;
        s.speed = s.baseSpeed * (0.7 + 0.6 * random.nextDouble());
        s.retargetAt = time + 8.0 + random.nextDouble() * 8.0;
    }

    private static double between(Random random, double lo, double hi) {
        return hi <= lo ? lo : lo + random.nextDouble() * (hi - lo);
    }

    private static boolean isWaterTank(Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof LargePotBlockEntity pot && pot.isTank()
                && pot.effectiveLiquid() == LargePotBlock.Liquid.WATER;
    }

    /** The glass pots joined to this one. Joined means the wall between the two is open. */
    private static List<BlockPos> neighbours(Level level, BlockPos cell) {
        List<BlockPos> out = new ArrayList<>(6);
        BlockState state = level.getBlockState(cell);
        if (!(state.getBlock() instanceof GlassPotBlock)) {
            return out;
        }
        if (state.getValue(LargePotBlock.NORTH)) out.add(cell.north());
        if (state.getValue(LargePotBlock.EAST)) out.add(cell.east());
        if (state.getValue(LargePotBlock.SOUTH)) out.add(cell.south());
        if (state.getValue(LargePotBlock.WEST)) out.add(cell.west());
        if (state.getValue(GlassPotBlock.UP)) out.add(cell.above());
        if (state.getValue(GlassPotBlock.DOWN)) out.add(cell.below());
        out.removeIf(p -> !isWaterTank(level, p));
        return out;
    }

    /**
     * The water a swimmer can be in inside one pot, as {minX, maxX, minY, maxY, minZ, maxZ} in world coordinates:
     * clear of closed glass walls, the floor (and the layer on it) and the water surface, but running right up
     * to a side that is open to a joined pot. Null when the pot is not a tank with water.
     */
    private static double[] range(Level level, BlockPos cell, double half) {
        if (cell == null || !(level.getBlockEntity(cell) instanceof LargePotBlockEntity pot) || !pot.isTank()
                || pot.effectiveLiquid() != LargePotBlock.Liquid.WATER) {
            return null;
        }
        BlockState state = pot.getBlockState();
        if (!(state.getBlock() instanceof GlassPotBlock)) {
            return null;
        }
        double wall = 2.0 / 16.0 + half;
        double minX = state.getValue(LargePotBlock.WEST) ? 0.0 : wall;
        double maxX = state.getValue(LargePotBlock.EAST) ? 1.0 : 1.0 - wall;
        double minZ = state.getValue(LargePotBlock.NORTH) ? 0.0 : wall;
        double maxZ = state.getValue(LargePotBlock.SOUTH) ? 1.0 : 1.0 - wall;
        double halfY = Math.min(half, 0.14);
        boolean down = state.getValue(GlassPotBlock.DOWN);
        boolean up = state.getValue(GlassPotBlock.UP) && level.getBlockEntity(cell.above()) instanceof LargePotBlockEntity above
                && above.effectiveLiquid() != LargePotBlock.Liquid.NONE;
        double minY = down ? 0.0 : pot.floorHeight() + halfY;
        double maxY = up ? 1.0 : GardenLayout.POT_WATER_TOP - halfY;
        if (minX > maxX) minX = maxX = 0.5;
        if (minZ > maxZ) minZ = maxZ = 0.5;
        if (minY > maxY) minY = maxY = (minY + maxY) * 0.5;
        return new double[] {cell.getX() + minX, cell.getX() + maxX, cell.getY() + minY, cell.getY() + maxY,
                cell.getZ() + minZ, cell.getZ() + maxZ};
    }

    /** 0 = x, 1 = y, 2 = z: the axis along which two touching pots are joined. */
    private static int axisOf(BlockPos a, BlockPos b) {
        if (a.getX() != b.getX()) return 0;
        if (a.getY() != b.getY()) return 1;
        return 2;
    }

    /**
     * The space a swimmer may use while it crosses from one pot into the next: both pots along the joining axis,
     * only what the two have in common on the other two. Null if they share nothing there.
     */
    private static double[] transit(double[] a, double[] b, int axis) {
        double[] t = new double[6];
        for (int i = 0; i < 3; i++) {
            int lo = 2 * i;
            int hi = lo + 1;
            if (i == axis) {
                t[lo] = Math.min(a[lo], b[lo]);
                t[hi] = Math.max(a[hi], b[hi]);
            } else {
                t[lo] = Math.max(a[lo], b[lo]);
                t[hi] = Math.min(a[hi], b[hi]);
                if (t[hi] < t[lo] - 1.0e-6) {
                    return null;
                }
                if (t[hi] < t[lo]) {
                    t[hi] = t[lo];
                }
            }
        }
        return t;
    }

    // ---------------------------------------------------------------------------------------------- drawing

    private static void draw(Level level, BlockPos owner, Swimmer s, int index, float partialTick, double dt,
                             EntityRenderDispatcher dispatcher, PoseStack poseStack, MultiBufferSource buffers) {
        if (!s.placed) {
            return;
        }
        double horizontal = Math.sqrt(s.vx * s.vx + s.vz * s.vz);
        double speed = Math.sqrt(horizontal * horizontal + s.vy * s.vy);
        if (speed > 0.03) {
            float wantYaw = (float) (Mth.atan2(-s.vx, s.vz) * Mth.RAD_TO_DEG);
            float wantPitch = (float) Mth.clamp(-Math.atan2(s.vy, Math.max(horizontal, 0.08)) * Mth.RAD_TO_DEG, -40.0, 40.0);
            float turn = (float) (1.0 - Math.exp(-dt * 5.0));
            s.yaw = Mth.rotLerp(turn, s.yaw, wantYaw);
            s.pitch += (wantPitch - s.pitch) * (float) (1.0 - Math.exp(-dt * 4.0));
        }
        Entity entity = s.entity;
        entity.setYRot(0.0F);
        entity.yRotO = 0.0F;
        entity.setXRot(0.0F);
        entity.xRotO = 0.0F;
        entity.tickCount = (int) level.getGameTime() + index * 7;
        if (entity instanceof LivingEntity living) {
            living.yBodyRot = 0.0F;
            living.yBodyRotO = 0.0F;
            living.yHeadRot = 0.0F;
            living.yHeadRotO = 0.0F;
            // Limbs and fins animate with the distance moved, so a gliding fish swims and a resting one does not.
            float perTick = (float) (speed / 20.0);
            living.animationSpeedOld = living.animationSpeed;
            living.animationSpeed += (Math.min(perTick * 4.0F, 1.0F) - living.animationSpeed) * 0.4F;
            living.animationPosition += living.animationSpeed * (float) (dt * 20.0);
        }
        int light = LevelRenderer.getLightColor(level, BlockPos.containing(s.x, s.y, s.z).above());
        poseStack.pushPose();
        poseStack.translate(s.x - owner.getX(), s.y - owner.getY(), s.z - owner.getZ());
        poseStack.mulPose(Axis.YP.rotationDegrees(-s.yaw));
        poseStack.mulPose(Axis.XP.rotationDegrees(s.pitch));
        // The entity's origin is at its feet; the body should turn about its middle.
        poseStack.translate(0.0, -entity.getBbHeight() * 0.5, 0.0);
        dispatcher.render(entity, 0.0, 0.0, 0.0, 0.0F, partialTick, poseStack, buffers, light);
        poseStack.popPose();
    }

    /** Builds the entity a mob bucket holds: cod_bucket gives a cod, axolotl_bucket an axolotl, and so on. */
    private static Entity create(ItemStack bucket, Level level) {
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(bucket.getItem());
        if (id == null) {
            return null;
        }
        String path = id.getPath();
        if (path.endsWith("_bucket")) {
            path = path.substring(0, path.length() - "_bucket".length());
        }
        ResourceLocation typeId = new ResourceLocation(id.getNamespace(), path);
        if (!ForgeRegistries.ENTITY_TYPES.containsKey(typeId)) {
            return null;
        }
        try {
            EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(typeId);
            Entity entity = type == null ? null : type.create(level);
            if (entity == null) {
                return null;
            }
            if (entity instanceof Bucketable bucketable && bucket.hasTag()) {
                bucketable.loadFromBucketTag(bucket.getTag());
            }
            if (entity instanceof Mob mob) {
                mob.setNoAi(true);
            }
            markInWater(entity);
            return entity;
        } catch (RuntimeException e) {
            return null;
        }
    }

    /**
     * Fish lie sideways when they are not in water. The entity is never ticked, so its "in water" flag is set by
     * hand. The field is found by trying each flag of Entity until isInWater() answers true, so this works
     * whatever the field is called.
     */
    private static void markInWater(Entity entity) {
        try {
            if (!searchedWaterFlag) {
                searchedWaterFlag = true;
                for (Field field : Entity.class.getDeclaredFields()) {
                    if (field.getType() != boolean.class || Modifier.isStatic(field.getModifiers())
                            || Modifier.isFinal(field.getModifiers())) {
                        continue;
                    }
                    field.setAccessible(true);
                    boolean old = field.getBoolean(entity);
                    field.setBoolean(entity, true);
                    boolean found = entity.isInWater();
                    field.setBoolean(entity, old);
                    if (found) {
                        waterFlag = field;
                        break;
                    }
                }
            }
            if (waterFlag != null) {
                waterFlag.setBoolean(entity, true);
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // Without the flag the fish just look a little tired.
        }
    }
}
