# Step 49 (built on 48)
- Birdbath waterlily rebuilt as small 3D flowers: sepals + 3 rings of tilted petals + stamen, or a closed bud; random turn, size, openness, colour (pink/white/cream/lilac). 1-2 per bowl.
- 4-6 pads in different sizes (3 textures, notch, veins), rim curled up. All placed inside the real water outline.
- New textures: lily_petal_*, lily_bud_*, lily_stamen, lily_sepal, lily_pad_0..2 (tools/gen_lily3d.py). Old lily_flower_* and lily_pad_small_* removed.
- Not compiled by the assistant (syntax-checked only).
