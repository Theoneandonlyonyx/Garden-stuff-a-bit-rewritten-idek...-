# Step 36 changes
- Aromatization: dropping pink petals into pink-dyed water now requires sneaking (shift + right-click). A plain right-click still plants the petals as before.
