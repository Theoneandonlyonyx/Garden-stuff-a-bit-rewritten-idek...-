# Step 42 (on step 41) - Aspect 1 of 8: aromatization only
- New item **Sakura Bathbomb** (pink powder ball with little flowers). Craft 2x2: pink petals + pink dye on top, sugar + sweet berries below.
- Right-click any water-filled pot, glass tank or birdbath with it: the water turns rosy pink AND is aromatized at once. No sneaking, no pink dye first, nothing else needed. Empty pot: a message says it needs water. Used up in survival.
- Why it did not work before: it needed pink-dyed water plus pink petals plus sneaking, a combination nobody could guess. The bathbomb sets the pink and the aroma together in the block entity (`LargePotBlockEntity.aromatize()`), which is saved and synced to the client, so the existing particles start.
- Blockstate: deliberately NOT added. The aroma lives in the block entity (it is saved and synced); a blockstate would multiply every pot's state count and change nothing about the particles.
- Pink petals still work the old way (sneak + pink water).
- Not compiled here (no Minecraft/Forge in this sandbox), syntax-checked by eye only.
- Next aspects, one zip each: 2 water spray lower, 3 particles shape, 4 notches/redstone, 5 outer walls over height, 6 vine gap/lily, 7 5x5 round, 8 substrate below + liquid colors.
