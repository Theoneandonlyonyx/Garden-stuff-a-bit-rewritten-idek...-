# Step 46 (on step 45) - Aspect 4: notches that water flows out of
- Every birdbath bowl that stands on another birdbath now has notches (indents) cut into its rim: one in the middle of each open side of a lone bath (4), 8 on the round 3x3, 12 on the round 4x4, one per outer side on other joined groups. The bowl at the bottom of a stack has none.
- Made by `tools/notch_models.py` (already run): 51 new `*_notch` models, and the blockstate picks them when `down=true`. The cut starts at 15/16 height.
- When such a bath is powered and holds water, a thin sheet of water runs out of every notch down to the bowl below (`BathNotches` + `PlantBedRenderer.renderStreams`), in the water's own colour.
- Not compiled here.
