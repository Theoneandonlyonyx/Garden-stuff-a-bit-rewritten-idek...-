# Step 38 changes (on step 37)
- China pot: the pattern is no longer one 16x16 tile wrapped around the round pot. `tools/bake_china.py` walks every face of every china pot model, works out where that face sits on the pot (angle around it and height), paints exactly that piece of one continuous blue-white design (rim band, triangle row, eight flower medallions with leaves, wave and foot band) and packs the 665 distinct pieces into one 256x256 atlas, `china_pot_atlas.png`. The 56 models now point at their own piece; geometry is unchanged. Rerun the script if the models change (the originals are kept in `tools/china_source/`).
- Faces that are a single colour use one texel, and identical pieces share one place, which keeps the atlas small.
- The five old china pot textures are removed.
- Fine China block: only pure white and three blues now (the off-white grey tint is gone).
