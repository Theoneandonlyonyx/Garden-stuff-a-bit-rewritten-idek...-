# Step 41 (on step 40)
- Crash fix: Forge "Mod Sorting failed, Detected Cycles". Both mods listed each other with `ordering = "AFTER"`. Flowerbeds now lists Ornamental Trees as optional with `ordering = "NONE"`, and Ornamental Trees no longer lists Flowerbeds at all. Use the Ornamental Trees zip from this step too.
- Ornamental Trees in pots and beds are full size (one block per 16 texture pixels, same as placed trees) and drawn as the tree mod draws them: one picture turned to the camera, never mirrored.
- The pot's draw box grows to 11 blocks wide and the tree's height while a tree stands in it, so a 7-wide cherry tree is not cut off at the screen edge.
- Not compiled here, syntax check only.
