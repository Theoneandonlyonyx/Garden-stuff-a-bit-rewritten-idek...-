# Step 50 (built on 49)
- Bathbomb icons (sakura, violet): rounder, symmetric body, stray pixels removed, tidy little flower, two sparks each.
- Aroma sparks (sakura and violet water): new symmetric 4-point sparkle sprites (aroma_spark_0..2) replace the vanilla glint.
- Waterlily: smaller flowers (about 0.17-0.24 block) and pads, softer lighter colours, lighter cream; the yellow stamen is smaller and sits low under the inner petals so it only shows from above.
- Not compiled by the assistant.
