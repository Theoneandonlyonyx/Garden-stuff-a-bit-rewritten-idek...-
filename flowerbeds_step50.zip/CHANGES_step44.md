# Step 44 (on step 43) - icon and smoke
- Bathbomb icon: two big sakura blossoms (5x5, yellow centre) sit on the ball and touch it, one top-left and one bottom-right.
- The grey "smoke" around birdbath fountains was the vanilla splash sprite (soft grey blobs). It is gone: fountain drops now use their own small blue water-drop sprites (`textures/particle/fountain_drop_0..3.png`).
- Not compiled here.
