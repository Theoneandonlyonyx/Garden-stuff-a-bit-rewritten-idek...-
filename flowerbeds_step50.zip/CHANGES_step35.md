# Step 35 changes
- Glass pots: joined (interior) posts and walls between stacked glass pots now use a new near-transparent `glass_pot_seam` texture instead of the framed `edge` texture. The vertical seam line between connected glass pots disappears. Outer cap posts keep the edge frame.
