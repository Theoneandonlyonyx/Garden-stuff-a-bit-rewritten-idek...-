"""Draws the Sakura and Violet bathbomb icons (16x16). Run: python3 tools/gen_bathbombs.py"""
import math, os
from PIL import Image
OUT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/mikexxx_flowerbeds/textures/item')

def hx(s): return tuple(int(s[i:i+2], 16) for i in (1, 3, 5)) + (255,)

PAL = {
  'sakura': dict(ramp=['#8e3d5e', '#c96b93', '#e695b6', '#f6bfd3', '#fde3ec'], band=['#fff4f8', '#f9d2e0'],
                 fleck='#c45a84', petal=['#ffffff', '#ffd0e0', '#f59cbc'], heart='#ffd24a', spark='#ffffff'),
  'violet': dict(ramp=['#37205f', '#6a43a6', '#8f68cf', '#b894ea', '#dcc6fa'], band=['#f1e8ff', '#cdb4f2'],
                 fleck='#59399a', petal=['#f3e9ff', '#b58be6', '#7a49c2'], heart='#ffe45c', spark='#ffffff'),
}

def make(name):
    p = PAL[name]; img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    cx, cy, r = 7.5, 9.2, 5.9
    ramp = [hx(c) for c in p['ramp']]
    inside = lambda x, y, rr: math.hypot(x + 0.5 - cx, y + 0.5 - cy) <= rr
    for y in range(16):
        for x in range(16):
            if not inside(x, y, r): continue
            dx, dy = (x + 0.5 - cx) / r, (y + 0.5 - cy) / r
            nz = math.sqrt(max(0, 1 - dx * dx - dy * dy))
            lam = -0.5 * dx - 0.6 * dy + 0.62 * nz
            lvl = 4 if lam > 0.80 else 3 if lam > 0.50 else 2 if lam > 0.22 else 1
            if not inside(x, y, r - 1.0): lvl = 0 if lam < 0.35 else 1
            img.putpixel((x, y), ramp[lvl])
    b1, b2 = hx(p['band'][0]), hx(p['band'][1])
    for y in range(16):
        for x in range(16):
            if not inside(x, y, r - 1.0): continue
            t = (y + 0.5 - cy) + 0.55 * (x + 0.5 - cx)
            if -0.9 <= t < 0.7: img.putpixel((x, y), b1)
            elif 0.7 <= t < 1.6: img.putpixel((x, y), b2)
    for (x, y) in [(5, 12), (10, 10)]:
        img.putpixel((x, y), hx(p['fleck']))
    fx, fy = 9, 3
    pw, pm, pd = [hx(c) for c in p['petal']]
    for (ox, oy) in [(0, -1), (-1, 0), (1, 0), (0, 1)]: img.putpixel((fx + ox, fy + oy), pm)
    for (ox, oy) in [(-1, -1), (1, -1)]: img.putpixel((fx + ox, fy + oy), pw)
    for (ox, oy) in [(-1, 1), (1, 1)]: img.putpixel((fx + ox, fy + oy), pd)
    img.putpixel((fx, fy), hx(p['heart']))
    s = hx(p['spark']); sd = hx(p['band'][1])
    for (ox, oy) in [(-1, 0), (1, 0), (0, -1), (0, 1)]: img.putpixel((2 + ox, 4 + oy), sd)
    img.putpixel((2, 4), s)
    img.putpixel((14, 12), s)
    return img

if __name__ == '__main__':
    for n in PAL:
        make(n).save(os.path.join(OUT, n + '_bathbomb.png'))
