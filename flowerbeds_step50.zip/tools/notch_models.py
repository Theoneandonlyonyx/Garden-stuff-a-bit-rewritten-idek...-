#!/usr/bin/env python3
"""
Step 46: cuts the fountain notches (indents) into the rim of every birdbath bowl model and writes the matching
blockstate parts. A notched model is used when a birdbath stands on another birdbath (state down=true); the bowl
under it has no notches. Notches: 4 on a lone bath (middle of every open side), 8 on the round 3x3, 12 on the round
4x4, one in the middle of each outer side of every other block. Run once from the project root:
    python3 tools/notch_models.py
"""
import json, math, os, re, glob

A = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src/main/resources/assets/mikexxx_flowerbeds")
M = os.path.join(A, "models/block")
NOTCH_Y = 15.0
HALF = 1.7  # half width of a notch in px


def windows_for(name):
    w = []
    m = re.fullmatch(r"silver_birdbath_([01]{4})_([01]{4})", name)
    if m:
        n, e, s, wst = [c == "1" for c in m.group(1)]
        if not n: w.append((8 - HALF, 0, 8 + HALF, 2.8))
        if not s: w.append((8 - HALF, 13.2, 8 + HALF, 16))
        if not wst: w.append((0, 8 - HALF, 2.8, 8 + HALF))
        if not e: w.append((13.2, 8 - HALF, 16, 8 + HALF))
        return w
    m = re.fullmatch(r"silver_birdbath_round_(nw|n|ne|w|e|sw|s|se)", name)
    if m:
        i, j = {"nw": (0, 0), "n": (1, 0), "ne": (2, 0), "w": (0, 1), "e": (2, 1), "sw": (0, 2), "s": (1, 2), "se": (2, 2)}[m.group(1)]
        return ring(i, j, 24.0, 23.2, [k * 45.0 for k in range(8)])
    m = re.fullmatch(r"silver_birdbath_round4_([0-3])([0-3])", name)
    if m:
        i, j = int(m.group(1)), int(m.group(2))
        return ring(i, j, 32.0, 31.2, [15.0 + k * 30.0 for k in range(12)])
    return None


def ring(i, j, c, r, angles):
    out = []
    for a in angles:
        x = c + r * math.cos(math.radians(a)) - 16 * i
        z = c + r * math.sin(math.radians(a)) - 16 * j
        if 0.5 <= x < 15.5 and 0.5 <= z < 15.5:
            out.append((x - HALF, z - HALF, x + HALF, z + HALF))
    return out


def sub(face_name, p, s, uv):
    """uv of the sub-box face s inside parent p."""
    wx, wy, wz = (p[1][0] - p[0][0]), (p[1][1] - p[0][1]), (p[1][2] - p[0][2])
    def fr(v0, v1, lo, hi, rev=False):
        d = hi - lo
        if d < 1e-9: return 0.0, 1.0
        a, b = (v0 - lo) / d, (v1 - lo) / d
        return (1 - b, 1 - a) if rev else (a, b)
    if face_name == "north": t = fr(s[0][0], s[1][0], p[0][0], p[1][0], True); v = fr(s[0][1], s[1][1], p[0][1], p[1][1], True)
    elif face_name == "south": t = fr(s[0][0], s[1][0], p[0][0], p[1][0]); v = fr(s[0][1], s[1][1], p[0][1], p[1][1], True)
    elif face_name == "east": t = fr(s[0][2], s[1][2], p[0][2], p[1][2], True); v = fr(s[0][1], s[1][1], p[0][1], p[1][1], True)
    elif face_name == "west": t = fr(s[0][2], s[1][2], p[0][2], p[1][2]); v = fr(s[0][1], s[1][1], p[0][1], p[1][1], True)
    else: t = fr(s[0][0], s[1][0], p[0][0], p[1][0]); v = fr(s[0][2], s[1][2], p[0][2], p[1][2])
    u0, v0, u1, v1 = uv
    return [round(u0 + (u1 - u0) * t[0], 4), round(v0 + (v1 - v0) * v[0], 4),
            round(u0 + (u1 - u0) * t[1], 4), round(v0 + (v1 - v0) * v[1], 4)]


def cut(el, win):
    f, t = el["from"], el["to"]
    ix0, ix1 = max(f[0], win[0]), min(t[0], win[2])
    iy0, iy1 = max(f[1], NOTCH_Y), min(t[1], 16.0)
    iz0, iz1 = max(f[2], win[1]), min(t[2], win[3])
    if ix0 >= ix1 - 1e-6 or iy0 >= iy1 - 1e-6 or iz0 >= iz1 - 1e-6:
        return [el]
    boxes = []
    if iy0 > f[1]: boxes.append(([f[0], f[1], f[2]], [t[0], iy0, t[2]]))
    if iy1 < t[1]: boxes.append(([f[0], iy1, f[2]], [t[0], t[1], t[2]]))
    if ix0 > f[0]: boxes.append(([f[0], iy0, f[2]], [ix0, iy1, t[2]]))
    if ix1 < t[0]: boxes.append(([ix1, iy0, f[2]], [t[0], iy1, t[2]]))
    if iz0 > f[2]: boxes.append(([ix0, iy0, f[2]], [ix1, iy1, iz0]))
    if iz1 < t[2]: boxes.append(([ix0, iy0, iz1], [ix1, iy1, t[2]]))
    out = []
    ref = next(iter(el["faces"].values()))
    for lo, hi in boxes:
        faces = {}
        for name in ("north", "south", "east", "west", "up", "down"):
            ax = {"north": (2, 0), "south": (2, 1), "east": (0, 1), "west": (0, 0), "up": (1, 1), "down": (1, 0)}[name]
            on_edge = abs((hi if ax[1] else lo)[ax[0]] - (t if ax[1] else f)[ax[0]]) < 1e-6
            if name in el["faces"] and on_edge:
                fc = dict(el["faces"][name])
                if "uv" in fc:
                    fc["uv"] = sub(name, (f, t), (lo, hi), fc["uv"])
                faces[name] = fc
            elif not on_edge:
                faces[name] = {"uv": [0, 0, 2, 2] if name not in ("up", "down") else [lo[0] % 16, lo[2] % 16, hi[0] % 16 or 16, hi[2] % 16 or 16],
                               "texture": "#inner" if name not in ("down",) else "#top"}
        o = {k: v for k, v in el.items() if k not in ("from", "to", "faces")}
        o["from"] = [round(x, 4) for x in lo]
        o["to"] = [round(x, 4) for x in hi]
        o["faces"] = faces
        out.append(o)
    return out


def main():
    notched = set()
    for path in sorted(glob.glob(os.path.join(M, "silver_birdbath_*.json"))):
        name = os.path.basename(path)[:-5]
        if name.endswith("_notch"):
            continue
        wins = windows_for(name)
        if not wins:
            continue
        d = json.load(open(path))
        els = d["elements"]
        for win in wins:
            nxt = []
            for e in els:
                nxt += cut(e, win)
            els = nxt
        d["elements"] = els
        json.dump(d, open(os.path.join(M, name + "_notch.json"), "w"), separators=(",", ":"))
        notched.add(name)
    bs_path = os.path.join(A, "blockstates/silver_birdbath.json")
    bs = json.load(open(bs_path))
    parts = []
    for p in bs["multipart"]:
        model = p["apply"]["model"].split("/")[-1]
        if model in notched and "down" not in p.get("when", {}):
            a = json.loads(json.dumps(p)); a["when"]["down"] = "false"
            b = json.loads(json.dumps(p)); b["when"]["down"] = "true"
            b["apply"]["model"] += "_notch"
            parts += [a, b]
        else:
            parts.append(p)
    bs["multipart"] = parts
    json.dump(bs, open(bs_path, "w"), indent=1)
    print("notched models:", len(notched), "blockstate parts:", len(parts))


if __name__ == "__main__":
    main()
