"""Cuts the three big flowers out of the vanilla cherry_leaves texture (thick +, no corner pixels) and recolours each
into several pink schemes. Run: python3 tools/gen_cherry_flowers.py path/to/cherry_leaves.png
Writes textures/particle/cherry_flower_<flower>_<scheme>.png and the particle json."""
import json, os, sys
from PIL import Image

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/mikexxx_flowerbeds')
CENTRES = [(3, 4), (12, 8), (6, 12)]
# light, mid, dark stops of each scheme
RAMPS = {
    'soft': ((255, 238, 246), (251, 196, 226), (238, 136, 186)),
    'pink': ((255, 224, 240), (247, 152, 202), (226, 84, 152)),
    'hot': ((255, 204, 228), (245, 112, 172), (212, 42, 112)),
    'rose': ((250, 210, 220), (232, 134, 156), (194, 72, 104)),
    'peach': ((255, 234, 222), (252, 184, 170), (232, 122, 128)),
}
# which schemes each flower gets: peach is rare (two of fourteen sprites)
SCHEMES = [['soft', 'pink', 'hot', 'rose', 'peach'], ['soft', 'pink', 'hot', 'rose'], ['soft', 'pink', 'hot', 'rose', 'peach']]


def lerp(a, b, t):
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def ramp(stops, t):
    return lerp(stops[0], stops[1], t * 2) if t < 0.5 else lerp(stops[1], stops[2], (t - 0.5) * 2)


def main(path):
    src = Image.open(path).convert('RGBA')
    out_dir = os.path.join(ROOT, 'textures/particle')
    names = []
    for f, (cx, cy) in enumerate(CENTRES):
        px = {}
        for dy in range(-3, 4):
            for dx in range(-3, 4):
                if abs(dx) > 1 and abs(dy) > 1:
                    continue  # the armpits
                x, y = cx + dx, cy + dy
                if 0 <= x < 16 and 0 <= y < 16:
                    p = src.getpixel((x, y))
                    if p[3] and p[0] >= p[1]:  # not transparent, not leaf green
                        px[(dx + 3, dy + 3)] = p
        lum = {k: sum(v[:3]) for k, v in px.items()}
        lo, hi = min(lum.values()), max(lum.values())
        for scheme in SCHEMES[f]:
            im = Image.new('RGBA', (8, 8), (0, 0, 0, 0))
            for k, v in px.items():
                t = (hi - lum[k]) / max(1, hi - lo)  # 0 = lightest petal, 1 = darkest centre
                im.putpixel(k, ramp(RAMPS[scheme], 0.3 + 0.7 * t) + (255,))
            name = 'cherry_flower_%d_%s' % (f, scheme)
            im.save(os.path.join(out_dir, name + '.png'))
            names.append(name)
    with open(os.path.join(ROOT, 'particles/aroma_petal.json'), 'w') as fh:
        json.dump({'textures': ['mikexxx_flowerbeds:' + n for n in names]}, fh)
    print(len(names), 'sprites')


if __name__ == '__main__':
    main(sys.argv[1])
