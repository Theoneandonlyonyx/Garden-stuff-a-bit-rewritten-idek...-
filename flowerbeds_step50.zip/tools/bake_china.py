#!/usr/bin/env python3
"""
Paints the blue-white china pot by hand-made mini textures instead of wrapping one 16x16 tile around it.

The round pot is built from hundreds of tiny stair-step slabs, so a single tile wrapped around it cuts the
pattern at every step. This script walks every face of every china_pot_*.json model, works out where that face
sits on the pot (angle around the pot and height), paints exactly that piece of one continuous design and packs
all the pieces into one atlas (china_pot_atlas.png). The faces then point at their own piece.

It reads the ORIGINAL geometry, so it can be rerun at any time:  python3 tools/bake_china.py
(the first run saves the untouched models in tools/china_source/).
"""
import glob, json, math, os, shutil
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
ASSETS = os.path.join(ROOT, "src/main/resources/assets/mikexxx_flowerbeds")
MODELS = os.path.join(ASSETS, "models/block")
TEX = os.path.join(ASSETS, "textures/block")
SRC = os.path.join(ROOT, "tools/china_source")
MODID = "mikexxx_flowerbeds"

WHITE = (255, 255, 255)
LIGHT = (160, 188, 240)
BLUE = (52, 96, 204)
DEEP = (24, 52, 140)
PALETTE = [WHITE, LIGHT, BLUE, DEEP]

DENSITY = 1          # texels per block unit
SS = 3               # samples per texel side
REPEATS = 8          # motifs around the pot
GUTTER = 1


def nearest(rgb):
    return min(PALETTE, key=lambda p: sum((a - b) ** 2 for a, b in zip(p, rgb)))


# ------------------------------------------------------------------------------------------------ the design

def tri(t):
    t = t - math.floor(t)
    return abs(t - 0.5) * 2.0


def outer(phi, y):
    """phi 0..1 around the pot (motif centre at 0.5), y in block units. Returns a palette colour."""
    if y >= 15.0:
        return DEEP
    if y >= 14.2:
        return BLUE if y >= 14.55 else WHITE
    if y >= 12.4:
        # row of triangles hanging from the line below the rim
        t = tri(phi * 2.0)
        return BLUE if (14.2 - y) / 1.8 > t * 0.95 else (LIGHT if (14.2 - y) / 1.8 > t * 0.95 - 0.18 else WHITE)
    if y >= 11.7:
        return BLUE if y < 12.1 else WHITE
    if y >= 4.4:
        P = 2 * math.pi * 7.0 / REPEATS
        u = (phi - 0.5) * P
        v = y - 8.1
        # flower medallion
        r = math.hypot(u, v)
        ang = math.atan2(v, u)
        petal = 1.55 + 0.9 * math.cos(5 * ang)
        if r < 0.55:
            return WHITE
        if r < petal * 0.5:
            return DEEP
        if r < petal:
            return BLUE
        if r < petal + 0.45:
            return LIGHT
        # curling leaves left and right of the flower
        for side in (-1, 1):
            lu = (abs(u) - 2.15)
            if lu > -0.3 and abs(u) < P / 2.0 + 0.1:
                lv = v - side * 0.0
                if abs(lv) < 1.9 * (1.0 - abs(lu + 0.3) * 0.55):
                    return LIGHT if abs(lv) > 0.4 else BLUE
        # small dots above and below, at the seam between two medallions
        w = (phi * 1.0) - math.floor(phi + 0.5)
        us = w * P
        for dy in (-2.6, 2.6, 0.0):
            if math.hypot(us, v - dy) < 0.65:
                return BLUE
        return WHITE
    if y >= 3.5:
        return BLUE if y < 3.9 else WHITE
    if y >= 1.9:
        wave = 2.75 + 0.45 * math.sin(phi * 2 * math.pi * 2)
        return BLUE if y < wave else (LIGHT if y < wave + 0.3 else WHITE)
    if y >= 1.2:
        return WHITE
    return DEEP if y < 0.9 else BLUE


def top_face(x, y, z):
    """Rims, steps and the foot seen from above or below."""
    r = math.hypot(x - 8, z - 8)
    if y >= 15.9:
        return DEEP if r > 6.0 else BLUE
    return WHITE


def inner_face(x, y, z):
    """Inside of the pot: white, with a thin blue line under the rim."""
    if y >= 14.4 and y < 15.4:
        return LIGHT
    return WHITE


def paint(kind, x, y, z):
    if kind == "inner":
        return inner_face(x, y, z)
    if kind == "top":
        return top_face(x, y, z)
    theta = math.atan2(z - 8.0, x - 8.0)
    phi = (theta / (2 * math.pi)) * REPEATS
    phi = phi - math.floor(phi)
    return outer(phi, y)


# ------------------------------------------------------------------------------------------------ geometry

def corner(frm, to, direction, fu, fv):
    """3D point at fractions fu (left to right) and fv (top to bottom) of a face, in the way model uv runs."""
    x0, y0, z0 = frm
    x1, y1, z1 = to
    def lerp(a, b, f):
        return a + (b - a) * f
    if direction == "north":
        return lerp(x1, x0, fu), lerp(y1, y0, fv), z0
    if direction == "south":
        return lerp(x0, x1, fu), lerp(y1, y0, fv), z1
    if direction == "west":
        return x0, lerp(y1, y0, fv), lerp(z0, z1, fu)
    if direction == "east":
        return x1, lerp(y1, y0, fv), lerp(z1, z0, fu)
    if direction == "up":
        return lerp(x0, x1, fu), y1, lerp(z0, z1, fv)
    return lerp(x0, x1, fu), y0, lerp(z1, z0, fv)  # down


def face_size(frm, to, direction):
    dx, dy, dz = (to[i] - frm[i] for i in range(3))
    if direction in ("north", "south"):
        return dx, dy
    if direction in ("west", "east"):
        return dz, dy
    return dx, dz


def kind_of(texture_name):
    return {"inner": "inner", "top": "top"}.get(texture_name, "outer")


def bake_face(kind, frm, to, direction):
    w, h = face_size(frm, to, direction)
    tw = max(1, round(w * DENSITY))
    th = max(1, round(h * DENSITY))
    img = Image.new("RGB", (tw, th))
    px = img.load()
    for j in range(th):
        for i in range(tw):
            acc = [0, 0, 0]
            for sj in range(SS):
                for si in range(SS):
                    fu = (i + (si + 0.5) / SS) / tw
                    fv = (j + (sj + 0.5) / SS) / th
                    x, y, z = corner(frm, to, direction, fu, fv)
                    c = paint(kind, x, y, z)
                    for k in range(3):
                        acc[k] += c[k]
            n = SS * SS
            px[i, j] = nearest((acc[0] / n, acc[1] / n, acc[2] / n))
    return img


# ------------------------------------------------------------------------------------------------ run

def main():
    os.makedirs(SRC, exist_ok=True)
    files = sorted(glob.glob(os.path.join(MODELS, "china_pot_*.json")))
    for f in files:
        keep = os.path.join(SRC, os.path.basename(f))
        if not os.path.exists(keep):
            shutil.copy(f, keep)
    sources = sorted(glob.glob(os.path.join(SRC, "china_pot_*.json")))

    patches = {}
    for f in sources:
        m = json.load(open(f))
        for el in m["elements"]:
            for d, face in el["faces"].items():
                tex = face["texture"].lstrip("#")
                key = (kind_of(tex), tuple(el["from"]), tuple(el["to"]), d)
                if key not in patches:
                    patches[key] = bake_face(*key)
    print("models:", len(sources), "unique faces:", len(patches))

    # A face that is a single colour needs only one texel, and identical pieces share one place in the atlas.
    # Pieces are painted in a Python dict keyed by content, so the atlas stays small.
    shared = {}
    owner = {}
    for key, im in patches.items():
        colors = set(im.getdata())
        if len(colors) == 1:
            im = Image.new("RGB", (1, 1), next(iter(colors)))
        sig = (im.size, im.tobytes())
        if sig not in shared:
            shared[sig] = im
        owner[key] = sig
    print("distinct pieces:", len(shared))

    items = sorted(shared.items(), key=lambda kv: (-kv[1].size[1], -kv[1].size[0]))
    area = sum((im.size[0] + 2 * GUTTER) * (im.size[1] + 2 * GUTTER) for _, im in items)
    side = 32
    while side * side < area * 1.12:
        side *= 2
    while True:
        placed, x, y, shelf = {}, 0, 0, 0
        ok = True
        for sig, im in items:
            w, h = im.size[0] + 2 * GUTTER, im.size[1] + 2 * GUTTER
            if x + w > side:
                x, y, shelf = 0, y + shelf, 0
            if y + h > side:
                ok = False
                break
            placed[sig] = (x + GUTTER, y + GUTTER)
            x += w
            shelf = max(shelf, h)
        if ok:
            break
        side *= 2
    atlas = Image.new("RGBA", (side, side), WHITE + (255,))
    for sig, im in items:
        ox, oy = placed[sig]
        w, h = im.size
        # replicate the edge texels into the gutter so filtering never picks up a neighbour
        for gy in range(-GUTTER, h + GUTTER):
            for gx in range(-GUTTER, w + GUTTER):
                sx = min(max(gx, 0), w - 1)
                sy = min(max(gy, 0), h - 1)
                atlas.putpixel((ox + gx, oy + gy), im.getpixel((sx, sy)) + (255,))
    atlas.save(os.path.join(TEX, "china_pot_atlas.png"))
    print("atlas:", side, "x", side)

    scale = 16.0 / side
    for f in sources:
        m = json.load(open(f))
        for el in m["elements"]:
            for d, face in list(el["faces"].items()):
                tex = face["texture"].lstrip("#")
                key = (kind_of(tex), tuple(el["from"]), tuple(el["to"]), d)
                sig = owner[key]
                ox, oy = placed[sig]
                w, h = shared[sig].size
                face["texture"] = "#china"
                face["uv"] = [round(ox * scale, 5), round(oy * scale, 5),
                              round((ox + w) * scale, 5), round((oy + h) * scale, 5)]
        m["textures"] = {"china": "%s:block/china_pot_atlas" % MODID, "particle": "%s:block/china_pot_atlas" % MODID}
        with open(os.path.join(MODELS, os.path.basename(f)), "w") as out:
            json.dump(m, out, separators=(",", ":"))

    # fine china: pure white and blue
    fc = Image.open(os.path.join(TEX, "fine_china_source.png") if os.path.exists(os.path.join(TEX, "fine_china_source.png"))
                    else os.path.join(TEX, "fine_china.png")).convert("RGBA")
    out = Image.new("RGBA", fc.size)
    for yy in range(fc.size[1]):
        for xx in range(fc.size[0]):
            r, g, b, a = fc.getpixel((xx, yy))
            out.putpixel((xx, yy), nearest((r, g, b)) + (255,))
    out.save(os.path.join(TEX, "fine_china.png"))


if __name__ == "__main__":
    main()
