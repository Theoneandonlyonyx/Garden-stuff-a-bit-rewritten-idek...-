#!/usr/bin/env python3
"""Draws the textures of the birdbath waterlily patch (petals, buds, stamens, sepals, pads).

    python3 tools/gen_lily3d.py [textures/block dir]

The 3D shape is built in code (PlantBedRenderer.drawLilies): tilted petal planes in rings, a stamen disc,
sepals and pads with a raised rim. The same maths lives in tools/lily_preview.py for the drafts.
"""
import math
import os
import sys
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, '..', 'src/main/resources/assets/mikexxx_flowerbeds/textures/block')


def hx(s, a=255):
    return (int(s[1:3], 16), int(s[3:5], 16), int(s[5:7], 16), a)


def mix(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(4))


BAYER = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]


def dither(x, y, t):
    """0/1 pick for blending two colours with an ordered pattern (pixel-art banding instead of a smooth fade)."""
    return 1.0 if (BAYER[y % 4][x % 4] + 0.5) / 16.0 < t else 0.0


PALETTES = {
    'pink':  dict(tip='#f08db3', mid='#f8bdd3', base='#fff6f8', edge='#e07aa2', vein='#ffeef4', glow='#fffafc'),
    'white': dict(tip='#eef2f8', mid='#fafcff', base='#ffffff', edge='#c6d2de', vein='#ffffff', glow='#ffffff'),
    'cream': dict(tip='#f8e6a6', mid='#fdf2c8', base='#fffcf0', edge='#ecd68f', vein='#fffbe8', glow='#fffef6'),
    'lilac': dict(tip='#9b80e0', mid='#c4b0f2', base='#f8f3ff', edge='#8467c6', vein='#f0e8ff', glow='#fbf8ff'),
}


def petal(pal):
    """A pointed petal, tip at the top, pale at the base, a lighter vein and a darker edge."""
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    tip, mid, base, edge, vein, glow = (hx(pal[k]) for k in ('tip', 'mid', 'base', 'edge', 'vein', 'glow'))
    # half width per row, from the tip (row 0) to the base (row 15)
    widths = [0.6, 1.3, 2.0, 2.8, 3.5, 4.1, 4.5, 4.7, 4.6, 4.3, 3.9, 3.4, 2.9, 2.4, 2.0, 1.6]
    for y in range(16):
        w = widths[y]
        for x in range(16):
            dx = x + 0.5 - 8.0
            if abs(dx) > w:
                continue
            t = y / 15.0  # 0 tip .. 1 base
            if t < 0.45:
                c = mix(tip, mid, dither(x, y, t / 0.45))
            else:
                c = mix(mid, base, dither(x, y, (t - 0.45) / 0.55))
            if abs(dx) > w - 0.95:
                c = mix(c, edge, 0.3 if y > 1 else 0.5)
            elif abs(dx) < 0.55 and 2 < y < 13:
                c = mix(c, vein, 0.8)
            elif abs(dx) < 1.5 and 3 < y < 11 and dither(x, y, 0.35):
                c = mix(c, glow, 0.45)
            img.putpixel((x, y), c)
    return img


def bud(pal):
    """A closed bud, upright: a teardrop with overlapping petals and a green cup at the bottom."""
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    tip, mid, base, edge, vein = (hx(pal[k]) for k in ('tip', 'mid', 'base', 'edge', 'vein'))
    g1, g2 = hx('#4f9f48'), hx('#3a7d37')
    widths = [0.5, 1.2, 2.0, 2.7, 3.2, 3.5, 3.6, 3.5, 3.2, 2.7, 2.0, 0, 0, 0, 0, 0]
    for y in range(11):
        w = widths[y]
        for x in range(16):
            dx = x + 0.5 - 8.0
            if abs(dx) > w:
                continue
            t = y / 10.0
            c = mix(tip, mid, dither(x, y, t * 1.2)) if t < 0.6 else mix(mid, base, dither(x, y, (t - 0.6) * 2.0))
            if abs(dx) > w - 0.9:
                c = mix(c, edge, 0.6)
            if abs(dx) < 0.5 and 2 < y < 9:  # the seam where two petals meet
                c = mix(c, edge, 0.35)
            img.putpixel((x, y), c)
    for y in range(9, 15):  # cup of sepals
        w = [2.2, 3.4, 3.9, 3.4, 2.4, 1.2][y - 9]
        for x in range(16):
            dx = x + 0.5 - 8.0
            if abs(dx) <= w:
                c = g1 if abs(dx) < w - 0.9 else g2
                if y == 9 and abs(dx) > 1.0:
                    continue
                img.putpixel((x, y), c)
    return img


def stamen():
    """Seen from above: a golden ring of stamens, orange tips, a green-gold heart."""
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    gold, deep, tip, heart = hx('#ffd23c'), hx('#f0a81c'), hx('#ff8a1e'), hx('#c9a52a')
    for y in range(16):
        for x in range(16):
            d = math.hypot(x + 0.5 - 8.0, y + 0.5 - 8.0)
            if d <= 3.0:
                img.putpixel((x, y), heart if d < 1.6 else deep)
            elif d <= 5.0:
                img.putpixel((x, y), gold if (x + y) % 2 == 0 else deep)
    for k in range(12):
        a = k * math.pi / 6.0
        for r in (5.0, 6.0, 7.0):
            x, y = int(8 + math.cos(a) * r), int(8 + math.sin(a) * r)
            if 0 <= x < 16 and 0 <= y < 16:
                img.putpixel((x, y), tip if r >= 6.0 else gold)
    return img


def sepal():
    """A narrow green sepal, tip up. Four of them lie under the petals."""
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    g, d, l = hx('#3f8f3a'), hx('#2b6a2a'), hx('#6cbd4a')
    widths = [0.5, 1.1, 1.7, 2.2, 2.5, 2.6, 2.5, 2.3, 2.0, 1.7, 1.3, 1.0, 0.8, 0.6, 0.5, 0.5]
    for y in range(16):
        for x in range(16):
            dx = x + 0.5 - 8.0
            if abs(dx) <= widths[y]:
                c = g
                if abs(dx) > widths[y] - 0.8:
                    c = d
                elif abs(dx) < 0.5:
                    c = l
                img.putpixel((x, y), c)
    return img


def pad(notch_deg, variant):
    """A pad seen from above: a ring of darker rim, veins out of the middle, a lit patch, a V-shaped notch."""
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    rim = [hx('#2c6a2b'), hx('#3d6b25'), hx('#5a5a22')][variant]
    body = [hx('#3f9a3b'), hx('#4aa23f'), hx('#5aa83a')][variant]
    lit = [hx('#78cc58'), hx('#86d45f'), hx('#9bd860')][variant]
    vein = [hx('#2f7a2e'), hx('#2f7a2e'), hx('#3d7a2a')][variant]
    cx = cy = 7.5
    for y in range(16):
        for x in range(16):
            dx, dy = x - cx, y - cy
            d = math.hypot(dx, dy)
            if d > 7.6:
                continue
            ang = (math.degrees(math.atan2(dy, dx)) - notch_deg + 540) % 360 - 180
            if abs(ang) < 15.0 and d > 1.2:
                continue
            c = body
            if d > 6.2:
                c = rim
            else:
                for k in range(9):
                    va = math.radians(notch_deg + 20 + k * 40)
                    # distance of the pixel from the vein line
                    px, py = math.cos(va), math.sin(va)
                    along = dx * px + dy * py
                    across = abs(-dx * py + dy * px)
                    if 0.8 < along < 5.6 and across < 0.55:
                        c = mix(body, vein, 0.8)
                lx, ly = dx + 2.0, dy + 2.2  # light from the top left
                if math.hypot(lx, ly) < 3.4 and c == body and dither(x, y, 0.55):
                    c = lit
            img.putpixel((x, y), c)
    if variant == 2:  # a tiny torn corner and a droplet
        img.putpixel((11, 4), (255, 255, 255, 230))
    return img


def main():
    os.makedirs(OUT, exist_ok=True)
    for name, pal in PALETTES.items():
        petal(pal).save(os.path.join(OUT, 'lily_petal_%s.png' % name))
        bud(pal).save(os.path.join(OUT, 'lily_bud_%s.png' % name))
    stamen().save(os.path.join(OUT, 'lily_stamen.png'))
    sepal().save(os.path.join(OUT, 'lily_sepal.png'))
    for i, (deg, v) in enumerate([(35, 0), (200, 1), (300, 2)]):
        pad(deg, v).save(os.path.join(OUT, 'lily_pad_%d.png' % i))
    print('lily textures written to', OUT)


if __name__ == '__main__':
    main()
