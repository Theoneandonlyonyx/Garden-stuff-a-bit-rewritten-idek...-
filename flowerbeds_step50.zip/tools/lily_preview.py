#!/usr/bin/env python3
"""Draft preview of the birdbath lily patch (mirrors drawLilies maths). python3 tools/lily_preview.py out.png [seeds]"""
import math, os, random, sys
from PIL import Image, ImageDraw
T = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src/main/resources/assets/mikexxx_flowerbeds/textures/block/')
cache = {}
def tex(n):
    if n not in cache: cache[n] = Image.open(T + n + '.png').convert('RGBA')
    return cache[n]
polys = []
def quad(img, P, uvs=None):
    """P: 4 corners base-left, base-right, tip-right, tip-left (u0v1,u1v1,u1v0,u0v0)"""
    t = tex(img)
    for i in range(16):
        for j in range(16):
            c = t.getpixel((i, j))
            if c[3] < 20: continue
            def pt(a, b):  # a along u, b along v(0 top)
                bl = [P[0][k] + (P[1][k] - P[0][k]) * a for k in range(3)]
                tl = [P[3][k] + (P[2][k] - P[3][k]) * a for k in range(3)]
                return [tl[k] + (bl[k] - tl[k]) * b for k in range(3)]
            q = [pt(i / 16, j / 16), pt((i + 1) / 16, j / 16), pt((i + 1) / 16, (j + 1) / 16), pt(i / 16, (j + 1) / 16)]
            polys.append((q, c))
def petal(img, x, y, z, yaw, tilt, L, W):
    dx, dz = math.cos(yaw), math.sin(yaw); r, h = math.cos(tilt) * L, math.sin(tilt) * L
    sx, sz = -dz * W / 2, dx * W / 2; tx, tz = x + dx * r, z + dz * r
    quad(img, [(x - sx / 2, y, z - sz / 2), (x + sx / 2, y, z + sz / 2), (tx + sx, y + h, tz + sz), (tx - sx, y + h, tz - sz)])
def pad(img, cx, y, cz, size, ang):
    h = size / 2; lift = size * .07; e = [-1, -1 / 3, 1 / 3, 1]; c, s = math.cos(ang), math.sin(ang)
    def v(i, j):
        lx, lz = e[i] * h, e[j] * h; rim = i in (0, 3) or j in (0, 3)
        return (cx + lx * c - lz * s, y + (lift if rim else 0), cz + lx * s + lz * c)
    t = tex(img)
    for i in range(3):
        for j in range(3):
            a = [v(i, j), v(i, j + 1), v(i + 1, j + 1), v(i + 1, j)]
            for u in range(5):
                for w in range(5):
                    px = int((i / 3 + u / 15) * 16); py = int((j / 3 + w / 15) * 16)
                    col = t.getpixel((min(15, px), min(15, py)))
                    if col[3] < 20: continue
                    f = lambda p, q: [a[0][k] + (a[3][k] - a[0][k]) * p + (a[1][k] - a[0][k]) * q + (a[2][k] - a[3][k] - a[1][k] + a[0][k]) * p * q for k in range(3)]
                    polys.append(([f(u / 5, w / 5), f((u + 1) / 5, w / 5), f((u + 1) / 5, (w + 1) / 5), f(u / 5, (w + 1) / 5)], col))
def flower(cx, y, cz, size, yaw, rnd, color):
    s = size / 2
    if rnd.randrange(4) == 0:
        for k in range(2):
            a = yaw + k * math.pi / 2; dx, dz = math.cos(a) * s * .62, math.sin(a) * s * .62
            quad('lily_bud_' + color, [(cx - dx, y, cz - dz), (cx + dx, y, cz + dz), (cx + dx, y + s * 1.05, cz + dz), (cx - dx, y + s * 1.05, cz - dz)])
        return
    o = rnd.random()
    for k in range(4): petal('lily_sepal', cx, y, cz, yaw + .8 + k * math.pi / 2, .2, s * .8, s * .28)
    n = 7 + rnd.randrange(3); sp = rnd.random() * 6.283
    for k in range(n): petal('lily_petal_' + color, cx, y + .002, cz, sp + k * 6.283 / n, .28 + .2 * o, s, s * .62)
    for k in range(n - 2): petal('lily_petal_' + color, cx, y + .006, cz, sp + .35 + k * 6.283 / (n - 2), .75 + .25 * o, s * .78, s * .5)
    for k in range(5): petal('lily_petal_' + color, cx, y + .01, cz, sp + .2 + k * 6.283 / 5, 1.15 + .2 * o, s * .5, s * .36)
    r = s * .2; quad('lily_stamen', [(cx - r, y + .012, cz + r), (cx + r, y + .012, cz + r), (cx + r, y + .012, cz - r), (cx - r, y + .012, cz - r)])
def scene(seed):
    global polys; polys = []
    rnd = random.Random(seed); cols = ['pink', 'white', 'cream', 'lilac']
    placed = []; nf = 2 if rnd.randrange(10) < 4 else 1; items = nf + 4 + rnd.randrange(3)
    for i in range(items):
        fl = i < nf; size = .26 + rnd.random() * .08 if fl else .14 + rnd.random() * rnd.random() * .16
        for _ in range(60):
            cx, cz = .5 + rnd.uniform(-.3, .3), .5 + rnd.uniform(-.3, .3)
            if math.hypot(cx - .5, cz - .5) > .3 - size * .5: continue
            if all(math.hypot(cx - a, cz - b) >= (size + c) * .4 for a, b, c in placed): break
        else: continue
        placed.append((cx, cz, size)); ang = rnd.random() * 6.283
        if fl: flower(cx, .01, cz, size, ang, rnd, rnd.choice(cols))
        else: pad('lily_pad_%d' % rnd.randrange(3), cx, .004 + .0015 * i, cz, size, ang)
def render(W, H, S, yawv, pitch):
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    cy, sy = math.cos(yawv), math.sin(yawv); cp, sp = math.cos(pitch), math.sin(pitch)
    def proj(p):
        x, y, z = p[0] - .5, p[1], p[2] - .5
        rx, rz = x * cy - z * sy, x * sy + z * cy
        return (W / 2 + rx * S, H * .62 - (y * cp + rz * sp * -1) * S + 0), rz * cp + y * sp
    out = []
    for q, c in polys:
        pr = [proj(p) for p in q]; out.append((sum(p[1] for p in pr) / 4, [p[0] for p in pr], c))
    for dep, pts, c in sorted(out, key=lambda t: t[0]): d.polygon(pts, fill=c)
    return im
if __name__ == '__main__':
    seeds = [int(s) for s in sys.argv[3:]] or [1, 2, 3, 4]
    W = 360; sheet = Image.new('RGBA', (W * len(seeds), W + 0), (58, 110, 175, 255))
    for i, sd in enumerate(seeds):
        scene(sd); tile = Image.new('RGBA', (W, W), (58, 110, 175, 255))
        ImageDraw.Draw(tile).ellipse((W / 2 - 150, W * .62 - 90, W / 2 + 150, W * .62 + 90), fill=(86, 150, 215, 255), outline=(150, 150, 160, 255), width=6)
        tile.alpha_composite(render(W, W, 560, .5, .75)); sheet.alpha_composite(tile, (i * W, 0))
    sheet.save(sys.argv[1])
