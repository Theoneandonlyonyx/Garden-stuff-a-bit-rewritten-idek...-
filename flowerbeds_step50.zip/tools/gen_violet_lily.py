"""Draws the violet flower sprites (particle + floating) and the birdbath waterlily flowers and pads.
Run: python3 tools/gen_violet_lily.py"""
import math, os
from PIL import Image
RES = os.path.join(os.path.dirname(__file__), '..', 'src/main/resources/assets/mikexxx_flowerbeds/textures')

def hx(s): return tuple(int(s[i:i+2], 16) for i in (1, 3, 5)) + (255,)
def mix(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(4))

VIOLETS = [  # deep violet, blue violet, lavender
    dict(base='#5a2a9e', mid='#7a48c6', tip='#a47ae8', vein='#3c1a72', throat='#fff6c8'),
    dict(base='#4a3aa8', mid='#6a5ad0', tip='#9a8cf0', vein='#32277a', throat='#fffbe0'),
    dict(base='#8a5cc8', mid='#b088e8', tip='#d8c0fa', vein='#5e3a9a', throat='#fff2b0'),
]

def ell(img, cx, cy, rx, ry, rot, pal, light=0.0):
    c, s = math.cos(rot), math.sin(rot)
    base, mid, tip = hx(pal['base']), hx(pal['mid']), hx(pal['tip'])
    for y in range(16):
        for x in range(16):
            dx, dy = x + 0.5 - cx, y + 0.5 - cy
            u, v = dx * c + dy * s, -dx * s + dy * c
            d = (u / rx) ** 2 + (v / ry) ** 2
            if d <= 1.0:
                t = min(1.0, max(0.0, d))
                col = mix(base, mid, min(1, t * 1.4)) if t < 0.7 else mix(mid, tip, (t - 0.7) / 0.3)
                if d > 0.82: col = mix(col, base, 0.35)
                img.putpixel((x, y), col)

def violet(pal, spread=0.0):
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    cx, cy = 8.0, 8.4
    # five petals: two up, two to the sides, one big lower petal (a viola), drawn back to front
    ell(img, cx - 2.9, cy - 3.3, 3.0, 3.5, -0.45 - spread, pal)
    ell(img, cx + 2.9, cy - 3.3, 3.0, 3.5, 0.45 + spread, pal)
    ell(img, cx - 4.0, cy + 0.7, 3.2, 2.9, 0.2, pal)
    ell(img, cx + 4.0, cy + 0.7, 3.2, 2.9, -0.2, pal)
    ell(img, cx, cy + 3.6, 3.7, 3.3, 0.0, pal)
    vein = hx(pal['vein']); th = hx(pal['throat'])
    for (x, y) in [(8, 10), (8, 11), (7, 10), (9, 10), (6, 8), (10, 8)]:
        img.putpixel((x, y), vein)
    for (x, y) in [(7, 7), (8, 7), (7, 8), (8, 8), (8, 9)]:
        img.putpixel((x, y), th)
    img.putpixel((8, 8), hx('#f2b01c'))
    return img

PADS = ['#2f7a34', '#3f9444', '#59ad54']
def pad(notch):
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    cx = cy = 8.0
    dark, mid, light = hx('#256a2c'), hx(PADS[1]), hx('#6cbd62')
    for y in range(16):
        for x in range(16):
            dx, dy = x + 0.5 - cx, y + 0.5 - cy
            d = math.hypot(dx, dy)
            if d > 7.4: continue
            ang = math.atan2(dy, dx)
            da = (ang - notch + math.pi) % (2 * math.pi) - math.pi
            if abs(da) < 0.16 + (1.0 - d / 7.4) * 0.05 and d > 1.2: continue  # the slit
            col = mid
            if d > 6.2: col = dark
            elif (dx * -0.5 + dy * -0.6) > 2.6: col = light
            # radial veins
            k = (ang * 8 / (2 * math.pi)) % 1.0
            if d > 2 and (k < 0.07 or k > 0.93): col = mix(col, dark, 0.35)
            img.putpixel((x, y), col)
    return img

LILIES = {
    'pink':  dict(outer=('#f6b6cf', '#ffe6f0'), tip='#e56ba0', inner=('#ffd2e3', '#fff2f7')),
    'white': dict(outer=('#e9eef2', '#ffffff'), tip='#cfd9e6', inner=('#f6f9fb', '#ffffff')),
    'cream': dict(outer=('#f6e29a', '#fff6cc'), tip='#e8bd5a', inner=('#fff0b0', '#fffbe2')),
}
def lily(pal):
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    cx = cy = 8.0
    o1, o2 = hx(pal['outer'][0]), hx(pal['outer'][1]); tip = hx(pal['tip'])
    i1, i2 = hx(pal['inner'][0]), hx(pal['inner'][1])
    def ring(n, rmax, rmin, phase, c_edge, c_mid, tipc):
        for y in range(16):
            for x in range(16):
                dx, dy = x + 0.5 - cx, y + 0.5 - cy
                d = math.hypot(dx, dy); ang = math.atan2(dy, dx)
                f = abs(math.cos(n * (ang - phase) / 2)) ** 0.8
                reach = rmin + (rmax - rmin) * f
                if d <= reach:
                    t = d / reach
                    col = mix(c_mid, c_edge, t)
                    if f > 0.88 and d > reach - 1.6: col = mix(col, tipc, 0.55)
                    if f < 0.12 and d > reach * 0.7: col = mix(col, c_edge, 0.0)
                    img.putpixel((x, y), col)
    ring(8, 7.5, 4.9, 0.0, o1, o2, tip)
    ring(6, 5.2, 3.2, math.pi / 6, i1, i2, tip)
    yel = hx('#f4c020'); org = hx('#e88a10')
    for y in range(16):
        for x in range(16):
            if math.hypot(x + 0.5 - cx, y + 0.5 - cy) <= 1.9: img.putpixel((x, y), yel)
    for (x, y) in [(6, 8), (9, 6), (10, 9), (7, 10), (8, 8)]: img.putpixel((x, y), org)
    return img

if __name__ == '__main__':
    for i, pal in enumerate(VIOLETS):
        im = violet(pal, spread=0.08 * i)
        im.save(os.path.join(RES, 'particle', 'violet_flower_%d.png' % i))
        im.save(os.path.join(RES, 'block', 'aroma_violet_%d.png' % i))
    pad(0.9).save(os.path.join(RES, 'block', 'lily_pad_small_0.png'))
    pad(-2.3).save(os.path.join(RES, 'block', 'lily_pad_small_1.png'))
    for name, pal in LILIES.items():
        lily(pal).save(os.path.join(RES, 'block', 'lily_flower_%s.png' % name))
