# Step 43 (on step 42) - Aspect 2 of 8: water spray height only
- Spray is lower: drops now rise about 0.65-0.85 block above the nozzle (before about 1.5-2 blocks), matching your green arches. Launch speed 0.25-0.28 instead of 0.30-0.40.
- Drops fan a little more outward (0.012-0.034 sideways) so the low spray still reads as arches.
- Bathbomb icon: two small pink flowers sit outside the ball, so the silhouette is broken.
- Only `FountainEffects.java` and the icon changed. Not compiled here.
