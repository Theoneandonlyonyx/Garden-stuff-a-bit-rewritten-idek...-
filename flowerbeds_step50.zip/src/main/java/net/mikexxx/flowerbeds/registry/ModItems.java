package net.mikexxx.flowerbeds.registry;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.WindowBoxBlock;
import net.mikexxx.flowerbeds.item.TrowelItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, PmpMikexxx.MODID);

    /** Opens Arrange Plants on a bed; on dirt, sand and the like it makes a bedding block. */
    public static final RegistryObject<Item> TROWEL = ITEMS.register("garden_trowel",
            () -> new TrowelItem(new Item.Properties().stacksTo(1)));

    /** Right-click a water-filled pot or birdbath: the water becomes aromatized (rosy, with petals and sparkles). */
    public static final RegistryObject<Item> SAKURA_BATHBOMB = ITEMS.register("sakura_bathbomb",
            () -> new Item(new Item.Properties()));

    /** Right-click a water-filled pot or birdbath: deep violet water with violet flowers and sparkles. */
    public static final RegistryObject<Item> VIOLET_BATHBOMB = ITEMS.register("violet_bathbomb",
            () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> FINE_CHINA_ITEM = ITEMS.register("fine_china",
            () -> new BlockItem(ModBlocks.FINE_CHINA.get(), new Item.Properties()));
    public static final RegistryObject<Item> SOIL_BLOCK_ITEM = ITEMS.register("soil_block",
            () -> new BlockItem(ModBlocks.SOIL_BLOCK.get(), new Item.Properties()));

    public static final Map<String, RegistryObject<Item>> WINDOW_BOX_ITEMS = new LinkedHashMap<>();

    static {
        for (Map.Entry<String, RegistryObject<WindowBoxBlock>> entry : ModBlocks.WINDOW_BOXES.entrySet()) {
            WINDOW_BOX_ITEMS.put(entry.getKey(), ITEMS.register("window_box_" + entry.getKey(),
                    () -> new BlockItem(entry.getValue().get(), new Item.Properties())));
        }
    }

    public static final Map<String, RegistryObject<Item>> LARGE_POT_ITEMS = new LinkedHashMap<>();

    static {
        for (String variant : ModBlocks.POT_VARIANTS) {
            LARGE_POT_ITEMS.put(variant, ITEMS.register(ModBlocks.registryName(variant),
                    () -> new BlockItem(ModBlocks.LARGE_POTS.get(variant).get(), new Item.Properties())));
        }
    }
}
