package net.mikexxx.flowerbeds.client.particle;

import net.mikexxx.flowerbeds.registry.ModParticles;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

/** One particle class for the glint, the bubble and the petal of aromatized water. */
public class AromaParticle extends TextureSheetParticle {

    public enum Kind { GLINT, BUBBLE, PETAL, POP, VIOLET_FLOWER, VIOLET_HAPPY }

    private final Kind kind;
    /** The violet kind of aroma: set by the caller with vx = 1. */
    private final boolean violet;
    private final float baseSize;
    private final float phase;
    /** Petal only: how fast the blossom turns while it falls. */
    private final float spin;
    private final SpriteSet sprites;

    private AromaParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz,
                          SpriteSet sprites, Kind kind) {
        super(level, x, y, z, vx > 0.5 ? 0.0 : vx, vy, vz);
        this.violet = vx > 0.5 || kind == Kind.VIOLET_FLOWER || kind == Kind.VIOLET_HAPPY;
        vx = vx > 0.5 ? 0.0 : vx;
        this.kind = kind;
        this.sprites = sprites;
        this.xd = vx + (random.nextDouble() - 0.5) * 0.004;
        this.yd = vy;
        this.zd = vz + (random.nextDouble() - 0.5) * 0.004;
        this.phase = random.nextFloat() * 6.2831855F;
        this.spin = (random.nextFloat() - 0.5F) * 0.11F;
        this.roll = random.nextFloat() * 6.2831855F;
        this.oRoll = this.roll;
        this.hasPhysics = false;
        if (kind == Kind.POP) {
            setSpriteFromAge(sprites);
        } else {
            pickSprite(sprites);
        }
        float[] pink = violet ? lilac(random) : rosy(random);
        switch (kind) {
            case GLINT -> {
                setColor(pink[0], pink[1], pink[2]);
                this.baseSize = 0.10F + random.nextFloat() * 0.07F;
                this.lifetime = 22 + random.nextInt(18);
                setAlpha(0.95F);
            }
            case BUBBLE -> {
                // Bubbles stay lighter than the glints, so the pink is pulled toward white.
                setColor(Mth.lerp(0.35F, pink[0], 1.0F), Mth.lerp(0.35F, pink[1], 1.0F), Mth.lerp(0.35F, pink[2], 1.0F));
                this.baseSize = 0.05F + random.nextFloat() * 0.09F;
                this.lifetime = 24 + random.nextInt(26);
                setAlpha(0.85F);
            }
            case POP -> {
                setColor(Mth.lerp(0.35F, pink[0], 1.0F), Mth.lerp(0.35F, pink[1], 1.0F), Mth.lerp(0.35F, pink[2], 1.0F));
                this.baseSize = 0.12F + random.nextFloat() * 0.05F;
                this.lifetime = 7;
                this.xd = 0.0;
                this.yd = 0.0;
                this.zd = 0.0;
                setAlpha(0.9F);
            }
            case VIOLET_HAPPY -> {
                setColor(0.62F + random.nextFloat() * 0.12F, 0.28F + random.nextFloat() * 0.16F, 0.95F);
                this.baseSize = 0.13F + random.nextFloat() * 0.08F;
                this.lifetime = 20 + random.nextInt(14);
                this.xd = (random.nextDouble() - 0.5) * 0.02;
                this.zd = (random.nextDouble() - 0.5) * 0.02;
                this.yd = 0.02 + random.nextDouble() * 0.02;
                setAlpha(0.95F);
            }
            case VIOLET_FLOWER -> {
                // A small violet. Its colour is in the sprite; it grows in, floats and shrinks away like glitter.
                setColor(1.0F, 1.0F, 1.0F);
                this.baseSize = 0.10F + random.nextFloat() * 0.09F;
                this.lifetime = 60 + random.nextInt(50);
                this.alpha = 0.0F;
            }
            default -> {
                // The one big blossom. Its colour is in the sprite (a recoloured flower from the sprite list), so
                // there is no tint on top.
                setColor(1.0F, 1.0F, 1.0F);
                this.baseSize = 0.16F + random.nextFloat() * 0.12F;
                this.lifetime = 70 + random.nextInt(45);
                this.alpha = 0.0F;
            }
        }
        this.quadSize = baseSize;
    }


    /**
     * A random colour for the particles: mostly pink (soft to hot), often a rosier pink, and now and then a
     * peachy pink. The pink range is the soft-to-hot shade mix 1.0 / 0.4..0.8 / 0.7..0.95.
     */
    public static float[] rosy(RandomSource random) {
        float pick = random.nextFloat();
        float shade = random.nextFloat();
        if (pick < 0.07F) {
            // Peachy pink, rare.
            return new float[] {1.0F, 0.66F + shade * 0.12F, 0.58F + shade * 0.10F};
        }
        if (pick < 0.32F) {
            // Rosy pink, deeper.
            return new float[] {1.0F, 0.30F + shade * 0.18F, 0.55F + shade * 0.15F};
        }
        // Soft pink to hot pink.
        return new float[] {1.0F, 0.4F + shade * 0.4F, 0.7F + shade * 0.25F};
    }

    /** Violet aroma colours: mostly white with a purple tinge, some lavender, a few deep violet. */
    public static float[] lilac(RandomSource random) {
        float pick = random.nextFloat();
        float shade = random.nextFloat();
        if (pick < 0.15F) {
            return new float[] {0.62F + shade * 0.1F, 0.38F + shade * 0.12F, 1.0F};
        }
        if (pick < 0.45F) {
            return new float[] {0.80F + shade * 0.1F, 0.66F + shade * 0.12F, 1.0F};
        }
        return new float[] {0.93F + shade * 0.07F, 0.88F + shade * 0.07F, 1.0F};
    }

    private boolean petalLike() {
        return kind == Kind.PETAL || kind == Kind.VIOLET_FLOWER;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            if (kind == Kind.BUBBLE && ModParticles.AROMA_POP.isPresent()) {
                // A bubble does not just vanish, it pops.
                this.level.addParticle(ModParticles.AROMA_POP.get(), this.x, this.y, this.z, violet ? 1.0 : 0.0, 0.0, 0.0);
            }
            return;
        }
        if (kind == Kind.POP) {
            setSpriteFromAge(sprites);
            return;
        }
        if (petalLike()) {
            // Floats up for a moment, then sinks slowly, swaying and turning as it goes.
            this.xd += Mth.sin(age * 0.17F + phase) * 0.0008;
            this.zd += Mth.cos(age * 0.14F + phase) * 0.0008;
            this.yd = Math.max(this.yd - 0.0006, -0.011);
            this.oRoll = this.roll;
            this.roll += spin * (0.7F + 0.3F * Mth.sin(age * 0.2F + phase));
            // Fades in, hangs there, and fades out completely before it is gone.
            float t = (float) age / (float) lifetime;
            this.alpha = (t < 0.12F ? t / 0.12F : t > 0.9F ? Math.max(0.0F, (1.0F - t) / 0.1F) : 1.0F) * 0.97F;
        } else if (kind == Kind.BUBBLE) {
            this.xd += Mth.sin(age * 0.3F + phase) * 0.0003;
        }
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.96;
        this.zd *= 0.96;
        if (kind == Kind.VIOLET_HAPPY) {
            this.xd += Mth.sin(age * 0.5F + phase) * 0.0012;
            this.zd += Mth.cos(age * 0.45F + phase) * 0.0012;
        }
        if (!petalLike()) {
            this.yd *= 0.985;
        }
    }


    @Override
    public float getQuadSize(float partialTick) {
        float t = Mth.clamp((age + partialTick) / lifetime, 0.0F, 1.0F);
        return switch (kind) {
            // Full size at first, then smaller and smaller until it is gone.
            case GLINT, VIOLET_HAPPY -> baseSize * (1.0F - t * t);
            case BUBBLE -> baseSize * (t < 0.2F ? 0.6F + 2.0F * t : 1.0F);
            case POP -> baseSize;
            // Grows in, floats at full size, then turns smaller and smaller until it is gone.
            case PETAL, VIOLET_FLOWER -> baseSize * (t < 0.12F ? 0.4F + 5.0F * t : t > 0.55F ? Mth.clamp(1.0F - (float) Math.pow((t - 0.55F) / 0.45F, 1.4), 0.0F, 1.0F) : 1.0F);
        };
    }

    @Override
    protected int getLightColor(float partialTick) {
        int base = super.getLightColor(partialTick);
        return (base & 0xFFFF0000) | Math.max(base & 0xFFFF, 0xB0);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final Kind kind;

        public Provider(SpriteSet sprites, Kind kind) {
            this.sprites = sprites;
            this.kind = kind;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new AromaParticle(level, x, y, z, vx, vy, vz, sprites, kind);
        }
    }
}
