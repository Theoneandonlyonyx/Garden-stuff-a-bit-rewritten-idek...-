package net.mikexxx.flowerbeds.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.mikexxx.flowerbeds.block.GlassPotBlock;
import net.mikexxx.flowerbeds.block.BirdbathBlock;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.Round3;
import net.mikexxx.flowerbeds.block.RoundPotBlock;
import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.block.entity.PlantBedBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.OrnamentalTrees;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AzaleaBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.RenderTypeHelper;
import net.minecraftforge.client.model.data.ModelData;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Draws the items of a bed at their real size. Scaled fruit is drawn smaller and turned. A dense plant texture
 * is drawn as one covering plane so neighbouring crosses do not flicker. Pot fill is a solid, textured volume
 * up to just under the rim, and water (including dyed water) is the same kind of volume with plants stood on it.
 */
public class PlantBedRenderer<T extends PlantBedBlockEntity> implements BlockEntityRenderer<T> {

    private static final RandomSource RANDOM = RandomSource.create(42L);
    private static final Map<BlockState, ModelInfo> MODELS = new HashMap<>();

    /** Beds are only drawn this close, and single blocks of a tall plant only this close to the camera. */
    private static final boolean COVER_PLANES = false;
    private static final int VIEW_DISTANCE = 32;
    private static final net.minecraft.resources.ResourceLocation WATER_SPRITE =
            new net.minecraft.resources.ResourceLocation("minecraft", "block/water_still");
    private static final net.minecraft.resources.ResourceLocation LAVA_SPRITE =
            new net.minecraft.resources.ResourceLocation("minecraft", "block/lava_still");
    private static final net.minecraft.resources.ResourceLocation MILK_SPRITE =
            new net.minecraft.resources.ResourceLocation("minecraft", "block/white_concrete");
    private static final double BLOCK_CULL_SQ = 36.0 * 36.0;
    /**
     * Where pot fill and liquid end on a side that opens to a connected pot. It runs a hair past the block edge
     * (0 and 1) so two neighbours overlap a little and no hairline gap can show between them, which a plain
     * inset or even an exact edge leaves because each block is transformed on its own.
     */
    private static final float OPEN_LO = -0.0005F;
    private static final float OPEN_HI = 1.0005F;

    public PlantBedRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public int getViewDistance() {
        return VIEW_DISTANCE;
    }

    @Override
    public boolean shouldRender(T bed, Vec3 camera) {
        if (bed.substrateState() == null && !bed.hasContents()) {
            if (!(bed instanceof LargePotBlockEntity pot) || pot.effectiveLiquid() == LargePotBlock.Liquid.NONE) {
                return false;
            }
        }
        return BlockEntityRenderer.super.shouldRender(bed, camera);
    }

    @Override
    public void render(T bed, float partialTick, PoseStack poseStack, MultiBufferSource buffers,
                       int packedLight, int packedOverlay) {
        Level level = bed.getLevel();
        if (level == null) {
            return;
        }
        BlockPos pos = bed.getBlockPos();
        float baseY = bed.bedHeight();

        boolean pot = bed instanceof LargePotBlockEntity;
        if (pot) {
            LargePotBlockEntity potBed = (LargePotBlockEntity) bed;
            BlockState substrate = potBed.substrateState();
            if (substrate != null) {
                renderPotSubstrate(substrate, potBed, level, pos, poseStack, buffers, packedOverlay,
                        GardenLayout.POT_FILL_BOTTOM, GardenLayout.POT_FILL_TOP, false);
            }
            if (potBed.getBottomLayer() != null && potBed.effectiveLiquid() == LargePotBlock.Liquid.WATER) {
                renderPotSubstrate(potBed.getBottomLayer().defaultBlockState(), potBed, level, pos, poseStack, buffers,
                        packedOverlay, GardenLayout.POT_FILL_BOTTOM,
                        GardenLayout.POT_FILL_BOTTOM + LargePotBlockEntity.BOTTOM_LAYER_HEIGHT, true);
            }
            if (potBed.isTank() && !potBed.getFish().isEmpty()) {
                TankFish.render(potBed, level, pos, partialTick, poseStack, buffers,
                        LevelRenderer.getLightColor(level, pos.above()));
            }
        }

        int light = LevelRenderer.getLightColor(level, pos.above());
        Vec3 camera = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        int worldTop = level.getMaxBuildHeight() - pos.getY();
        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            ItemStack stack = bed.getSlot(i);
            if (stack.isEmpty()) {
                continue;
            }
            if (OrnamentalTrees.isTree(stack)) {
                // Trees of the Ornamental Trees mod are drawn by their own texture, not by a block model.
                double tx = pos.getX() + GardenLayout.localX(i) - camera.x;
                double ty = pos.getY() + baseY - camera.y;
                double tz = pos.getZ() + GardenLayout.localZ(i) - camera.z;
                if (tx * tx + ty * ty + tz * tz <= BLOCK_CULL_SQ) {
                    MiniTree.render(stack, GardenLayout.localX(i), baseY, GardenLayout.localZ(i), poseStack, buffers,
                            light, packedOverlay);
                }
                continue;
            }
            List<BlockState> column = bed.getColumn(i);
            if (column.isEmpty()) {
                continue;
            }
            float x = GardenLayout.localX(i);
            float z = GardenLayout.localZ(i);
            boolean scaled = GardenLayout.isScaled(stack);
            LargePotBlockEntity potBed = pot ? (LargePotBlockEntity) bed : null;
            boolean water = potBed != null && potBed.effectiveLiquid() == LargePotBlock.Liquid.WATER;
            boolean tank = potBed != null && potBed.isTank();
            float surface = water ? potBed.waterSurface() : 0.0F;
            BlockState first = column.get(0);
            // Floating plants (lily pads, lotus ...) ride the water line, flower and all. A plant that is two
            // blocks or more (small dripleaf, tall flowers, tall seagrass) stands on the floor of a water pot
            // with its bottom part in the water and its top part out of it. Everything else keeps its old place.
            boolean floating = water && PlantStates.isFloating(first);
            boolean submerged = water && !tank && !floating && column.size() >= 2
                    && !PlantStates.isVerticalGrower(first);
            float slotBase = baseY;
            if (floating) {
                slotBase = surface + 0.075F;
            } else if (submerged) {
                slotBase = potBed.floorHeight() + 0.002F;
            }
            float aquatic = water && !tank && !submerged && PlantStates.isAquatic(first) ? 0.02F : 0.0F;
            int blockLight = light;
            int top = Math.min(column.size(), worldTop);
            for (int k = 0; k < top; k++) {
                // Far-away parts of a very tall plant are skipped, and the light is looked up every fourth block.
                double dx = pos.getX() + x - camera.x;
                double dy = pos.getY() + baseY + k + 0.5 - camera.y;
                double dz = pos.getZ() + z - camera.z;
                if (dx * dx + dy * dy + dz * dz > BLOCK_CULL_SQ) {
                    continue;
                }
                if (k > 0 && (k & 3) == 0) {
                    blockLight = LevelRenderer.getLightColor(level, pos.above(k + 1));
                }
                poseStack.pushPose();
                if (scaled) {
                    poseStack.translate(x, slotBase + aquatic, z);
                    if (!PlantStates.hasFront(column.get(k))) {
                        poseStack.mulPose(Axis.YP.rotationDegrees(bed.getRotation(i) * 90.0F));
                    }
                    float s = GardenLayout.SCALED_FRUIT_SCALE;
                    poseStack.scale(s, s, s);
                    poseStack.translate(-0.5, 0.0, -0.5);
                } else {
                    poseStack.translate(x - 0.5, slotBase + k + aquatic, z - 0.5);
                }
                BlockState part = column.get(k);
                if (water && part.hasProperty(BlockStateProperties.WATERLOGGED)) {
                    // A part that stands in the water is waterlogged, a part above the surface is not.
                    part = part.setValue(BlockStateProperties.WATERLOGGED, slotBase + k + 0.5F < surface);
                }
                BlockState drawn = scaled ? PlantStates.orient(part, bed.getRotation(i)) : part;
                renderState(drawn, level, pos, poseStack, buffers, blockLight, packedOverlay, i,
                        column.size() == 1 && !scaled);
                poseStack.popPose();
            }
        }

        ItemStack groundcover = bed.getSlot(GardenLayout.GROUNDCOVER_SLOT);
        if (!groundcover.isEmpty()) {
            poseStack.pushPose();
            poseStack.translate(0.0, baseY + 0.004, 0.0);
            BlockState state = PlantStates.stateFor(groundcover, bed.getAge(GardenLayout.GROUNDCOVER_SLOT));
            if (pot && !((LargePotBlockEntity) bed).isTank()
                    && ((LargePotBlockEntity) bed).getLiquid() == LargePotBlock.Liquid.WATER) {
                state = clearWaterlogged(state);
            }
            renderState(state, level, pos, poseStack, buffers, light, packedOverlay, 0, false);
            poseStack.popPose();
        }

        // Water is see-through, so it is drawn after everything that sits in it. Plants, fish and the floor
        // layer show through it instead of being hidden behind its faces.
        if (pot && ((LargePotBlockEntity) bed).effectiveLiquid() != LargePotBlock.Liquid.NONE) {
            renderPotLiquid((LargePotBlockEntity) bed, level, pos, poseStack, buffers, packedOverlay);
        }
    }

    private static BlockState clearWaterlogged(BlockState state) {
        if (state.hasProperty(BlockStateProperties.WATERLOGGED)) {
            return state.setValue(BlockStateProperties.WATERLOGGED, false);
        }
        return state;
    }

    private void renderState(BlockState state, Level level, BlockPos tintPos, PoseStack poseStack,
                             MultiBufferSource buffers, int light, int overlay, int slot, boolean allowCover) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        if (state.getRenderShape() != RenderShape.MODEL) {
            dispatcher.renderSingleBlock(state, poseStack, buffers, light, overlay);
            return;
        }
        ModelInfo info = info(state);
        // A dense texture flickering against its neighbours is replaced by one plane of that same texture.
        // A tall, detailed model is left alone so modern plants keep their shape, and is only nudged apart.
        // Only a lone plant of normal height can be replaced; parts of a stacked plant and tall models never are.
        // Plants are always drawn with their real model; the single covering plane is switched off.
        if (COVER_PLANES && allowCover && info.dense && info.cross && info.sprite != null && info.maxY <= 1.6F) {
            renderCover(info, state, level, tintPos, poseStack, buffers, light, overlay, slot);
            return;
        }
        poseStack.pushPose();
        poseStack.translate((slot & 3) * 0.0016F, slot * 0.0012F, ((slot >> 2) & 3) * 0.0016F);
        int rgb = PlantTint.color(state, level, tintPos, 0);
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        BakedModel model = dispatcher.getBlockModel(state);
        for (RenderType renderType : info.types) {
            dispatcher.getModelRenderer().renderModel(poseStack.last(),
                    buffers.getBuffer(renderType),
                    state, model, r, g, b, light, overlay, ModelData.EMPTY, renderType);
        }
        poseStack.popPose();
    }

    /** One double-sided plane of the plant texture. It cannot z-fight with itself, and each slot is turned. */
    private void renderCover(ModelInfo info, BlockState state, Level level, BlockPos tintPos, PoseStack poseStack,
                             MultiBufferSource buffers, int light, int overlay, int slot) {
        int rgb = PlantTint.color(state, level, tintPos, info.tint);
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        float height = Math.max(1.0F, info.maxY);
        TextureAtlasSprite sprite = info.sprite;
        VertexConsumer consumer = buffers.getBuffer(RenderType.cutout());
        poseStack.pushPose();
        poseStack.translate(0.5, 0.0, 0.5);
        poseStack.mulPose(Axis.YP.rotationDegrees(45.0F + slot * 13.0F));
        poseStack.translate(-0.5, 0.0, -0.5);
        PoseStack.Pose pose = poseStack.last();
        float x0 = 0.08F;
        float x1 = 0.92F;
        float z = 0.5F;
        float u0 = sprite.getU0();
        float u1 = sprite.getU1();
        float v0 = sprite.getV0();
        float v1 = sprite.getV1();
        // Front: top-left, top-right, bottom-right, bottom-left.
        vertex(consumer, pose, x0, height, z, r, g, b, 1, u0, v0, overlay, light, 0, 0, 1);
        vertex(consumer, pose, x1, height, z, r, g, b, 1, u1, v0, overlay, light, 0, 0, 1);
        vertex(consumer, pose, x1, 0, z, r, g, b, 1, u1, v1, overlay, light, 0, 0, 1);
        vertex(consumer, pose, x0, 0, z, r, g, b, 1, u0, v1, overlay, light, 0, 0, 1);
        // Back, opposite winding, same texture.
        vertex(consumer, pose, x1, height, z, r, g, b, 1, u1, v0, overlay, light, 0, 0, -1);
        vertex(consumer, pose, x0, height, z, r, g, b, 1, u0, v0, overlay, light, 0, 0, -1);
        vertex(consumer, pose, x0, 0, z, r, g, b, 1, u0, v1, overlay, light, 0, 0, -1);
        vertex(consumer, pose, x1, 0, z, r, g, b, 1, u1, v1, overlay, light, 0, 0, -1);
        poseStack.popPose();
    }

    private void renderPotSubstrate(BlockState substrate, LargePotBlockEntity pot, Level level, BlockPos pos,
                                    PoseStack poseStack, MultiBufferSource buffers, int overlay,
                                    float y0, float y1, boolean layer) {
        BlockState potState = pot.getBlockState();
        if (!(potState.getBlock() instanceof LargePotBlock)) {
            return;
        }
        float x0 = potState.getValue(LargePotBlock.WEST) ? OPEN_LO : 2.0F / 16.0F;
        float x1 = potState.getValue(LargePotBlock.EAST) ? OPEN_HI : 14.0F / 16.0F;
        float z0 = potState.getValue(LargePotBlock.NORTH) ? OPEN_LO : 2.0F / 16.0F;
        float z1 = potState.getValue(LargePotBlock.SOUTH) ? OPEN_HI : 14.0F / 16.0F;
        int light = LevelRenderer.getLightColor(level, pos.above());
        VertexConsumer consumer = buffers.getBuffer(RenderType.cutout());
        PoseStack.Pose pose = poseStack.last();
        Face top = face(substrate, Direction.UP);
        if (potState.getBlock() instanceof BirdbathBlock bath) {
            // In a birdbath the substrate sits on the bowl floor: a thin layer under the water, or a full fill.
            y0 = bath.fillBottom();
            y1 = layer ? y0 + bath.bottomLayerHeight() : GardenLayout.POT_FILL_TOP;
            float[][] rects = net.mikexxx.flowerbeds.block.BirdbathWater.rects(potState);
            if (rects != null) {
                for (float[] q : rects) {
                    horizontal(consumer, pose, q[0] / 16.0F, y1, q[1] / 16.0F, q[2] / 16.0F, y1, q[3] / 16.0F,
                            top, substrate, level, pos, overlay, light, true);
                }
                return;
            }
        }
        net.mikexxx.flowerbeds.block.PotFill.Slice[] shaped = net.mikexxx.flowerbeds.block.PotFill.slices(potState);
        if (shaped != null) {
            drawShapedSubstrate(shaped, substrate, level, pos, pose, consumer, overlay, light, y0, y1);
            return;
        }
        Face down = face(substrate, Direction.DOWN);
        horizontal(consumer, pose, x0, y1, z0, x1, y1, z1, top, substrate, level, pos, overlay, light, true);
        horizontal(consumer, pose, x0, y0, z0, x1, y0, z1, down, substrate, level, pos, overlay, light, false);
        if (!potState.getValue(LargePotBlock.NORTH) || !neighborFill(level, pos.north(), layer ? pot.getBottomLayer() : pot.getSubstrate(), layer)) {
            sideZ(consumer, pose, x0, x1, y0, y1, z0, face(substrate, Direction.NORTH), substrate, level, pos, overlay, light, false);
        }
        if (!potState.getValue(LargePotBlock.SOUTH) || !neighborFill(level, pos.south(), layer ? pot.getBottomLayer() : pot.getSubstrate(), layer)) {
            sideZ(consumer, pose, x0, x1, y0, y1, z1, face(substrate, Direction.SOUTH), substrate, level, pos, overlay, light, true);
        }
        if (!potState.getValue(LargePotBlock.WEST) || !neighborFill(level, pos.west(), layer ? pot.getBottomLayer() : pot.getSubstrate(), layer)) {
            sideX(consumer, pose, z0, z1, y0, y1, x0, face(substrate, Direction.WEST), substrate, level, pos, overlay, light, false);
        }
        if (!potState.getValue(LargePotBlock.EAST) || !neighborFill(level, pos.east(), layer ? pot.getBottomLayer() : pot.getSubstrate(), layer)) {
            sideX(consumer, pose, z0, z1, y0, y1, x1, face(substrate, Direction.EAST), substrate, level, pos, overlay, light, true);
        }
    }

    /** Substrate inside the curved outline of an amphora or china pot: slice by slice, no box through the wall. */
    private void drawShapedSubstrate(net.mikexxx.flowerbeds.block.PotFill.Slice[] slices, BlockState substrate,
                                     Level level, BlockPos pos, PoseStack.Pose pose, VertexConsumer consumer,
                                     int overlay, int light, float y0, float y1) {
        int lo = Math.max(2, (int) Math.floor(y0 * 16.0F + 1.0E-4F));
        int hi = Math.min(2 + slices.length - 1, (int) Math.ceil(y1 * 16.0F - 1.0E-4F) - 1);
        Face top = face(substrate, Direction.UP);
        Face down = face(substrate, Direction.DOWN);
        for (int k = lo; k <= hi; k++) {
            net.mikexxx.flowerbeds.block.PotFill.Slice s = slices[k - 2];
            float a = Math.max(k, y0 * 16.0F) / 16.0F;
            float b = Math.min(k + 1, y1 * 16.0F) / 16.0F;
            for (float[] q : k == hi ? s.rects() : s.up()) {
                horizontal(consumer, pose, q[0] / 16.0F, b, q[1] / 16.0F, q[2] / 16.0F, b, q[3] / 16.0F,
                        top, substrate, level, pos, overlay, light, true);
            }
            for (float[] q : k == lo ? s.rects() : s.down()) {
                horizontal(consumer, pose, q[0] / 16.0F, a, q[1] / 16.0F, q[2] / 16.0F, a, q[3] / 16.0F,
                        down, substrate, level, pos, overlay, light, false);
            }
            for (net.mikexxx.flowerbeds.block.PotFill.Edge e : s.edges()) {
                if (e.alongX()) {
                    sideX(consumer, pose, e.a0() / 16.0F, e.a1() / 16.0F, a, b, e.pos() / 16.0F,
                            face(substrate, e.positive() ? Direction.EAST : Direction.WEST), substrate, level, pos,
                            overlay, light, e.positive());
                } else {
                    sideZ(consumer, pose, e.a0() / 16.0F, e.a1() / 16.0F, a, b, e.pos() / 16.0F,
                            face(substrate, e.positive() ? Direction.SOUTH : Direction.NORTH), substrate, level, pos,
                            overlay, light, e.positive());
                }
            }
        }
    }

    /** Liquid inside the curved outline of an amphora or china pot. */
    private void drawShapedLiquid(net.mikexxx.flowerbeds.block.PotFill.Slice[] slices, Face face,
                                  VertexConsumer consumer, PoseStack.Pose pose, float r, float g, float b,
                                  float alpha, int overlay, int light, float y0, float y1) {
        int lo = Math.max(2, (int) Math.floor(y0 * 16.0F + 1.0E-4F));
        int hi = Math.min(2 + slices.length - 1, (int) Math.ceil(y1 * 16.0F - 1.0E-4F) - 1);
        for (int k = lo; k <= hi; k++) {
            net.mikexxx.flowerbeds.block.PotFill.Slice s = slices[k - 2];
            float a = Math.max(k, y0 * 16.0F) / 16.0F;
            float t = Math.min(k + 1, y1 * 16.0F) / 16.0F;
            for (float[] q : k == hi ? s.rects() : s.up()) {
                tintedHorizontal(consumer, pose, q[0] / 16.0F, t, q[1] / 16.0F, q[2] / 16.0F, t, q[3] / 16.0F,
                        face, r, g, b, alpha, overlay, light, true);
            }
            for (float[] q : k == lo ? s.rects() : s.down()) {
                tintedHorizontal(consumer, pose, q[0] / 16.0F, a, q[1] / 16.0F, q[2] / 16.0F, a, q[3] / 16.0F,
                        face, r * 0.7F, g * 0.7F, b * 0.7F, alpha, overlay, light, false);
            }
            for (net.mikexxx.flowerbeds.block.PotFill.Edge e : s.edges()) {
                if (e.alongX()) {
                    tintedSideX(consumer, pose, e.a0() / 16.0F, e.a1() / 16.0F, a, t, e.pos() / 16.0F, face,
                            r * 0.8F, g * 0.8F, b * 0.8F, alpha, overlay, light, e.positive());
                } else {
                    tintedSideZ(consumer, pose, e.a0() / 16.0F, e.a1() / 16.0F, a, t, e.pos() / 16.0F, face,
                            r * 0.8F, g * 0.8F, b * 0.8F, alpha, overlay, light, e.positive());
                }
            }
        }
    }

    private void renderPotLiquid(LargePotBlockEntity pot, Level level, BlockPos pos, PoseStack poseStack,
                                 MultiBufferSource buffers, int overlay) {
        BlockState potState = pot.getBlockState();
        if (!(potState.getBlock() instanceof LargePotBlock)) {
            return;
        }
        // A glass pot shows the liquid of the stack above it too.
        LargePotBlockEntity source = pot.liquidSource();
        LargePotBlock.Liquid liquid = source.getLiquid();
        boolean lava = liquid == LargePotBlock.Liquid.LAVA;
        boolean milk = liquid == LargePotBlock.Liquid.MILK;
        // Milk is a solid creamy white, not a tinted water surface.
        TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS)
                .apply(lava ? LAVA_SPRITE : milk ? MILK_SPRITE : WATER_SPRITE);
        int rgb = milk ? 0xF4F2E8 : 0xFFFFFF;
        if (liquid == LargePotBlock.Liquid.WATER) {
            rgb = source.getDyeColor() >= 0 ? source.getDyeColor() : PlantTint.water(level, pos);
        }
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        float alpha = lava || milk ? 1.0F : 0.85F;
        int light = lava ? LightTexture.FULL_BRIGHT : LevelRenderer.getLightColor(level, pos.above());
        if (potState.getBlock() instanceof BirdbathBlock bath) {
            renderBowlWater(potState, bath, consumerOf(buffers), poseStack.last(), sprite, r, g, b, alpha, overlay, light);
            if (potState.getValue(BirdbathBlock.POWERED) && potState.getValue(BirdbathBlock.DOWN)
                    && liquid == LargePotBlock.Liquid.WATER) {
                renderStreams(potState, bath, consumerOf(buffers), poseStack.last(), sprite, r, g, b, overlay, light);
            }
            if (pot.isAromaticWater() || pot.hasLily()) {
                float[][] bowl = net.mikexxx.flowerbeds.block.BirdbathWater.rects(potState);
                if (bowl == null) {
                    bowl = new float[][] {{potState.getValue(LargePotBlock.WEST) ? 0.0F : 1.5F,
                            potState.getValue(LargePotBlock.NORTH) ? 0.0F : 1.5F,
                            potState.getValue(LargePotBlock.EAST) ? 16.0F : 14.5F,
                            potState.getValue(LargePotBlock.SOUTH) ? 16.0F : 14.5F}};
                }
                if (pot.isAromaticWater()) {
                    drawFloatingPetals(bowl, bath.waterTop(), pos, consumerOf(buffers), poseStack.last(), overlay, light,
                            pot.isVioletWater());
                }
                if (pot.hasLily()) {
                    drawLilies(bowl, bath.waterTop(), pos, consumerOf(buffers), poseStack.last(), overlay, light);
                }
            }
            return;
        }
        float x0 = potState.getValue(LargePotBlock.WEST) ? OPEN_LO : 2.0F / 16.0F;
        float x1 = potState.getValue(LargePotBlock.EAST) ? OPEN_HI : 14.0F / 16.0F;
        float z0 = potState.getValue(LargePotBlock.NORTH) ? OPEN_LO : 2.0F / 16.0F;
        float z1 = potState.getValue(LargePotBlock.SOUTH) ? OPEN_HI : 14.0F / 16.0F;
        float y0 = GardenLayout.POT_FILL_BOTTOM;
        float y1 = GardenLayout.POT_WATER_TOP;
        boolean joinedAbove = false;
        boolean joinedBelow = false;
        if (pot.isTank()) {
            // The water runs on into the glass pots above and below, so there is no surface or floor between.
            joinedBelow = potState.getValue(GlassPotBlock.DOWN);
            joinedAbove = potState.getValue(GlassPotBlock.UP)
                    && level.getBlockEntity(pos.above()) instanceof LargePotBlockEntity up && up.effectiveLiquid() != LargePotBlock.Liquid.NONE;
            if (joinedBelow) {
                y0 = 0.0F;
            }
            if (joinedAbove) {
                y1 = 1.0F;
            }
        }
        VertexConsumer consumer = buffers.getBuffer(RenderType.translucent());
        PoseStack.Pose pose = poseStack.last();
        Face face = new Face(sprite, -1);
        net.mikexxx.flowerbeds.block.PotFill.Slice[] shaped = pot.isTank() ? null
                : net.mikexxx.flowerbeds.block.PotFill.slices(potState);
        if (shaped != null) {
            drawShapedLiquid(shaped, face, consumer, pose, r, g, b, alpha, overlay, light, y0, y1);
            if (pot.isAromaticWater()) {
                int top = Math.max(2, Math.min(2 + shaped.length - 1, (int) Math.ceil(y1 * 16.0F - 1.0E-4F) - 1));
                drawFloatingPetals(shaped[top - 2].rects(), y1, pos, consumer, pose, overlay, light, pot.isVioletWater());
            }
            return;
        }
        if (!joinedAbove) {
            tintedHorizontal(consumer, pose, x0, y1, z0, x1, y1, z1, face, r, g, b, alpha, overlay, light, true);
            if (pot.isAromaticWater()) {
                drawFloatingPetals(new float[][] {{Math.max(0.0F, x0) * 16.0F, Math.max(0.0F, z0) * 16.0F,
                        Math.min(1.0F, x1) * 16.0F, Math.min(1.0F, z1) * 16.0F}}, y1, pos, consumer, pose, overlay, light,
                        pot.isVioletWater());
            }
        }
        if (!joinedBelow) {
            tintedHorizontal(consumer, pose, x0, y0, z0, x1, y0, z1, face, r * 0.7F, g * 0.7F, b * 0.7F, alpha, overlay, light, false);
        }
        float sr = r * 0.8F;
        float sg = g * 0.8F;
        float sb = b * 0.8F;
        if (!potState.getValue(LargePotBlock.NORTH) || !neighborLiquid(level, pos.north(), liquid)) {
            tintedSideZ(consumer, pose, x0, x1, y0, y1, z0, face, sr, sg, sb, alpha, overlay, light, false);
        }
        if (!potState.getValue(LargePotBlock.SOUTH) || !neighborLiquid(level, pos.south(), liquid)) {
            tintedSideZ(consumer, pose, x0, x1, y0, y1, z1, face, sr, sg, sb, alpha, overlay, light, true);
        }
        if (!potState.getValue(LargePotBlock.WEST) || !neighborLiquid(level, pos.west(), liquid)) {
            tintedSideX(consumer, pose, z0, z1, y0, y1, x0, face, sr, sg, sb, alpha, overlay, light, false);
        }
        if (!potState.getValue(LargePotBlock.EAST) || !neighborLiquid(level, pos.east(), liquid)) {
            tintedSideX(consumer, pose, z0, z1, y0, y1, x1, face, sr, sg, sb, alpha, overlay, light, true);
        }
    }


    private static final net.minecraft.resources.ResourceLocation[] PETAL_SPRITES = {
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/aroma_petal_0"),
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/aroma_petal_1"),
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/aroma_petal_2")
    };

    private static final net.minecraft.resources.ResourceLocation[] VIOLET_SPRITES = {
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/aroma_violet_0"),
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/aroma_violet_1"),
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/aroma_violet_2")
    };
    private static final net.minecraft.resources.ResourceLocation[] PAD_SPRITES = {
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/lily_pad_0"),
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/lily_pad_1"),
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/lily_pad_2")
    };
    private static final String[] LILY_COLORS = {"pink", "white", "cream", "lilac"};
    private static final net.minecraft.resources.ResourceLocation LILY_STAMEN =
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/lily_stamen");
    private static final net.minecraft.resources.ResourceLocation LILY_SEPAL =
            new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/lily_sepal");

    private static net.minecraft.resources.ResourceLocation lilyTex(String kind, String color) {
        return new net.minecraft.resources.ResourceLocation("mikexxx_flowerbeds", "block/lily_" + kind + "_" + color);
    }

    /**
     * A small waterlily patch on the water of a birdbath bowl: one or two flowers (open with rings of tilted petals,
     * or still a bud, each turned and sized differently, pink / white / cream / lilac) and four to six pads of
     * different sizes with a slightly raised rim. Everything is placed inside the real water outline.
     */
    private void drawLilies(float[][] rects, float surface, BlockPos pos, VertexConsumer consumer,
                            PoseStack.Pose pose, int overlay, int light) {
        if (rects == null || rects.length == 0) {
            return;
        }
        RandomSource random = RandomSource.create(pos.asLong() * 2654435761L + 97531L);
        var atlas = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS);
        float total = 0.0F;
        for (float[] q : rects) {
            total += Math.max(0.0F, (q[2] - q[0]) * (q[3] - q[1]));
        }
        if (total <= 0.0F) {
            return;
        }
        int flowers = random.nextInt(10) < 4 ? 2 : 1;
        int pads = 4 + random.nextInt(3);
        int items = flowers + pads;
        float[][] placed = new float[items][3];
        int count = 0;
        for (int i = 0; i < items; i++) {
            boolean flower = i < flowers;
            float size = flower ? 0.17F + random.nextFloat() * 0.07F : 0.10F + random.nextFloat() * random.nextFloat() * 0.13F + 0.02F;
            float cx = 0.0F;
            float cz = 0.0F;
            float angle = random.nextFloat() * 6.2831855F;
            boolean ok = false;
            for (int attempt = 0; attempt < 60 && !ok; attempt++) {
                if (attempt > 0 && attempt % 15 == 0) {
                    size *= 0.8F;
                }
                if (size < 0.09F) {
                    break;
                }
                float pick = random.nextFloat() * total;
                float[] rect = rects[rects.length - 1];
                for (float[] q : rects) {
                    pick -= Math.max(0.0F, (q[2] - q[0]) * (q[3] - q[1]));
                    if (pick <= 0.0F) {
                        rect = q;
                        break;
                    }
                }
                cx = (rect[0] + random.nextFloat() * (rect[2] - rect[0])) / 16.0F;
                cz = (rect[1] + random.nextFloat() * (rect[3] - rect[1])) / 16.0F;
                ok = petalFits(rects, cx, cz, size * 0.5F * 1.05F, angle);
                for (int k = 0; k < count && ok; k++) {
                    float dx = cx - placed[k][0];
                    float dz = cz - placed[k][1];
                    float min = (size + placed[k][2]) * 0.5F * 0.8F;
                    if (dx * dx + dz * dz < min * min) {
                        ok = false;
                    }
                }
            }
            if (!ok) {
                continue;
            }
            placed[count][0] = cx;
            placed[count][1] = cz;
            placed[count][2] = size;
            count++;
            if (flower) {
                drawLilyFlower(atlas, random, consumer, pose, overlay, light, cx, surface + 0.01F, cz, size, angle);
            } else {
                drawLilyPad(atlas.apply(PAD_SPRITES[random.nextInt(PAD_SPRITES.length)]), consumer, pose, overlay,
                        light, cx, surface + 0.004F + 0.0015F * i, cz, size, angle);
            }
        }
    }

    /** A pad as a 3x3 grid of quads whose outer ring is raised a hair, so the rim curls up out of the water. */
    private static void drawLilyPad(TextureAtlasSprite sprite, VertexConsumer consumer, PoseStack.Pose pose, int overlay,
                                    int light, float cx, float y, float cz, float size, float angle) {
        float sin = (float) Math.sin(angle);
        float cos = (float) Math.cos(angle);
        float half = size * 0.5F;
        float lift = size * 0.07F;
        float du = sprite.getU1() - sprite.getU0();
        float dv = sprite.getV1() - sprite.getV0();
        float[] edge = {-1.0F, -1.0F / 3.0F, 1.0F / 3.0F, 1.0F};
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int[][] c = {{i, j}, {i, j + 1}, {i + 1, j + 1}, {i + 1, j}};
                for (int[] v : c) {
                    float lx = edge[v[0]] * half;
                    float lz = edge[v[1]] * half;
                    boolean rim = v[0] == 0 || v[0] == 3 || v[1] == 0 || v[1] == 3;
                    float px = cx + lx * cos - lz * sin;
                    float pz = cz + lx * sin + lz * cos;
                    float u = sprite.getU0() + (edge[v[0]] + 1.0F) * 0.5F * du;
                    float vv = sprite.getV0() + (edge[v[1]] + 1.0F) * 0.5F * dv;
                    vertex(consumer, pose, px, y + (rim ? lift : 0.0F), pz, 1.0F, 1.0F, 1.0F, 1.0F, u, vv, overlay, light, 0, 1, 0);
                }
            }
        }
    }

    /**
     * A flower: four sepals, then rings of tilted petals (outer low and wide open, middle, inner nearly upright), a
     * stamen disc in the middle. About one in four is a closed bud instead. Petals are drawn on both sides.
     */
    private static void drawLilyFlower(java.util.function.Function<net.minecraft.resources.ResourceLocation, TextureAtlasSprite> atlas,
                                       RandomSource random, VertexConsumer consumer, PoseStack.Pose pose, int overlay,
                                       int light, float cx, float y, float cz, float size, float yaw) {
        String color = LILY_COLORS[random.nextInt(LILY_COLORS.length)];
        float s = size * 0.5F;
        if (random.nextInt(4) == 0) {
            TextureAtlasSprite bud = atlas.apply(lilyTex("bud", color));
            float h = s * 1.05F;
            float w = s * 0.62F;
            for (int k = 0; k < 2; k++) {
                float a = yaw + k * 1.5707964F;
                float dx = (float) Math.cos(a) * w;
                float dz = (float) Math.sin(a) * w;
                doubleQuad(consumer, pose, overlay, light, bud, cx - dx, y, cz - dz, cx + dx, y, cz + dz,
                        cx + dx, y + h, cz + dz, cx - dx, y + h, cz - dz);
            }
            return;
        }
        float open = 0.0F + random.nextFloat();
        TextureAtlasSprite sepal = atlas.apply(LILY_SEPAL);
        for (int k = 0; k < 4; k++) {
            petalQuad(consumer, pose, overlay, light, sepal, cx, y, cz, yaw + 0.8F + k * 1.5707964F, 0.2F, s * 0.8F, s * 0.28F);
        }
        TextureAtlasSprite petal = atlas.apply(lilyTex("petal", color));
        int outer = 7 + random.nextInt(3);
        int mid = outer - 2;
        int inner = 5;
        float spin = random.nextFloat() * 6.2831855F;
        for (int k = 0; k < outer; k++) {
            petalQuad(consumer, pose, overlay, light, petal, cx, y + 0.002F, cz, spin + k * 6.2831855F / outer,
                    0.28F + 0.2F * open, s, s * 0.62F);
        }
        for (int k = 0; k < mid; k++) {
            petalQuad(consumer, pose, overlay, light, petal, cx, y + 0.006F, cz, spin + 0.35F + k * 6.2831855F / mid,
                    0.75F + 0.25F * open, s * 0.78F, s * 0.5F);
        }
        for (int k = 0; k < inner; k++) {
            petalQuad(consumer, pose, overlay, light, petal, cx, y + 0.01F, cz, spin + 0.2F + k * 6.2831855F / inner,
                    1.25F + 0.15F * open, s * 0.6F, s * 0.42F);
        }
        float r = s * 0.16F;
        TextureAtlasSprite st = atlas.apply(LILY_STAMEN);
        float sy = y + 0.003F;
        float[][] corner = {{-r, -r, st.getU0(), st.getV0()}, {-r, r, st.getU0(), st.getV1()},
                {r, r, st.getU1(), st.getV1()}, {r, -r, st.getU1(), st.getV0()}};
        for (float[] c : corner) {
            vertex(consumer, pose, cx + c[0], sy, cz + c[1], 1.0F, 1.0F, 1.0F, 1.0F, c[2], c[3], overlay, light, 0, 1, 0);
        }
    }

    /** A petal leaning out from (x,y,z) towards yaw, raised by tilt radians from flat, drawn on both sides. */
    private static void petalQuad(VertexConsumer consumer, PoseStack.Pose pose, int overlay, int light,
                                  TextureAtlasSprite sprite, float x, float y, float z, float yaw, float tilt,
                                  float length, float width) {
        float dx = (float) Math.cos(yaw);
        float dz = (float) Math.sin(yaw);
        float reach = (float) Math.cos(tilt) * length;
        float rise = (float) Math.sin(tilt) * length;
        float sx = -dz * width * 0.5F;
        float sz = dx * width * 0.5F;
        float tx = x + dx * reach;
        float tz = z + dz * reach;
        // base left, base right, tip right, tip left
        doubleQuad(consumer, pose, overlay, light, sprite, x - sx * 0.5F, y, z - sz * 0.5F, x + sx * 0.5F, y, z + sz * 0.5F,
                tx + sx, y + rise, tz + sz, tx - sx, y + rise, tz - sz);
    }

    /** Four corners in the order base-left, base-right, tip-right, tip-left, texture tip up. Both sides are drawn. */
    private static void doubleQuad(VertexConsumer consumer, PoseStack.Pose pose, int overlay, int light,
                                   TextureAtlasSprite sprite, float x0, float y0, float z0, float x1, float y1, float z1,
                                   float x2, float y2, float z2, float x3, float y3, float z3) {
        float u0 = sprite.getU0();
        float u1 = sprite.getU1();
        float v0 = sprite.getV0();
        float v1 = sprite.getV1();
        vertex(consumer, pose, x0, y0, z0, 1.0F, 1.0F, 1.0F, 1.0F, u0, v1, overlay, light, 0, 1, 0);
        vertex(consumer, pose, x1, y1, z1, 1.0F, 1.0F, 1.0F, 1.0F, u1, v1, overlay, light, 0, 1, 0);
        vertex(consumer, pose, x2, y2, z2, 1.0F, 1.0F, 1.0F, 1.0F, u1, v0, overlay, light, 0, 1, 0);
        vertex(consumer, pose, x3, y3, z3, 1.0F, 1.0F, 1.0F, 1.0F, u0, v0, overlay, light, 0, 1, 0);
        vertex(consumer, pose, x3, y3, z3, 1.0F, 1.0F, 1.0F, 1.0F, u0, v0, overlay, light, 0, -1, 0);
        vertex(consumer, pose, x2, y2, z2, 1.0F, 1.0F, 1.0F, 1.0F, u1, v0, overlay, light, 0, -1, 0);
        vertex(consumer, pose, x1, y1, z1, 1.0F, 1.0F, 1.0F, 1.0F, u1, v1, overlay, light, 0, -1, 0);
        vertex(consumer, pose, x0, y0, z0, 1.0F, 1.0F, 1.0F, 1.0F, u0, v1, overlay, light, 0, -1, 0);
    }

    /**
     * A few two-coloured petals drifting on the surface of aromatized water, like magnolia petals on a pond.
     * Three to a block. Each block gets its own sizes (a few large, mostly small), spots and turns from its
     * position, and one of three petal sprites. The sprites are never mirrored. They sway a little over time.
     * rects: where the water is, as {x0, z0, x1, z1} in sixteenths.
     */
    private void drawFloatingPetals(float[][] rects, float surface, BlockPos pos, VertexConsumer consumer,
                                    PoseStack.Pose pose, int overlay, int light, boolean violet) {
        if (rects == null || rects.length == 0) {
            return;
        }
        RandomSource random = RandomSource.create(pos.asLong() * 341873128712L + 132897987541L);
        float total = 0.0F;
        for (float[] q : rects) {
            total += Math.max(0.0F, (q[2] - q[0]) * (q[3] - q[1]));
        }
        if (total <= 0.0F) {
            return;
        }
        long time = Minecraft.getInstance().level != null ? Minecraft.getInstance().level.getGameTime() : 0L;
        var atlas = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS);
        float y = surface + 0.004F;
        net.minecraft.resources.ResourceLocation[] sprites = violet ? VIOLET_SPRITES : PETAL_SPRITES;
        for (int i = 0; i < (violet ? 4 : 3); i++) {
            float size = violet ? 0.11F + (float) Math.pow(random.nextFloat(), 1.4F) * 0.11F
                    : 0.13F + (float) Math.pow(random.nextFloat(), 1.6F) * 0.17F;
            float cx = 0.0F;
            float cz = 0.0F;
            float angle = 0.0F;
            boolean placed = false;
            // Try spots until the whole petal, turned as it is, lies inside the water outline. If it will not fit
            // anywhere the petal gets smaller, and if it never fits it is left out.
            for (int attempt = 0; attempt < 48 && !placed; attempt++) {
                if (attempt > 0 && attempt % 12 == 0) {
                    size *= 0.78F;
                }
                if (size < 0.05F) {
                    break;
                }
                float pick = random.nextFloat() * total;
                float[] rect = rects[rects.length - 1];
                for (float[] q : rects) {
                    pick -= Math.max(0.0F, (q[2] - q[0]) * (q[3] - q[1]));
                    if (pick <= 0.0F) {
                        rect = q;
                        break;
                    }
                }
                cx = (rect[0] + random.nextFloat() * (rect[2] - rect[0])) / 16.0F;
                cz = (rect[1] + random.nextFloat() * (rect[3] - rect[1])) / 16.0F;
                angle = random.nextFloat() * 6.2831855F;
                placed = petalFits(rects, cx, cz, size * 0.5F * 1.15F, angle);
            }
            if (!placed) {
                continue;
            }
            float half = size * 0.5F;
            angle += 0.06F * (float) Math.sin(time * 0.03F + i * 2.1F + pos.getX() + pos.getZ());
            int variant = random.nextInt(sprites.length);
            float sin = (float) Math.sin(angle);
            float cos = (float) Math.cos(angle);
            TextureAtlasSprite sprite = atlas.apply(sprites[variant]);
            float u0 = sprite.getU0();
            float u1 = sprite.getU1();
            float v0 = sprite.getV0();
            float v1 = sprite.getV1();
            // Corners in the same order as a water surface quad: (-,-) (-,+) (+,+) (+,-).
            float[][] corner = {{-half, -half, u0, v0}, {-half, half, u0, v1}, {half, half, u1, v1}, {half, -half, u1, v0}};
            for (float[] c : corner) {
                float px = cx + c[0] * cos - c[1] * sin;
                float pz = cz + c[0] * sin + c[1] * cos;
                vertex(consumer, pose, px, y, pz, 1.0F, 1.0F, 1.0F, 0.97F, c[2], c[3], overlay, light, 0, 1, 0);
            }
        }
    }

    /** Whether a petal of this radius, turned by angle, lies wholly inside the water rectangles (sixteenths). */
    private static boolean petalFits(float[][] rects, float cx, float cz, float radius, float angle) {
        float sin = (float) Math.sin(angle);
        float cos = (float) Math.cos(angle);
        // The four corners of the square and the middle of each edge, turned like the petal.
        float[][] probe = {{-1, -1}, {-1, 1}, {1, 1}, {1, -1}, {-1, 0}, {1, 0}, {0, -1}, {0, 1}, {0, 0}};
        for (float[] p : probe) {
            float x = (cx + (p[0] * cos - p[1] * sin) * radius) * 16.0F;
            float z = (cz + (p[0] * sin + p[1] * cos) * radius) * 16.0F;
            boolean in = false;
            for (float[] q : rects) {
                if (x >= q[0] - 0.01F && x <= q[2] + 0.01F && z >= q[1] - 0.01F && z <= q[3] + 0.01F) {
                    in = true;
                    break;
                }
            }
            if (!in) {
                return false;
            }
        }
        return true;
    }

    /**
     * Water running out of the notches of a powered bowl that stands on another bowl: a thin sheet from the notch
     * lip down to the water of the bowl below.
     */
    private void renderStreams(BlockState st, BirdbathBlock bath, VertexConsumer consumer, PoseStack.Pose pose,
                               TextureAtlasSprite sprite, float r, float g, float b, int overlay, int light) {
        Face face = new Face(sprite, -1);
        float top = bath.waterTop();
        float bottom = top - 1.0F;
        float half = 0.9F / 16.0F;
        float lr = r * 0.7F + 0.3F;
        float lg = g * 0.7F + 0.3F;
        float lb = b * 0.7F + 0.3F;
        float a = 0.7F;
        for (float[] spot : net.mikexxx.flowerbeds.block.BathNotches.spots(st)) {
            float cx = spot[0] + spot[2] * 1.2F / 16.0F;
            float cz = spot[1] + spot[3] * 1.2F / 16.0F;
            float x0 = cx - half;
            float x1 = cx + half;
            float z0 = cz - half;
            float z1 = cz + half;
            tintedHorizontal(consumer, pose, x0, top, z0, x1, top, z1, face, lr, lg, lb, a, overlay, light, true);
            tintedSideZ(consumer, pose, x0, x1, bottom, top, z0, face, lr, lg, lb, a, overlay, light, false);
            tintedSideZ(consumer, pose, x0, x1, bottom, top, z1, face, lr, lg, lb, a, overlay, light, true);
            tintedSideX(consumer, pose, z0, z1, bottom, top, x0, face, lr, lg, lb, a, overlay, light, false);
            tintedSideX(consumer, pose, z0, z1, bottom, top, x1, face, lr, lg, lb, a, overlay, light, true);
        }
    }

    private static VertexConsumer consumerOf(MultiBufferSource buffers) {
        return buffers.getBuffer(RenderType.translucent());
    }

    /**
     * The water of a birdbath is one flat sheet in the bowl. A corner whose two sides are both closed is cut
     * back so the sheet follows the rounded rim, and in a finished 3x3 the corners are cut deeper to match the
     * round bath.
     */
    private void renderBowlWater(BlockState st, BirdbathBlock bath, VertexConsumer consumer, PoseStack.Pose pose,
                                 TextureAtlasSprite sprite, float r, float g, float b, float alpha,
                                 int overlay, int light) {
        float[][] rects = net.mikexxx.flowerbeds.block.BirdbathWater.rects(st);
        if (rects != null) {
            // The water fills exactly the floor inside the round rim of the bowl models.
            Face bowl = new Face(sprite, -1);
            float level = bath.waterTop();
            for (float[] q : rects) {
                tintedHorizontal(consumer, pose, q[0] / 16.0F, level, q[1] / 16.0F, q[2] / 16.0F, level, q[3] / 16.0F,
                        bowl, r, g, b, alpha, overlay, light, true);
            }
            return;
        }
        boolean n = st.getValue(LargePotBlock.NORTH);
        boolean e = st.getValue(LargePotBlock.EAST);
        boolean so = st.getValue(LargePotBlock.SOUTH);
        boolean w = st.getValue(LargePotBlock.WEST);
        Round3 round = BirdbathBlock.round(st);
        boolean roundCorner = round == Round3.NW || round == Round3.NE || round == Round3.SE || round == Round3.SW;
        float inset = 1.5F / 16.0F;
        float x0 = w ? OPEN_LO : inset;
        float x1 = e ? OPEN_HI : 1.0F - inset;
        float z0 = n ? OPEN_LO : inset;
        float z1 = so ? OPEN_HI : 1.0F - inset;
        float cut = (roundCorner ? 7.0F : 4.5F) / 16.0F;
        boolean nw = !n && !w;
        boolean ne = !n && !e;
        boolean se = !so && !e;
        boolean sw = !so && !w;
        float cutN = nw || ne ? cut : 0.0F;
        float cutS = se || sw ? cut : 0.0F;
        float y = bath.waterTop();
        Face face = new Face(sprite, -1);
        // Middle band, full width.
        tintedHorizontal(consumer, pose, x0, y, z0 + cutN, x1, y, z1 - cutS, face, r, g, b, alpha, overlay, light, true);
        if (cutN > 0.0F) {
            tintedHorizontal(consumer, pose, x0 + (nw ? cut : 0.0F), y, z0, x1 - (ne ? cut : 0.0F), y, z0 + cutN,
                    face, r, g, b, alpha, overlay, light, true);
        }
        if (cutS > 0.0F) {
            tintedHorizontal(consumer, pose, x0 + (sw ? cut : 0.0F), y, z1 - cutS, x1 - (se ? cut : 0.0F), y, z1,
                    face, r, g, b, alpha, overlay, light, true);
        }
    }

    /** Whether the pot next door has the same fill, so the side face between the two is not drawn. */
    private static boolean neighborFill(Level level, BlockPos pos, net.minecraft.world.level.block.Block block,
                                        boolean layer) {
        if (!(level.getBlockEntity(pos) instanceof LargePotBlockEntity pot) || block == null) {
            return false;
        }
        return layer ? pot.getBottomLayer() == block : pot.getSubstrate() != null;
    }

    private static boolean neighborLiquid(Level level, BlockPos pos, LargePotBlock.Liquid liquid) {
        return level.getBlockEntity(pos) instanceof LargePotBlockEntity pot && pot.effectiveLiquid() == liquid;
    }

    private ModelInfo info(BlockState state) {
        ModelInfo cached = MODELS.get(state);
        if (cached != null) {
            return cached;
        }
        ModelInfo baked;
        try {
            baked = bake(state);
        } catch (RuntimeException e) {
            baked = ModelInfo.fallback();
        }
        MODELS.put(state, baked);
        return baked;
    }

    private ModelInfo bake(BlockState state) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        BakedModel model = dispatcher.getBlockModel(state);
        float minX = 0, minY = 0, minZ = 0, maxX = 1, maxY = 1, maxZ = 1;
        boolean any = false;
        int quads = 0;
        int tint = -1;
        boolean allVertical = true;
        TextureAtlasSprite sprite = model.getParticleIcon(ModelData.EMPTY);
        for (Direction face : iterateFaces()) {
            for (BakedQuad quad : model.getQuads(state, face, RANDOM, ModelData.EMPTY, null)) {
                quads++;
                if (sprite == null || face == Direction.UP) {
                    sprite = quad.getSprite();
                }
                if (tint < 0) {
                    tint = quad.getTintIndex();
                }
                int[] v = quad.getVertices();
                int stride = v.length / 4;
                // A quad that lies flat (all four corners at one height) means this is not a simple crossed plant.
                float firstY = Float.intBitsToFloat(v[1]);
                boolean flat = true;
                for (int i = 1; i < 4; i++) {
                    if (Math.abs(Float.intBitsToFloat(v[i * stride + 1]) - firstY) > 0.001F) {
                        flat = false;
                    }
                }
                if (flat) {
                    allVertical = false;
                }
                for (int i = 0; i < 4; i++) {
                    float x = Float.intBitsToFloat(v[i * stride]);
                    float y = Float.intBitsToFloat(v[i * stride + 1]);
                    float z = Float.intBitsToFloat(v[i * stride + 2]);
                    if (!any) {
                        minX = maxX = x;
                        minY = maxY = y;
                        minZ = maxZ = z;
                        any = true;
                    } else {
                        minX = Math.min(minX, x);
                        minY = Math.min(minY, y);
                        minZ = Math.min(minZ, z);
                        maxX = Math.max(maxX, x);
                        maxY = Math.max(maxY, y);
                        maxZ = Math.max(maxZ, z);
                    }
                }
            }
        }
        if (!any) {
            minX = minY = minZ = 0;
            maxX = maxY = maxZ = 1;
        }
        float opacity = sprite == null ? 0 : opacity(sprite);
        boolean leafy = state.getBlock() instanceof LeavesBlock || state.getBlock() instanceof AzaleaBlock;
        boolean dense = leafy || opacity >= 0.50F;
        List<RenderType> types = model.getRenderTypes(state, RANDOM, ModelData.EMPTY).asList();
        return new ModelInfo(minX, minY, minZ, maxX, maxY, maxZ, quads, dense, tint, sprite, types, allVertical && quads <= 4);
    }

    private static Direction[] iterateFaces() {
        return new Direction[] {Direction.DOWN, Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, null};
    }

    private static float opacity(TextureAtlasSprite sprite) {
        try {
            Object contents = sprite.contents();
            com.mojang.blaze3d.platform.NativeImage image = null;
            Class<?> type = contents.getClass();
            while (type != null && image == null) {
                for (Field field : type.getDeclaredFields()) {
                    field.setAccessible(true);
                    Object value = field.get(contents);
                    if (value instanceof com.mojang.blaze3d.platform.NativeImage nativeImage) {
                        image = nativeImage;
                        break;
                    }
                    if (value instanceof com.mojang.blaze3d.platform.NativeImage[] images && images.length > 0 && images[0] != null) {
                        image = images[0];
                        break;
                    }
                }
                type = type.getSuperclass();
            }
            if (image == null) {
                return 0;
            }
            int w = image.getWidth();
            int h = image.getHeight();
            int stepX = Math.max(1, w / 16);
            int stepY = Math.max(1, h / 16);
            int total = 0;
            int opaque = 0;
            for (int y = 0; y < h; y += stepY) {
                for (int x = 0; x < w; x += stepX) {
                    total++;
                    int pixel = image.getPixelRGBA(x, y);
                    if (((pixel >>> 24) & 255) > 200) {
                        opaque++;
                    }
                }
            }
            return total == 0 ? 0 : opaque / (float) total;
        } catch (Throwable ignored) {
            return 0;
        }
    }

    private Face face(BlockState state, Direction direction) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        BakedModel model = dispatcher.getBlockModel(state);
        List<BakedQuad> quads = model.getQuads(state, direction, RANDOM, ModelData.EMPTY, null);
        if (quads.isEmpty()) {
            quads = model.getQuads(state, null, RANDOM, ModelData.EMPTY, null);
        }
        if (quads.isEmpty()) {
            return new Face(model.getParticleIcon(ModelData.EMPTY), -1);
        }
        return new Face(quads.get(0).getSprite(), quads.get(0).getTintIndex());
    }

    private void horizontal(VertexConsumer consumer, PoseStack.Pose pose, float x0, float y, float z0,
                            float x1, float y2, float z1, Face face, BlockState state, Level level, BlockPos pos,
                            int overlay, int light, boolean up) {
        int rgb = PlantTint.color(state, level, pos, face.tint);
        float shade = up ? 1.0F : 0.5F;
        float r = shade * (rgb >> 16 & 255) / 255.0F;
        float g = shade * (rgb >> 8 & 255) / 255.0F;
        float b = shade * (rgb & 255) / 255.0F;
        tintedHorizontal(consumer, pose, x0, y, z0, x1, y2, z1, face, r, g, b, 1, overlay, light, up);
    }

    private void tintedHorizontal(VertexConsumer consumer, PoseStack.Pose pose, float x0, float y, float z0,
                                  float x1, float ignoredY, float z1, Face face, float r, float g, float b, float a,
                                  int overlay, int light, boolean up) {
        TextureAtlasSprite sprite = face.sprite;
        float u0 = sprite.getU(x0 * 16.0F);
        float u1 = sprite.getU(x1 * 16.0F);
        float v0 = sprite.getV(z0 * 16.0F);
        float v1 = sprite.getV(z1 * 16.0F);
        float ny = up ? 1 : -1;
        if (up) {
            vertex(consumer, pose, x0, y, z0, r, g, b, a, u0, v0, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x0, y, z1, r, g, b, a, u0, v1, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x1, y, z1, r, g, b, a, u1, v1, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x1, y, z0, r, g, b, a, u1, v0, overlay, light, 0, ny, 0);
        } else {
            vertex(consumer, pose, x0, y, z0, r, g, b, a, u0, v0, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x1, y, z0, r, g, b, a, u1, v0, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x1, y, z1, r, g, b, a, u1, v1, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x0, y, z1, r, g, b, a, u0, v1, overlay, light, 0, ny, 0);
        }
    }

    private void sideZ(VertexConsumer consumer, PoseStack.Pose pose, float x0, float x1, float y0, float y1, float z,
                       Face face, BlockState state, Level level, BlockPos pos, int overlay, int light, boolean positive) {
        int rgb = PlantTint.color(state, level, pos, face.tint);
        float shade = 0.8F;
        float r = shade * (rgb >> 16 & 255) / 255.0F;
        float g = shade * (rgb >> 8 & 255) / 255.0F;
        float b = shade * (rgb & 255) / 255.0F;
        tintedSideZ(consumer, pose, x0, x1, y0, y1, z, face, r, g, b, 1, overlay, light, positive);
    }

    private void tintedSideZ(VertexConsumer consumer, PoseStack.Pose pose, float x0, float x1, float y0, float y1, float z,
                             Face face, float r, float g, float b, float a, int overlay, int light, boolean positive) {
        TextureAtlasSprite sprite = face.sprite;
        float u0 = sprite.getU(x0 * 16.0F);
        float u1 = sprite.getU(x1 * 16.0F);
        float v0 = sprite.getV((1.0F - y1) * 16.0F);
        float v1 = sprite.getV((1.0F - y0) * 16.0F);
        float nz = positive ? 1 : -1;
        if (positive) {
            vertex(consumer, pose, x0, y1, z, r, g, b, a, u0, v0, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x0, y0, z, r, g, b, a, u0, v1, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x1, y0, z, r, g, b, a, u1, v1, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x1, y1, z, r, g, b, a, u1, v0, overlay, light, 0, 0, nz);
        } else {
            vertex(consumer, pose, x1, y1, z, r, g, b, a, u1, v0, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x1, y0, z, r, g, b, a, u1, v1, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x0, y0, z, r, g, b, a, u0, v1, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x0, y1, z, r, g, b, a, u0, v0, overlay, light, 0, 0, nz);
        }
    }

    private void sideX(VertexConsumer consumer, PoseStack.Pose pose, float z0, float z1, float y0, float y1, float x,
                       Face face, BlockState state, Level level, BlockPos pos, int overlay, int light, boolean positive) {
        int rgb = PlantTint.color(state, level, pos, face.tint);
        float shade = 0.6F;
        float r = shade * (rgb >> 16 & 255) / 255.0F;
        float g = shade * (rgb >> 8 & 255) / 255.0F;
        float b = shade * (rgb & 255) / 255.0F;
        tintedSideX(consumer, pose, z0, z1, y0, y1, x, face, r, g, b, 1, overlay, light, positive);
    }

    private void tintedSideX(VertexConsumer consumer, PoseStack.Pose pose, float z0, float z1, float y0, float y1, float x,
                             Face face, float r, float g, float b, float a, int overlay, int light, boolean positive) {
        TextureAtlasSprite sprite = face.sprite;
        float u0 = sprite.getU(z0 * 16.0F);
        float u1 = sprite.getU(z1 * 16.0F);
        float v0 = sprite.getV((1.0F - y1) * 16.0F);
        float v1 = sprite.getV((1.0F - y0) * 16.0F);
        float nx = positive ? 1 : -1;
        if (positive) {
            vertex(consumer, pose, x, y1, z1, r, g, b, a, u0, v0, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y0, z1, r, g, b, a, u0, v1, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y0, z0, r, g, b, a, u1, v1, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y1, z0, r, g, b, a, u1, v0, overlay, light, nx, 0, 0);
        } else {
            vertex(consumer, pose, x, y1, z0, r, g, b, a, u1, v0, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y0, z0, r, g, b, a, u1, v1, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y0, z1, r, g, b, a, u0, v1, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y1, z1, r, g, b, a, u0, v0, overlay, light, nx, 0, 0);
        }
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, float x, float y, float z,
                               float r, float g, float b, float a, float u, float v, int overlay, int light,
                               float nx, float ny, float nz) {
        consumer.vertex(pose.pose(), x, y, z).color(r, g, b, a).uv(u, v).overlayCoords(overlay)
                .uv2(light).normal(pose.normal(), nx, ny, nz).endVertex();
    }

    private record Face(TextureAtlasSprite sprite, int tint) {}

    private static final class ModelInfo {
        final float minX, minY, minZ, maxX, maxY, maxZ;
        final int quads;
        final boolean dense;
        final int tint;
        final TextureAtlasSprite sprite;
        final List<RenderType> types;
        /** Only a plain crossed-planes plant may be swapped for the single covering plane. */
        final boolean cross;

        ModelInfo(float minX, float minY, float minZ, float maxX, float maxY, float maxZ, int quads, boolean dense,
                  int tint, TextureAtlasSprite sprite, List<RenderType> types, boolean cross) {
            this.cross = cross;
            this.minX = minX;
            this.minY = minY;
            this.minZ = minZ;
            this.maxX = maxX;
            this.maxY = maxY;
            this.maxZ = maxZ;
            this.quads = quads;
            this.dense = dense;
            this.tint = tint;
            this.sprite = sprite;
            this.types = types;
        }

        static ModelInfo fallback() {
            return new ModelInfo(0, 0, 0, 1, 1, 1, 0, false, -1, null, List.of(), false);
        }
    }
}
