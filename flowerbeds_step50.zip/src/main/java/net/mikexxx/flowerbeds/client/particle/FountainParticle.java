package net.mikexxx.flowerbeds.client.particle;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** A drop of fountain water: shot up, falls in an arc and vanishes when it is back at the height it started. */
public class FountainParticle extends TextureSheetParticle {
    private final double startY;

    private FountainParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz,
                             SpriteSet sprites) {
        super(level, x, y, z, vx, vy, vz);
        this.startY = y;
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.hasPhysics = false;
        this.lifetime = 40;
        this.quadSize = 0.07F + random.nextFloat() * 0.05F;
        setColor(1.0F, 1.0F, 1.0F);
        setAlpha(0.85F);
        pickSprite(sprites);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime || (this.yd < 0 && this.y <= this.startY - 0.02)) {
            this.remove();
            return;
        }
        this.yd -= 0.04;
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.99;
        this.zd *= 0.99;
    }

    /**
     * Drawn as a small six-panel drop: three panels turned around the flight direction (each seen from both
     * sides), stretched along the way the drop is moving. Because the direction changes along the arc, the spray
     * bends over like the arches of a real fountain instead of showing flat camera-facing squares.
     */
    @Override
    public void render(VertexConsumer buffer, Camera camera, float partialTick) {
        Vec3 cam = camera.getPosition();
        float px = (float) (Mth.lerp(partialTick, this.xo, this.x) - cam.x);
        float py = (float) (Mth.lerp(partialTick, this.yo, this.y) - cam.y);
        float pz = (float) (Mth.lerp(partialTick, this.zo, this.z) - cam.z);
        Vector3f v = new Vector3f((float) this.xd, (float) this.yd, (float) this.zd);
        float speed = v.length();
        if (speed < 1.0E-4F) {
            v.set(0.0F, 1.0F, 0.0F);
        } else {
            v.div(speed);
        }
        float half = Mth.clamp(speed * 1.6F, 0.05F, 0.22F);
        float w = this.quadSize * 0.5F;
        Vector3f a = v.cross(new Vector3f(0.0F, 1.0F, 0.0F), new Vector3f());
        if (a.lengthSquared() < 1.0E-4F) {
            a.set(1.0F, 0.0F, 0.0F);
        }
        a.normalize();
        Vector3f b = v.cross(a, new Vector3f()).normalize();
        float u0 = getU0();
        float u1 = getU1();
        float v0 = getV0();
        float v1 = getV1();
        int light = getLightColor(partialTick);
        for (int k = 0; k < 3; k++) {
            float ang = k * (float) Math.PI / 3.0F;
            float cs = Mth.cos(ang) * w;
            float sn = Mth.sin(ang) * w;
            float sx = a.x * cs + b.x * sn;
            float sy = a.y * cs + b.y * sn;
            float sz = a.z * cs + b.z * sn;
            float hx = v.x * half;
            float hy = v.y * half;
            float hz = v.z * half;
            float[][] c = {
                    {px + hx - sx, py + hy - sy, pz + hz - sz, u1, v0},
                    {px + hx + sx, py + hy + sy, pz + hz + sz, u0, v0},
                    {px - hx + sx, py - hy + sy, pz - hz + sz, u0, v1},
                    {px - hx - sx, py - hy - sy, pz - hz - sz, u1, v1}};
            for (int i = 0; i < 4; i++) {
                put(buffer, c[i], light);
            }
            for (int i = 3; i >= 0; i--) {
                put(buffer, c[i], light);
            }
        }
    }

    private void put(VertexConsumer buffer, float[] p, int light) {
        buffer.vertex(p[0], p[1], p[2]).uv(p[3], p[4]).color(this.rCol, this.gCol, this.bCol, this.alpha)
                .uv2(light).endVertex();
    }

    @Override
    protected int getLightColor(float partialTick) {
        int base = super.getLightColor(partialTick);
        return (base & 0xFFFF0000) | Math.max(base & 0xFFFF, 0xA0);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new FountainParticle(level, x, y, z, vx, vy, vz, sprites);
        }
    }
}
