package net.mikexxx.flowerbeds.client.renderer;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Tint colours for blocks that are drawn by a bed instead of by the chunk renderer.
 *
 * Asking the block colours for a tint averages the biomes around the block, which is far too much work to repeat
 * for every bed, every frame. Biome colours hardly ever change, so each answer is kept for a couple of seconds.
 */
public final class PlantTint {
    private PlantTint() {}

    /** Plain green, used when a block's own colour handler cannot give a colour at this position. */
    public static final int PLACEHOLDER_GREEN = 0x7CBD6B;

    private static final long KEEP_NANOS = 2_000_000_000L;
    private static final int MAX_ENTRIES = 4096;
    private static final int WATER_KEY = -7;

    private static final class Entry {
        final BlockState state;
        final int color;
        final long until;

        Entry(BlockState state, int color, long until) {
            this.state = state;
            this.color = color;
            this.until = until;
        }
    }

    private static final Long2ObjectOpenHashMap<Entry> CACHE = new Long2ObjectOpenHashMap<>();

    /**
     * RGB colour for a tint index of the state at the given position: the real biome colour for grass,
     * foliage and water, or white when the block has no colour handler.
     */
    public static int color(BlockState state, BlockAndTintGetter level, BlockPos pos, int tintIndex) {
        if (tintIndex < 0) {
            return 0xFFFFFF;
        }
        long key = pos.asLong() * 31L + tintIndex;
        long now = System.nanoTime();
        Entry hit = CACHE.get(key);
        if (hit != null && hit.state == state && now < hit.until) {
            return hit.color;
        }
        int result;
        try {
            int color = Minecraft.getInstance().getBlockColors().getColor(state, level, pos, tintIndex);
            result = color == -1 ? 0xFFFFFF : color;
        } catch (RuntimeException e) {
            result = PLACEHOLDER_GREEN;
        }
        store(key, state, result, now);
        return result;
    }

    /** The biome water colour at a position (cached like the other tints). */
    public static int water(BlockAndTintGetter level, BlockPos pos) {
        long key = pos.asLong() * 31L + WATER_KEY;
        long now = System.nanoTime();
        Entry hit = CACHE.get(key);
        if (hit != null && now < hit.until) {
            return hit.color;
        }
        int result = BiomeColors.getAverageWaterColor(level, pos);
        store(key, null, result, now);
        return result;
    }

    private static void store(long key, BlockState state, int color, long now) {
        if (CACHE.size() > MAX_ENTRIES) {
            CACHE.clear();
        }
        CACHE.put(key, new Entry(state, color, now + KEEP_NANOS));
    }
}
