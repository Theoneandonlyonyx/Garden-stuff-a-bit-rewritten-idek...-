package net.mikexxx.flowerbeds.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.mikexxx.flowerbeds.garden.OrnamentalTrees;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Draws an Ornamental Trees tree small, at full size as one camera-facing picture of its own texture, standing in a pot. */
final class MiniTree {

    private MiniTree() {
    }

    static void render(ItemStack stack, float x, float y, float z, PoseStack poseStack, MultiBufferSource buffers,
                       int light, int overlay) {
        String name = OrnamentalTrees.nameOf(stack);
        ResourceLocation texture = new ResourceLocation(OrnamentalTrees.MOD_ID, "textures/block/" + name + ".png");
        float width = OrnamentalTrees.widthOf(name) * OrnamentalTrees.POT_SCALE;
        float height = OrnamentalTrees.heightOf(name) * OrnamentalTrees.POT_SCALE;
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(texture));
        // One picture turned to the camera around the vertical axis only, exactly like the tree mod draws it:
        // never mirrored, never a thin edge, the same from every side.
        float yaw = net.minecraft.client.Minecraft.getInstance().gameRenderer.getMainCamera().getYRot();
        poseStack.pushPose();
        poseStack.translate(x, y, z);
        poseStack.mulPose(new org.joml.Quaternionf().rotationY((float) Math.PI - yaw * ((float) Math.PI / 180.0F)));
        PoseStack.Pose pose = poseStack.last();
        float h = width / 2.0F;
        quad(consumer, pose.pose(), pose.normal(), -h, 0.0F, h, height, light, overlay);
        poseStack.popPose();
    }

    private static void quad(VertexConsumer c, Matrix4f m, Matrix3f n, float x0, float y0, float x1, float y1,
                             int light, int overlay) {
        vertex(c, m, n, x0, y0, 0.0F, 0.0F, 1.0F, light, overlay);
        vertex(c, m, n, x1, y0, 0.0F, 1.0F, 1.0F, light, overlay);
        vertex(c, m, n, x1, y1, 0.0F, 1.0F, 0.0F, light, overlay);
        vertex(c, m, n, x0, y1, 0.0F, 0.0F, 0.0F, light, overlay);
    }

    private static void vertex(VertexConsumer c, Matrix4f m, Matrix3f n, float x, float y, float z, float u, float v,
                               int light, int overlay) {
        c.vertex(m, x, y, z).color(255, 255, 255, 255).uv(u, v).overlayCoords(overlay).uv2(light)
                .normal(n, 0.0F, 1.0F, 0.0F).endVertex();
    }
}
