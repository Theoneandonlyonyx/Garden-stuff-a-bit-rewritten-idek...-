# Step 37 changes
- German language (`de_de.json`): every block, item, container and message.
- Performance:
  - Biome tint colours (grass, foliage, vines, water) are cached for two seconds instead of being averaged over the surrounding biomes for every bed on every frame. This was the biggest per-frame cost.
  - Water, lava and milk sprite lookups use fixed constants instead of building a new resource location every frame.
  - Beds and window boxes are drawn up to 32 blocks away (was 40), and single plants up to 36 (was 48).
