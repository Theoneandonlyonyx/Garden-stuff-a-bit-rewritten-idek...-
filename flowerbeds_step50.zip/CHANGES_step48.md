# Step 48 (on step 47)
- **China pot recipe**: the blue dye in the middle is gone. It is now the same shape as the other large pots: fine china in a ring (`F F / F F / FFF`).
- **Bathbombs**: both are now 2x2 and orderless (shapeless, 4 ingredients, any slot).
  - Sakura: pink petals, pink dye, sugar, sweet berries.
  - Violet: allium, purple dye, sugar, amethyst shard.
- **Sneak + pink petals in pink water is gone** (`BathEvents` and `LargePotBlock`). The sakura bathbomb is now the only way to aromatize water pink. Pink petals plant like normal again.
- **Window box vine - step 47 undone**: the second, mirrored strip is removed. Back to one strip per layer, same shape, same vanilla vine texture, no new look.
- **Window box vine - the marked gap closed** (between the vine on the box and the little tip at the bottom). Cause: the vanilla vine texture has transparent holes, and where the drape gets narrow a whole row could land on a hole, so the vine broke off. Now every row of the drape checks which texels of the texture are opaque and reads from the nearest ones (slides sideways first, then to a neighbouring row), and the drape is never thinner than one texel. Shape and look are unchanged; only the gap is filled. If the texture cannot be read for some reason the old behaviour is used.
- Not compiled here (no Minecraft jars): syntax and JSON checked only.
