# Step 45 (on step 44) - Aspect 3: spray particle shape
- Fountain drops are now small six-panel drops: three panels turned around the flight direction, each visible from both sides, stretched along the way the drop moves. The direction changes along the arc, so the spray bends over like your drawn arches instead of flat squares.
- Only `FountainParticle.java` changed. Not compiled here.
