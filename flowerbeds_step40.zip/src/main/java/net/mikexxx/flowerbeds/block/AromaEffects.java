package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.registry.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The particles of aromatized water, run on the client every tick while the water is aromatic, day and night.
 * In a pot they are spread evenly over the water. In a birdbath they favour the rim: the sides that are not
 * joined to another birdbath, so a big bath shows them around its edge.
 */
public final class AromaEffects {
    private static final double RANGE = 24.0;

    private AromaEffects() {
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, LargePotBlockEntity pot) {
        if (!pot.isAromaticWater()) {
            return;
        }
        if (level.getNearestPlayer(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, RANGE, false) == null) {
            return;
        }
        RandomSource random = level.random;
        if (random.nextFloat() < 0.12F) {
            spawn(level, pos, state, pot, ModParticles.AROMA_GLINT.get(), random, 0);
        }
        if (random.nextFloat() < 0.08F) {
            spawn(level, pos, state, pot, ModParticles.AROMA_BUBBLE.get(), random, 1);
        }
        if (random.nextFloat() < 0.09F) {
            spawn(level, pos, state, pot, ModParticles.AROMA_PETAL.get(), random, 2);
        }
    }

    /** kind: 0 glint, 1 bubble, 2 petal. */
    private static void spawn(Level level, BlockPos pos, BlockState state, LargePotBlockEntity pot,
                              ParticleOptions particle, RandomSource random, int kind) {
        if (!(state.getBlock() instanceof LargePotBlock block)) {
            return;
        }
        boolean west = state.getValue(LargePotBlock.WEST);
        boolean east = state.getValue(LargePotBlock.EAST);
        boolean north = state.getValue(LargePotBlock.NORTH);
        boolean south = state.getValue(LargePotBlock.SOUTH);
        boolean bath = block instanceof BirdbathBlock;
        float inset = bath ? 2.0F / 16.0F : 2.0F / 16.0F;
        float x0 = west ? 0.0F : inset;
        float x1 = east ? 1.0F : 1.0F - inset;
        float z0 = north ? 0.0F : inset;
        float z1 = south ? 1.0F : 1.0F - inset;
        float x = x0 + random.nextFloat() * (x1 - x0);
        float z = z0 + random.nextFloat() * (z1 - z0);

        if (bath) {
            // Favour the barriers: pick one of the sides that has no bath next to it.
            int closed = (north ? 0 : 1) + (east ? 0 : 1) + (south ? 0 : 1) + (west ? 0 : 1);
            if (closed == 0) {
                if (random.nextFloat() > 0.2F) {
                    return;
                }
            } else {
                int pick = random.nextInt(closed);
                float depth = (1.8F + random.nextFloat() * 2.4F) / 16.0F;
                if (!north && pick-- == 0) {
                    z = z0 + depth;
                } else if (!east && pick-- == 0) {
                    x = x1 - depth;
                } else if (!south && pick-- == 0) {
                    z = z1 - depth;
                } else if (!west && pick == 0) {
                    x = x0 + depth;
                }
            }
        }

        float top = Math.min(0.98F, pot.waterSurface());
        float bottom = block.fillBottom();
        if (pot.isTank() && state.getValue(GlassPotBlock.DOWN)) {
            bottom = 0.0F;
        }
        double y;
        double vy;
        switch (kind) {
            case 0 -> {
                y = top - 0.04F + random.nextFloat() * 0.12F;
                vy = 0.010 + random.nextDouble() * 0.010;
            }
            case 1 -> {
                // Bubbles rise from anywhere in the water; in the shallow bath that is just under the surface.
                y = bottom + random.nextFloat() * Math.max(0.0F, top - bottom - 0.02F);
                vy = 0.014 + random.nextDouble() * 0.016;
            }
            default -> {
                y = top + 0.02F + random.nextFloat() * 0.08F;
                vy = 0.003 + random.nextDouble() * 0.006;
            }
        }
        // Amphora and china pot: the particles stay inside the curved water, never in or behind the wall.
        PotFill.Slice[] shaped = PotFill.slices(state);
        if (shaped != null) {
            int k = Math.max(0, Math.min(shaped.length - 1, (int) Math.floor(y * 16.0) - 2));
            float[][] rects = shaped[k].rects();
            if (rects.length > 0) {
                float[] q = rects[random.nextInt(rects.length)];
                x = (q[0] + random.nextFloat() * (q[2] - q[0])) / 16.0F;
                z = (q[1] + random.nextFloat() * (q[3] - q[1])) / 16.0F;
            }
        }
        level.addParticle(particle, pos.getX() + x, pos.getY() + y, pos.getZ() + z, 0.0, vy, 0.0);
    }
}
