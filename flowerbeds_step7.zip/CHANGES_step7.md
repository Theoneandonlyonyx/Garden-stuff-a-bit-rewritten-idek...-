# Step 7

## Growth stages
- Each plant now uses its own real stage count, not the shared stage property of the whole mod.
  - Plants with stages (the two-block plants, crops, ...) keep them: they start small and grow with bone meal in pots and beds, as before.
  - Plants without stages (brugmansia / angel's trumpets and the other large plants) are drawn at their full height straight away and do not grow with bone meal.
- Nothing forces a starting stage any more.

## Carried over from step 6
- Large plants are drawn at their real height (2 blocks = bottom + top, 3 = + middle, 4+ = more middles).
- Pot block states cut from about 524k to 32k (liquid in the block entity, light in 4 steps) for RAM and load time.
- Beds draw within 40 blocks; far parts of very tall plants are skipped; light looked up once per four blocks.
- No stacked-plants tag; growth limit 256 blocks.
