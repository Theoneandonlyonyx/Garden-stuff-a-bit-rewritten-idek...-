package net.mikexxx.flowerbeds.client.model;

import net.mikexxx.flowerbeds.block.entity.BeddingBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.ChunkRenderTypeSet;
import net.minecraftforge.client.model.BakedModelWrapper;
import net.minecraftforge.client.model.data.ModelData;

import java.util.List;

/**
 * The model of a bedding block. It hands out the quads of the block the bedding was made from, so the faces are
 * part of the normal chunk mesh: no per-frame drawing, nothing that can shimmer or move. If the original is not
 * known yet it falls back to the plain dirt cube the blockstate points at.
 */
public class BeddingBakedModel extends BakedModelWrapper<BakedModel> {

    public BeddingBakedModel(BakedModel fallback) {
        super(fallback);
    }

    private static BakedModel modelOf(BlockState source) {
        return Minecraft.getInstance().getBlockRenderer().getBlockModel(source);
    }

    @Override
    public List<BakedQuad> getQuads(BlockState state, Direction side, RandomSource rand,
                                    ModelData data, RenderType renderType) {
        BlockState source = data.get(BeddingBlockEntity.ORIGINAL);
        if (source == null) {
            return super.getQuads(state, side, rand, data, renderType);
        }
        return modelOf(source).getQuads(source, side, rand, ModelData.EMPTY, renderType);
    }

    @Override
    public ChunkRenderTypeSet getRenderTypes(BlockState state, RandomSource rand,
                                             ModelData data) {
        BlockState source = data.get(BeddingBlockEntity.ORIGINAL);
        if (source == null) {
            return super.getRenderTypes(state, rand, data);
        }
        return modelOf(source).getRenderTypes(source, rand, ModelData.EMPTY);
    }

    @Override
    public TextureAtlasSprite getParticleIcon(ModelData data) {
        BlockState source = data.get(BeddingBlockEntity.ORIGINAL);
        if (source == null) {
            return super.getParticleIcon(data);
        }
        return modelOf(source).getParticleIcon(ModelData.EMPTY);
    }
}
