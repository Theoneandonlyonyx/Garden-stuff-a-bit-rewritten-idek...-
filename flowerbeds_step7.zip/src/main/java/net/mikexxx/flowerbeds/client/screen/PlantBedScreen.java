package net.mikexxx.flowerbeds.client.screen;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.menu.PlantBedMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/**
 * Arrange Plants. Soil, bedding and pots all use this one layout: a centre place, four around it and a ring of
 * border places. A border place that has no connected block to share it is shown greyed out and unlocks when a
 * neighbour appears. The layout never turns; north is always at the top.
 */
public class PlantBedScreen extends AbstractContainerScreen<PlantBedMenu> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(PmpMikexxx.MODID, "textures/gui/plant_bed.png");

    /** Where the 18-pixel slot tile sits in the GUI texture. */
    private static final int TILE_U = 200;
    private static final int TILE_V = 0;
    private static final int TILE_SIZE = 18;
    /** Dark veil over a place that is locked until a neighbour shares it. */
    private static final int LOCKED_VEIL = 0xC0555555;

    public PlantBedScreen(PlantBedMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 204;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight, 256, 256);
        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            Slot slot = menu.getSlot(i);
            int x = leftPos + slot.x;
            int y = topPos + slot.y;
            graphics.blit(TEXTURE, x - 1, y - 1, TILE_U, TILE_V, TILE_SIZE, TILE_SIZE, 256, 256);
            if (!slot.isActive()) {
                graphics.fill(x, y, x + 16, y + 16, LOCKED_VEIL);
            }
        }
        // The grid never turns, so say which way is north.
        int right = leftPos + PlantBedMenu.GRID_ORIGIN_X + PlantBedMenu.GRID_STEP * 5 + 4;
        graphics.drawString(this.font, "N", right, topPos + PlantBedMenu.GRID_ORIGIN_Y + 4, 0x404040, false);
        graphics.drawString(this.font, "^", right, topPos + PlantBedMenu.GRID_ORIGIN_Y + 13, 0x404040, false);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 0x404040, false);
        graphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY,
                0x404040, false);
    }
}
