package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.BeddingBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;

import java.util.List;

/**
 * A block turned into a flowerbed with the trowel. It looks like the block it was made from (its faces are baked
 * into the chunk like any other block, so they are static), connects to soil blocks, and has the Arrange Plants GUI. Breaking it drops what the
 * original block would have dropped.
 */
public class BeddingBlock extends PlantBedBlock {

    public BeddingBlock(BlockBehaviour.Properties properties) {
        super(properties.lightLevel(PlantBedBlock::lightOf));
        registerDefaultState(this.stateDefinition.any().setValue(LIGHT, 0));
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new BeddingBlockEntity(pos, state);
    }

    @Override
    public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
        if (builder.getOptionalParameter(LootContextParams.BLOCK_ENTITY) instanceof BeddingBlockEntity bedding) {
            return bedding.getOriginalState().getDrops(builder);
        }
        return List.of(new ItemStack(net.minecraft.world.level.block.Blocks.DIRT));
    }

    @Override
    public ItemStack getCloneItemStack(BlockGetter level, BlockPos pos, BlockState state) {
        if (level.getBlockEntity(pos) instanceof BeddingBlockEntity bedding) {
            return new ItemStack(bedding.getOriginalState().getBlock());
        }
        return new ItemStack(net.minecraft.world.level.block.Blocks.DIRT);
    }
}
