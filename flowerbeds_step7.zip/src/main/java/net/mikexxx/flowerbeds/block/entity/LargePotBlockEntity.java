package net.mikexxx.flowerbeds.block.entity;

import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

public class LargePotBlockEntity extends PlantBedBlockEntity {

    /** Dyed water colour as RGB, or -1 when undyed. Only used while the pot holds water. */
    private int dyeColor = -1;
    /** The block the pot is filled with (dirt, sand, ...), or null. A pot holds a substrate or a liquid, not both. */
    private Block substrate;
    /** The liquid in the pot. Kept here and not in the block state, which keeps the number of block states small. */
    private LargePotBlock.Liquid liquid = LargePotBlock.Liquid.NONE;

    public LargePotBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.LARGE_POT.get(), pos, state);
    }

    /** Plants sit on the fill. Over water they stand just above the surface so aquatic plants stay visible. */
    @Override
    public float bedHeight() {
        if (getLiquid() != LargePotBlock.Liquid.NONE) {
            return GardenLayout.POT_WATER_TOP + 0.03F;
        }
        return GardenLayout.POT_FILL_TOP + 0.002F;
    }

    public int getDyeColor() {
        return dyeColor;
    }

    public void setDyeColor(int rgb) {
        this.dyeColor = rgb;
        onSlotsChanged();
    }

    public Block getSubstrate() {
        return substrate;
    }

    @Override
    public BlockState substrateState() {
        return substrate == null ? null : substrate.defaultBlockState();
    }

    public LargePotBlock.Liquid getLiquid() {
        return liquid;
    }

    /** Lava lights the pot like any other light source. */
    @Override
    public int lightLevel() {
        return liquid == LargePotBlock.Liquid.LAVA ? 15 : super.lightLevel();
    }

    /** Fills the pot with a liquid (which empties any substrate), or empties the liquid with NONE. */
    public void setLiquid(LargePotBlock.Liquid liquid) {
        applyFill(liquid != LargePotBlock.Liquid.NONE ? null : substrate, liquid);
    }

    /** Fills the pot with a substrate block (which empties any liquid), or empties it with null. */
    public void setSubstrate(Block block) {
        applyFill(block, block != null ? LargePotBlock.Liquid.NONE : getLiquid());
    }

    /** What the pot holds right now, as the item that would give it back (a bucket or a block item). */
    public ItemStack removeFill() {
        if (substrate != null) {
            return new ItemStack(substrate);
        }
        return switch (getLiquid()) {
            case WATER -> new ItemStack(Items.WATER_BUCKET);
            case LAVA -> new ItemStack(Items.LAVA_BUCKET);
            case MILK -> new ItemStack(Items.MILK_BUCKET);
            default -> ItemStack.EMPTY;
        };
    }

    private void applyFill(Block newSubstrate, LargePotBlock.Liquid newLiquid) {
        this.substrate = newSubstrate;
        this.liquid = newLiquid;
        if (newLiquid != LargePotBlock.Liquid.WATER) {
            dyeColor = -1;
        }
        if (level != null) {
            BlockState state = level.getBlockState(worldPosition);
            if (state.getBlock() instanceof LargePotBlock
                    && state.getValue(LargePotBlock.SUBSTRATE) != (newSubstrate != null)) {
                level.setBlock(worldPosition, state.setValue(LargePotBlock.SUBSTRATE, newSubstrate != null),
                        Block.UPDATE_ALL);
            }
        }
        onSlotsChanged();
    }

    @Override
    public void dropContents() {
        super.dropContents();
        if (level != null && !level.isClientSide && substrate != null) {
            Block.popResource(level, worldPosition, new ItemStack(substrate));
            substrate = null;
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("DyeColor", dyeColor);
        tag.putString("Liquid", liquid.name());
        if (substrate != null) {
            ResourceLocation key = ForgeRegistries.BLOCKS.getKey(substrate);
            if (key != null) {
                tag.putString("Substrate", key.toString());
            }
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        dyeColor = tag.contains("DyeColor") ? tag.getInt("DyeColor") : -1;
        liquid = LargePotBlock.Liquid.NONE;
        if (tag.contains("Liquid")) {
            try {
                liquid = LargePotBlock.Liquid.valueOf(tag.getString("Liquid"));
            } catch (IllegalArgumentException ignored) {
                liquid = LargePotBlock.Liquid.NONE;
            }
        }
        substrate = null;
        if (tag.contains("Substrate")) {
            ResourceLocation key = ResourceLocation.tryParse(tag.getString("Substrate"));
            if (key != null && ForgeRegistries.BLOCKS.containsKey(key)) {
                substrate = ForgeRegistries.BLOCKS.getValue(key);
            }
        }
    }
}
