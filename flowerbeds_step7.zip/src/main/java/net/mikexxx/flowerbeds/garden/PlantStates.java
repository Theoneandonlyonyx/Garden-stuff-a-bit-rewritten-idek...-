package net.mikexxx.flowerbeds.garden;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.BambooStalkBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.CactusBlock;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.GrowingPlantBlock;
import net.minecraft.world.level.block.KelpBlock;
import net.minecraft.world.level.block.KelpPlantBlock;
import net.minecraft.world.level.block.SeaPickleBlock;
import net.minecraft.world.level.block.SeagrassBlock;
import net.minecraft.world.level.block.SugarCaneBlock;
import net.minecraft.world.level.block.TallSeagrassBlock;
import net.minecraft.world.level.block.WaterlilyBlock;
import net.minecraft.world.level.block.GrowingPlantHeadBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BambooLeaves;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.ArrayList;
import java.util.List;

/** Turns a stored item into the block state(s) that are drawn and grown. */
public final class PlantStates {
    private PlantStates() {}

    /**
     * Safety cap for plants that grow by stacking (sugar cane, cactus, bamboo, kelp). High enough that a
     * normal garden never hits it. There is no datapack tag to opt into this; vanilla stackers are detected
     * directly, so no tag is needed.
     */
    public static final int MAX_HEIGHT = 256;


    /** Growth-stage property names, in priority order. */
    private static final String[] GROWTH_NAMES = {"age", "stage", "growth", "growth_stage"};

    /** The growth-stage property of a block state, or null if it has none. */
    public static IntegerProperty growthProperty(BlockState state) {
        for (String name : GROWTH_NAMES) {
            for (Property<?> property : state.getProperties()) {
                if (property instanceof IntegerProperty ip && property.getName().equals(name)) {
                    return ip;
                }
            }
        }
        return null;
    }

    public static int maxOf(IntegerProperty property) {
        return property.getPossibleValues().stream().max(Integer::compare).orElse(0);
    }

    public static int minOf(IntegerProperty property) {
        return property.getPossibleValues().stream().min(Integer::compare).orElse(0);
    }

    /**
     * The "how many" property of a block that stacks several of itself into one block: pink petals and
     * wildflowers (flower_amount), leaf litter (segment_amount), candles, sea pickles, turtle eggs, and any
     * modded block with an integer property named like "..._amount". Null if the block does not stack.
     */
    public static IntegerProperty amountProperty(BlockState state) {
        for (Property<?> property : state.getProperties()) {
            if (property instanceof IntegerProperty ip) {
                String name = property.getName();
                if (name.contains("amount") || name.equals("candles") || name.equals("pickles") || name.equals("eggs")) {
                    return ip;
                }
            }
        }
        return null;
    }

    /** How many of this item fit in one bed slot: the block's own maximum amount (4 for petals), or 1. */
    public static int maxAmount(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return 1;
        }
        IntegerProperty amount = amountProperty(blockItem.getBlock().defaultBlockState());
        if (amount == null) {
            return 1;
        }
        return Math.max(1, Math.min(maxOf(amount), stack.getMaxStackSize()));
    }

    /** Whether the item is a flat cover (petals, leaf litter, carpets) that belongs in the groundcover slot. */
    public static boolean isGroundcover(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        BlockState state = blockItem.getBlock().defaultBlockState();
        IntegerProperty amount = amountProperty(state);
        return state.getBlock() instanceof CarpetBlock || (amount != null && amount.getName().endsWith("_amount"));
    }

    /**
     * Plants that grow by adding another copy above themselves. Detected from the vanilla classes so no tag
     * is required.
     */
    public static boolean isVerticalGrower(BlockState state) {
        Block block = state.getBlock();
        return block instanceof BambooStalkBlock || block instanceof SugarCaneBlock
                || block instanceof CactusBlock || block instanceof GrowingPlantBlock;
    }

    /**
     * Whether bone meal grows this plant in the world. Plants that do not accept bone meal do not grow in a
     * pot either. The check is the block type, not a world position: the plant is drawn inside the pot, so a
     * position test against the pot block would wrongly refuse it.
     */
    public static boolean canBonemeal(BlockState state) {
        return state.getBlock() instanceof BonemealableBlock;
    }

    /** The highest growth age bone meal can bring a plant to, or -1 if the plant does not grow. */
    public static int maxAge(BlockState state) {
        if (!canBonemeal(state)) {
            return -1;
        }
        if (isVerticalGrower(state)) {
            return MAX_HEIGHT - 1;
        }
        IntegerProperty growth = growthProperty(state);
        if (growth == null) {
            return -1;
        }
        int cap = stageCap(state, growth);
        return cap <= minOf(growth) ? -1 : cap;
    }

    /** Seagrass, kelp, coral and the like. Drawn above the water line when a pot or box holds water. */
    public static boolean isAquatic(BlockState state) {
        Block block = state.getBlock();
        return block instanceof SeagrassBlock
                || block instanceof TallSeagrassBlock
                || block instanceof KelpBlock
                || block instanceof KelpPlantBlock
                || block instanceof SeaPickleBlock
                || block instanceof WaterlilyBlock
                || state.is(BlockTags.CORALS)
                || state.is(BlockTags.CORAL_PLANTS)
                || state.is(BlockTags.WALL_CORALS);
    }

    /** Block state drawn for a stored item at a given growth age. The stack size sets the amount (petals, candles). Candles are drawn lit. */
    public static BlockState stateFor(ItemStack stack, int age) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return Blocks.AIR.defaultBlockState();
        }
        BlockState state = blockItem.getBlock().defaultBlockState();
        IntegerProperty growth = isVerticalGrower(state) ? null : growthProperty(state);
        if (growth != null) {
            int clamped = Math.max(minOf(growth), Math.min(age, stageCap(state, growth)));
            state = state.setValue(growth, clamped);
        }
        IntegerProperty amount = amountProperty(state);
        if (amount != null) {
            int clamped = Math.max(minOf(amount), Math.min(stack.getCount(), maxOf(amount)));
            state = state.setValue(amount, clamped);
        }
        if (stack.is(GardenLayout.CANDLES)) {
            for (Property<?> property : state.getProperties()) {
                if (property instanceof BooleanProperty bp && property.getName().equals("lit")) {
                    state = state.setValue(bp, true);
                }
            }
        }
        return state;
    }

    /**
     * The blocks drawn for a stored item, bottom to top. A double plant is its lower and upper half; a
     * vertical grower (bamboo, sugar cane, cactus, ...) is one block per growth age, up to
     * {@link #MAX_HEIGHT}. Everything else is a single block.
     */
    public static List<BlockState> columnFor(ItemStack stack, int age) {
        BlockState state = stateFor(stack, age);
        List<BlockState> column = new ArrayList<>();
        if (state.isAir()) {
            return column;
        }
        if (state.hasProperty(BlockStateProperties.DOUBLE_BLOCK_HALF)) {
            column.add(state.setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER));
            column.add(state.setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.UPPER));
            return column;
        }
        List<BlockState> sections = sectionsOf(state);
        if (sections != null) {
            return sections;
        }
        if (isVerticalGrower(state)) {
            int height = Math.max(1, Math.min(age + 1, MAX_HEIGHT));
            Block stem = state.getBlock() instanceof GrowingPlantHeadBlock ? stemOf(state.getBlock()) : null;
            for (int i = 0; i < height; i++) {
                if (state.getBlock() instanceof BambooStalkBlock) {
                    column.add(bambooSegment(state, i, height));
                } else if (stem != null && i < height - 1) {
                    column.add(stem.defaultBlockState());
                } else {
                    column.add(state);
                }
            }
            return column;
        }
        column.add(state);
        return column;
    }


    /** Property names that modded tall plants use to say which part of the plant a block is. */
    private static final String[] SECTION_NAMES = {"half", "part", "section", "segment", "tall_part", "stage_part"};

    /**
     * Plants that are taller than two blocks (modded three, four or five block plants) name their parts with an
     * enum property such as lower / middle / upper. Every value is one block of the plant, bottom first, so the
     * whole plant is drawn and nothing is cut off. Returns null if the block has no such property.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static List<BlockState> sectionsOf(BlockState state) {
        int wanted = sectionHeight(state);
        for (String name : SECTION_NAMES) {
            for (Property<?> property : state.getProperties()) {
                if (!(property instanceof EnumProperty<?> enumProperty) || !property.getName().equals(name)) {
                    continue;
                }
                List<Object[]> ranked = new ArrayList<>();
                for (Object value : enumProperty.getPossibleValues()) {
                    if (!(value instanceof StringRepresentable named)) {
                        ranked = null;
                        break;
                    }
                    ranked.add(new Object[] {sectionRank(named.getSerializedName()), value});
                }
                if (ranked == null || ranked.size() < 2) {
                    continue;
                }
                ranked.sort((a, b) -> Integer.compare((Integer) a[0], (Integer) b[0]));
                if ((Integer) ranked.get(0)[0] == 1 && (Integer) ranked.get(ranked.size() - 1)[0] == 1) {
                    continue;
                }
                List<BlockState> column = new ArrayList<>();
                if (wanted > 0) {
                    // The block says how tall it really is: bottom, as many middles as it needs, top.
                    Object bottom = ranked.get(0)[1];
                    Object top = ranked.get(ranked.size() - 1)[1];
                    Object middle = ranked.size() > 2 ? ranked.get(1)[1] : null;
                    for (int i = 0; i < wanted; i++) {
                        Object value = i == 0 ? bottom : i == wanted - 1 ? top : middle != null ? middle : bottom;
                        column.add(state.setValue((Property) property, (Comparable) value));
                    }
                    return column;
                }
                for (Object[] entry : ranked) {
                    column.add(state.setValue((Property) property, (Comparable) entry[1]));
                }
                return column;
            }
        }
        return null;
    }

    /** Lower parts first (0), unknown middles next (1), upper parts last (2). */
    private static int sectionRank(String name) {
        String n = name.toLowerCase(java.util.Locale.ROOT);
        if (n.contains("lower") || n.contains("bottom") || n.equals("base") || n.contains("root")) {
            return 0;
        }
        if (n.contains("upper") || n.contains("top") || n.contains("head") || n.contains("crown")) {
            return 2;
        }
        return 1;
    }

    /** One block of a bamboo stalk: thick when tall, with small leaves second from the top and large leaves on top. */
    private static BlockState bambooSegment(BlockState state, int index, int height) {
        if (state.hasProperty(BlockStateProperties.AGE_1)) {
            state = state.setValue(BlockStateProperties.AGE_1, height >= 6 ? 1 : 0);
        }
        if (state.hasProperty(BlockStateProperties.BAMBOO_LEAVES)) {
            BambooLeaves leaves = BambooLeaves.NONE;
            if (index == height - 1 && height >= 3) {
                leaves = BambooLeaves.LARGE;
            } else if (index == height - 1 && height == 2 || index == height - 2 && height >= 3) {
                leaves = BambooLeaves.SMALL;
            }
            state = state.setValue(BlockStateProperties.BAMBOO_LEAVES, leaves);
        }
        return state;
    }

    // ---------------------------------------------------------------------------------------------
    // Plants that know their own height (large and tall plants from other mods)
    // ---------------------------------------------------------------------------------------------

    /** How a block class exposes its height, found once by reflection and remembered. */
    private static final class TallInfo {
        java.lang.reflect.Method heightAt;
        java.lang.reflect.Field height;
        java.lang.reflect.Field tallFrom;
        java.lang.reflect.Method lastStage;
        java.lang.reflect.Field maxStage;
    }

    private static final java.util.Map<Class<?>, TallInfo> TALL_INFO = new java.util.concurrent.ConcurrentHashMap<>();

    private static TallInfo tallInfo(Class<?> type) {
        return TALL_INFO.computeIfAbsent(type, c -> {
            TallInfo info = new TallInfo();
            for (Class<?> k = c; k != null && k != Block.class && k != Object.class; k = k.getSuperclass()) {
                try {
                    if (info.heightAt == null) {
                        java.lang.reflect.Method m = k.getDeclaredMethod("heightAt", int.class);
                        if (m.getReturnType() == int.class) {
                            m.setAccessible(true);
                            info.heightAt = m;
                        }
                    }
                } catch (ReflectiveOperationException | RuntimeException ignored) {
                    // not on this class
                }
                try {
                    if (info.lastStage == null) {
                        java.lang.reflect.Method m = k.getDeclaredMethod("lastStage");
                        if (m.getReturnType() == int.class) {
                            m.setAccessible(true);
                            info.lastStage = m;
                        }
                    }
                } catch (ReflectiveOperationException | RuntimeException ignored) {
                    // not on this class
                }
                info.maxStage = intField(k, "maxStage", info.maxStage);
                info.height = intField(k, "height", info.height);
                info.tallFrom = intField(k, "tallFrom", info.tallFrom);
            }
            return info;
        });
    }

    private static java.lang.reflect.Field intField(Class<?> k, String name, java.lang.reflect.Field current) {
        if (current != null) {
            return current;
        }
        try {
            java.lang.reflect.Field f = k.getDeclaredField(name);
            if (f.getType() == int.class) {
                f.setAccessible(true);
                return f;
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // not on this class
        }
        return null;
    }

    /**
     * How many blocks tall a stacked plant is at its current growth stage, or -1 if the block does not say.
     * Large plants stay one block until a certain stage and are their full height after it; a plant without
     * stages is always full height.
     */
    private static int sectionHeight(BlockState state) {
        Block block = state.getBlock();
        TallInfo info = tallInfo(block.getClass());
        if (info.heightAt == null && info.height == null) {
            return -1;
        }
        IntegerProperty growth = growthProperty(state);
        try {
            // A plant with no growth stages of its own (the large plants) is always its full height and never grows.
            if (growth == null || stageCap(state, growth) <= minOf(growth)) {
                if (info.height != null) {
                    return info.height.getInt(block);
                }
                if (info.heightAt != null && growth != null) {
                    return (Integer) info.heightAt.invoke(block, maxOf(growth));
                }
            }
            if (info.heightAt != null && growth != null) {
                return (Integer) info.heightAt.invoke(block, state.getValue(growth));
            }
            if (info.height != null) {
                int full = info.height.getInt(block);
                if (growth == null) {
                    return full;
                }
                int from = info.tallFrom != null ? info.tallFrom.getInt(block) : stageCap(state, growth);
                return state.getValue(growth) >= from ? full : 1;
            }
        } catch (ReflectiveOperationException | RuntimeException e) {
            return -1;
        }
        return -1;
    }

    /**
     * The last growth stage this particular plant really has. The stage property is often shared by every plant of
     * a mod and runs higher than one plant needs, so a plant that reports its own last stage is held to it: a plant
     * with no stages (the large plants) does not grow, and one with stages grows through exactly those.
     */
    private static int stageCap(BlockState state, IntegerProperty growth) {
        int property = maxOf(growth);
        Block block = state.getBlock();
        TallInfo info = tallInfo(block.getClass());
        try {
            if (info.lastStage != null) {
                return Math.max(minOf(growth), Math.min(property, (Integer) info.lastStage.invoke(block)));
            }
            if (info.maxStage != null) {
                return Math.max(minOf(growth), Math.min(property, info.maxStage.getInt(block)));
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // fall back to the property range
        }
        return property;
    }

    /** The stem block under a growing plant head, found by the usual naming (kelp -> kelp_plant), or null. */
    private static Block stemOf(Block head) {
        net.minecraft.resources.ResourceLocation key = net.minecraftforge.registries.ForgeRegistries.BLOCKS.getKey(head);
        if (key == null) {
            return null;
        }
        net.minecraft.resources.ResourceLocation stem =
                new net.minecraft.resources.ResourceLocation(key.getNamespace(), key.getPath() + "_plant");
        return net.minecraftforge.registries.ForgeRegistries.BLOCKS.containsKey(stem)
                ? net.minecraftforge.registries.ForgeRegistries.BLOCKS.getValue(stem) : null;
    }
}
