package net.mikexxx.flowerbeds.block.entity;

import net.mikexxx.flowerbeds.block.GlassPotBlock;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

public class LargePotBlockEntity extends PlantBedBlockEntity {

    /** Dyed water colour as RGB, or -1 when undyed. Only used while the pot holds water. */
    private int dyeColor = -1;
    /** The block the pot is filled with (dirt, sand, ...), or null. A pot holds a substrate or a liquid, not both. */
    private Block substrate;
    /** The liquid in the pot. Kept here and not in the block state, which keeps the number of block states small. */
    private LargePotBlock.Liquid liquid = LargePotBlock.Liquid.NONE;

    /** A thin layer of sand, gravel, dirt ... on the floor of a water-filled pot, under the water. */
    private Block bottomLayer;
    /** How thick that layer is: thin, but easy to see. */
    public static final float BOTTOM_LAYER_HEIGHT = 1.5F / 16.0F;

    /** How many fish and other swimmers one glass tank holds. */
    public static final int MAX_FISH = 6;
    /** The mob buckets that were put in, one per swimmer. Giving one back returns the same bucket. */
    private final List<ItemStack> fish = new ArrayList<>();
    private int fishVersion;

    public List<ItemStack> getFish() {
        return fish;
    }

    /** Changes whenever the swimmers change, so the client knows when to rebuild its models. */
    public int fishVersion() {
        return fishVersion;
    }

    public boolean addFish(ItemStack bucket) {
        if (fish.size() >= MAX_FISH) {
            return false;
        }
        fish.add(bucket.copyWithCount(1));
        fishVersion++;
        onSlotsChanged();
        return true;
    }

    public ItemStack removeFish() {
        if (fish.isEmpty()) {
            return ItemStack.EMPTY;
        }
        ItemStack last = fish.remove(fish.size() - 1);
        fishVersion++;
        onSlotsChanged();
        return last;
    }

    public Block getBottomLayer() {
        return bottomLayer;
    }

    public void setBottomLayer(Block block) {
        this.bottomLayer = block;
        onSlotsChanged();
    }

    /** Removes the floor layer and returns its block (null if there was none). */
    public Block takeBottomLayer() {
        Block taken = bottomLayer;
        if (taken != null) {
            bottomLayer = null;
            onSlotsChanged();
        }
        return taken;
    }

    /** The height of the floor plants stand on when the pot is under water: the pot floor plus any bottom layer. */
    public float floorHeight() {
        return GardenLayout.POT_FILL_BOTTOM + (bottomLayer != null ? BOTTOM_LAYER_HEIGHT : 0.0F);
    }

    /**
     * Height of the water surface in this pot's own coordinates. In a glass tank the water belongs to the pot it
     * was poured into, which can be several blocks higher up the stack.
     */
    public float waterSurface() {
        LargePotBlockEntity source = liquidSource();
        return (source.worldPosition.getY() - worldPosition.getY()) + GardenLayout.POT_WATER_TOP;
    }

    public LargePotBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.LARGE_POT.get(), pos, state);
    }

    /** True for a glass pot: a tank whose liquid is shared with the glass pots stacked above it. */
    public boolean isTank() {
        return getBlockState().getBlock() instanceof GlassPotBlock;
    }

    /**
     * The pot that holds the liquid this pot shows: itself, or for a glass pot with no liquid of its own the
     * nearest pot above in the stack that has some. Water poured into the top fills every pot below it.
     */
    public LargePotBlockEntity liquidSource() {
        LargePotBlockEntity current = this;
        for (int guard = 0; guard < 64; guard++) {
            if (current.getLiquid() != LargePotBlock.Liquid.NONE || !current.isTank()
                    || !current.getBlockState().getValue(GlassPotBlock.UP)
                    || current.level == null
                    || !(current.level.getBlockEntity(current.worldPosition.above()) instanceof LargePotBlockEntity above)) {
                return current;
            }
            current = above;
        }
        return current;
    }

    /** The liquid this pot actually shows, which for a glass pot includes the water from the pots above. */
    public LargePotBlock.Liquid effectiveLiquid() {
        return liquidSource().getLiquid();
    }

    /**
     * Plants sit on the fill. Over water they stand just above the surface so aquatic plants stay visible.
     * In a glass tank they stand on the floor of the lowest pot, under the water.
     */
    @Override
    public float bedHeight() {
        if (isTank()) {
            return floorHeight() + 0.002F;
        }
        if (getLiquid() != LargePotBlock.Liquid.NONE) {
            return GardenLayout.POT_WATER_TOP + 0.03F;
        }
        return GardenLayout.POT_FILL_TOP + 0.002F;
    }

    public int getDyeColor() {
        return dyeColor;
    }

    public void setDyeColor(int rgb) {
        this.dyeColor = rgb;
        onSlotsChanged();
    }

    public Block getSubstrate() {
        return substrate;
    }

    @Override
    public BlockState substrateState() {
        return substrate == null ? null : substrate.defaultBlockState();
    }

    public LargePotBlock.Liquid getLiquid() {
        return liquid;
    }

    /** The lowest pot of a glass stack (the one with a floor), or this pot. */
    public LargePotBlockEntity bottomOfStack() {
        LargePotBlockEntity current = this;
        for (int guard = 0; guard < 64; guard++) {
            if (!current.isTank() || !current.getBlockState().getValue(GlassPotBlock.DOWN) || current.level == null
                    || !(current.level.getBlockEntity(current.worldPosition.below()) instanceof LargePotBlockEntity below)) {
                return current;
            }
            current = below;
        }
        return current;
    }

    /** Lava lights the pot like any other light source. */
    @Override
    public int lightLevel() {
        return liquid == LargePotBlock.Liquid.LAVA ? 15 : super.lightLevel();
    }

    /** Fills the pot with a liquid (which empties any substrate), or empties the liquid with NONE. */
    public void setLiquid(LargePotBlock.Liquid liquid) {
        applyFill(liquid != LargePotBlock.Liquid.NONE ? null : substrate, liquid);
    }

    /** Fills the pot with a substrate block (which empties any liquid), or empties it with null. */
    public void setSubstrate(Block block) {
        applyFill(block, block != null ? LargePotBlock.Liquid.NONE : getLiquid());
    }

    /** What the pot holds right now, as the item that would give it back (a bucket or a block item). */
    public ItemStack removeFill() {
        if (substrate != null) {
            return new ItemStack(substrate);
        }
        return switch (getLiquid()) {
            case WATER -> new ItemStack(Items.WATER_BUCKET);
            case LAVA -> new ItemStack(Items.LAVA_BUCKET);
            case MILK -> new ItemStack(Items.MILK_BUCKET);
            default -> ItemStack.EMPTY;
        };
    }

    private void applyFill(Block newSubstrate, LargePotBlock.Liquid newLiquid) {
        this.substrate = newSubstrate;
        this.liquid = newLiquid;
        if (newLiquid != LargePotBlock.Liquid.WATER) {
            dyeColor = -1;
            // The thin floor layer belongs under water. Without water it goes back to the player's world as an item.
            if (bottomLayer != null && level != null && !level.isClientSide) {
                Block.popResource(level, worldPosition, new ItemStack(bottomLayer));
            }
            bottomLayer = null;
        }
        if (level != null) {
            BlockState state = level.getBlockState(worldPosition);
            if (state.getBlock() instanceof LargePotBlock
                    && state.getValue(LargePotBlock.SUBSTRATE) != (newSubstrate != null)) {
                level.setBlock(worldPosition, state.setValue(LargePotBlock.SUBSTRATE, newSubstrate != null),
                        Block.UPDATE_ALL);
            }
        }
        onSlotsChanged();
    }

    @Override
    public void dropContents() {
        super.dropContents();
        if (level != null && !level.isClientSide && !fish.isEmpty()) {
            for (ItemStack bucket : fish) {
                Block.popResource(level, worldPosition, bucket);
            }
            fish.clear();
            fishVersion++;
        }
        if (level != null && !level.isClientSide && substrate != null) {
            Block.popResource(level, worldPosition, new ItemStack(substrate));
            substrate = null;
        }
        if (level != null && !level.isClientSide && bottomLayer != null) {
            Block.popResource(level, worldPosition, new ItemStack(bottomLayer));
            bottomLayer = null;
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("DyeColor", dyeColor);
        tag.putString("Liquid", liquid.name());
        if (!fish.isEmpty()) {
            ListTag list = new ListTag();
            for (ItemStack bucket : fish) {
                list.add(bucket.save(new CompoundTag()));
            }
            tag.put("Fish", list);
        }
        if (substrate != null) {
            ResourceLocation key = ForgeRegistries.BLOCKS.getKey(substrate);
            if (key != null) {
                tag.putString("Substrate", key.toString());
            }
        }
        if (bottomLayer != null) {
            ResourceLocation key = ForgeRegistries.BLOCKS.getKey(bottomLayer);
            if (key != null) {
                tag.putString("BottomLayer", key.toString());
            }
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        dyeColor = tag.contains("DyeColor") ? tag.getInt("DyeColor") : -1;
        liquid = LargePotBlock.Liquid.NONE;
        if (tag.contains("Liquid")) {
            try {
                liquid = LargePotBlock.Liquid.valueOf(tag.getString("Liquid"));
            } catch (IllegalArgumentException ignored) {
                liquid = LargePotBlock.Liquid.NONE;
            }
        }
        fish.clear();
        if (tag.contains("Fish", Tag.TAG_LIST)) {
            ListTag list = tag.getList("Fish", Tag.TAG_COMPOUND);
            for (int i = 0; i < list.size(); i++) {
                ItemStack bucket = ItemStack.of(list.getCompound(i));
                if (!bucket.isEmpty()) {
                    fish.add(bucket);
                }
            }
        }
        fishVersion++;
        substrate = null;
        if (tag.contains("Substrate")) {
            ResourceLocation key = ResourceLocation.tryParse(tag.getString("Substrate"));
            if (key != null && ForgeRegistries.BLOCKS.containsKey(key)) {
                substrate = ForgeRegistries.BLOCKS.getValue(key);
            }
        }
        bottomLayer = null;
        if (tag.contains("BottomLayer")) {
            ResourceLocation key = ResourceLocation.tryParse(tag.getString("BottomLayer"));
            if (key != null && ForgeRegistries.BLOCKS.containsKey(key)) {
                bottomLayer = ForgeRegistries.BLOCKS.getValue(key);
            }
        }
    }
}
