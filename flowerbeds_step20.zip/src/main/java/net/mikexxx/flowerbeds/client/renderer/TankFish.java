package net.mikexxx.flowerbeds.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import net.mikexxx.flowerbeds.block.GlassPotBlock;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Bucketable;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Draws the fish, axolotls and tadpoles that live in a glass tank. They are real entity models, created on the
 * client only, never added to the world, and moved along a lazy loop inside the tank's water.
 */
final class TankFish {
    private TankFish() {}

    private static final class Swimmers {
        int version = -1;
        final List<Entity> entities = new ArrayList<>();
    }

    private static final Map<LargePotBlockEntity, Swimmers> CACHE = new WeakHashMap<>();
    private static Field waterFlag;
    private static boolean searchedWaterFlag;

    static void render(LargePotBlockEntity tank, Level level, BlockPos pos, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffers, int light) {
        List<ItemStack> buckets = tank.getFish();
        if (buckets.isEmpty()) {
            return;
        }
        Swimmers swimmers = CACHE.computeIfAbsent(tank, key -> new Swimmers());
        if (swimmers.version != tank.fishVersion()) {
            swimmers.version = tank.fishVersion();
            swimmers.entities.clear();
            for (ItemStack bucket : buckets) {
                Entity entity = create(bucket, level);
                if (entity != null) {
                    swimmers.entities.add(entity);
                }
            }
        }
        // The water runs up through the glass pots above, so the swimmers may use all of it.
        int pots = 1;
        BlockPos cursor = pos;
        for (int guard = 0; guard < 32; guard++) {
            BlockPos above = cursor.above();
            if (level.getBlockEntity(above) instanceof LargePotBlockEntity up && up.isTank()
                    && up.getBlockState().getValue(GlassPotBlock.DOWN)
                    && up.effectiveLiquid() == LargePotBlock.Liquid.WATER) {
                pots++;
                cursor = above;
            } else {
                break;
            }
        }
        float low = GardenLayout.POT_FILL_BOTTOM + 0.12F;
        float high = (pots - 1) + GardenLayout.POT_WATER_TOP - 0.12F;
        double time = (level.getGameTime() + partialTick) / 20.0;

        EntityRenderDispatcher dispatcher = Minecraft.getInstance().getEntityRenderDispatcher();
        dispatcher.setRenderShadow(false);
        int count = swimmers.entities.size();
        for (int i = 0; i < count; i++) {
            Entity entity = swimmers.entities.get(i);
            double phase = i * Mth.TWO_PI / count;
            double speed = 0.45 + 0.07 * (i % 3);
            double angle = time * speed * (i % 2 == 0 ? 1 : -1) + phase;
            float radius = 0.2F + 0.05F * (i % 3);
            double x = 0.5 + Math.cos(angle) * radius;
            double z = 0.5 + Math.sin(angle) * radius;
            double wave = 0.5 + 0.5 * Math.sin(time * 0.35 + phase * 1.7);
            double y = low + (high - low) * wave;
            // Face along the loop.
            double dirX = -Math.sin(angle) * (i % 2 == 0 ? 1 : -1);
            double dirZ = Math.cos(angle) * (i % 2 == 0 ? 1 : -1);
            float yaw = (float) (Mth.atan2(-dirX, dirZ) * Mth.RAD_TO_DEG);
            entity.setYRot(yaw);
            entity.yRotO = yaw;
            entity.setXRot(0.0F);
            entity.xRotO = 0.0F;
            if (entity instanceof LivingEntity living) {
                living.yBodyRot = yaw;
                living.yBodyRotO = yaw;
                living.yHeadRot = yaw;
                living.yHeadRotO = yaw;
            }
            entity.tickCount = (int) level.getGameTime() + i * 7;
            dispatcher.render(entity, x, y, z, yaw, partialTick, poseStack, buffers, light);
        }
        dispatcher.setRenderShadow(true);
    }

    /** Builds the entity a mob bucket holds: cod_bucket gives a cod, axolotl_bucket an axolotl, and so on. */
    private static Entity create(ItemStack bucket, Level level) {
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(bucket.getItem());
        if (id == null) {
            return null;
        }
        String path = id.getPath();
        if (path.endsWith("_bucket")) {
            path = path.substring(0, path.length() - "_bucket".length());
        }
        ResourceLocation typeId = new ResourceLocation(id.getNamespace(), path);
        if (!ForgeRegistries.ENTITY_TYPES.containsKey(typeId)) {
            return null;
        }
        try {
            EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(typeId);
            Entity entity = type == null ? null : type.create(level);
            if (entity == null) {
                return null;
            }
            if (entity instanceof Bucketable bucketable && bucket.hasTag()) {
                bucketable.loadFromBucketTag(bucket.getTag());
            }
            if (entity instanceof Mob mob) {
                mob.setNoAi(true);
            }
            markInWater(entity);
            return entity;
        } catch (RuntimeException e) {
            return null;
        }
    }

    /**
     * Fish lie sideways when they are not in water. The entity is never ticked, so its "in water" flag is set by
     * hand. The field is found by trying each flag of Entity until isInWater() answers true, so this works
     * whatever the field is called.
     */
    private static void markInWater(Entity entity) {
        try {
            if (!searchedWaterFlag) {
                searchedWaterFlag = true;
                for (Field field : Entity.class.getDeclaredFields()) {
                    if (field.getType() != boolean.class || Modifier.isStatic(field.getModifiers())
                            || Modifier.isFinal(field.getModifiers())) {
                        continue;
                    }
                    field.setAccessible(true);
                    boolean old = field.getBoolean(entity);
                    field.setBoolean(entity, true);
                    boolean found = entity.isInWater();
                    field.setBoolean(entity, old);
                    if (found) {
                        waterFlag = field;
                        break;
                    }
                }
            }
            if (waterFlag != null) {
                waterFlag.setBoolean(entity, true);
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // Without the flag the fish just look a little tired.
        }
    }
}
