"""Roman arched window v2. W wide (1..6) and H tall (1..6) blocks. The top is a round arch (semicircle of radius W*8 px;
when the window is lower than half its width, a shallower arc). A real frame: lip, band, dentil bead and an inner
ornamental arch with glazing bars that all meet. Everything outside the arch is a thin lattice, one block wide, that
lines up across blocks. One model per (W, Hc, col, row, sill)."""
import json, math, os, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src/main/resources/assets/mikexxx_flowerbeds')
F, G, WD = 'f', 'g', 'w'


def straight(H):
    return 8 if H == 1 else 16


def full_h(W):
    """Smallest height with a full semicircle plus a straight part below it."""
    for H in range(1, 9):
        if 16 * H - straight(H) >= 8 * W:
            return H
    return 8


def geom(W, H):
    wp, hp = 16 * W, 16 * H
    rise = min(wp / 2.0, float(hp - straight(H)))
    rho = (wp * wp / 4.0 + rise * rise) / (2 * rise)
    return wp, hp, rho


def seg_dist(px, py, ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy or 1)))
    return math.hypot(px - ax - t * dx, py - ay - t * dy)


def column(W, H, X, Y, sill):
    """Solid z intervals of global pixel (X, Y from top) of a window W x H blocks."""
    wp, hp, rho = geom(W, H)
    cx = wp / 2.0
    x, y = X + 0.5, Y + 0.5
    arch = y < rho
    d = math.hypot(x - cx, y - rho)
    outside = arch and d >= rho
    if outside:
        # wooden lattice, a full block deep and wide: 2px slats every 8px on global coordinates
        if X % 8 < 2 or Y % 8 < 2:
            return [(0, 16, WD)]
        return []
    e = (rho - d) if arch else min(x, wp - x)
    out = []
    if sill and Y % 16 >= 13:
        return [(0, 16, F)]
    z = None
    u = (math.atan2(y - rho, x - cx) % math.tau) * rho if arch else y
    if e < 1:
        z = (3, 13)                       # lip
    elif e < 4:
        # running wave scroll carved into the band
        ec = 2.5 + 1.1 * math.sin(math.tau * u / 10.0)
        z = (4, 12) if abs(e - ec) < 0.8 else (5, 11)
    elif e < 5:
        if int(u / 2) % 2 == 0:           # dentils
            z = (6, 10)
    if arch and abs(x - cx) <= 3 and e < 9:
        z = (3, 13)                      # keystone
    if abs(y - rho) <= 2.5 and e < 6.5 and rho <= hp:
        z = (3, 13)                      # impost at the spring line
    if z:
        return [(z[0], z[1], F)]
    # inner ornamental arch and glazing bars
    bars = []
    if wp >= 32:
        if arch and abs(e - 12) < 0.7:
            return [(6, 10, F)]
        if not arch and rho <= hp and (abs(x - 12) < 0.7 or abs(x - (wp - 12)) < 0.7):
            return [(6, 10, F)]
    top_in = 5.0
    if rho <= hp:
        if abs(y - rho) < 0.75 and wp >= 24:
            return [(6, 10, F)]  # transom on the spring line, meets every bar
        n = max(0, int((wp - 24) // 32))  # extra mullions either side of the centre
        xs = [cx] + [cx + s * k * 16 for k in range(1, n + 2) for s in (-1, 1) if k * 16 < cx - 8]
        for mx in xs:
            if abs(x - mx) < 0.6 and y >= rho:
                return [(6, 10, F)]
        if arch:
            for k in range(1, 6):
                th = k * math.pi / 6
                ex, ey = cx + (rho - top_in) * math.cos(th), rho - (rho - top_in) * math.sin(th)
                if seg_dist(x, y, cx, rho, ex, ey) < 0.6:
                    return [(6, 10, F)]
    else:
        if abs(x - cx) < 0.6:
            return [(6, 10, F)]
    return [(7, 9, G)]


def model(W, Hc, col, row, sill):
    R = Hc
    cells = {}
    for py in range(16):
        for px in range(16):
            Y = (row * 16 if row < R else 16 * R) + py
            cells[(px, py)] = tuple(column(W, Hc, col * 16 + px, Y, sill))
    done, els = set(), []
    for py in range(16):
        for px in range(16):
            k = cells[(px, py)]
            if (px, py) in done or not k:
                continue
            w = 1
            while px + w < 16 and cells[(px + w, py)] == k and (px + w, py) not in done:
                w += 1
            h = 1
            while py + h < 16 and all(cells[(px + i, py + h)] == k and (px + i, py + h) not in done for i in range(w)):
                h += 1
            for i in range(w):
                for j in range(h):
                    done.add((px + i, py + j))
            for z0, z1, t in k:
                els.append({'from': [px, 16 - py - h, z0], 'to': [px + w, 16 - py, z1],
                            'faces': {s: {'texture': '#' + t} for s in ('north', 'south', 'east', 'west', 'up', 'down')}})
    return {'parent': 'minecraft:block/block', 'render_type': 'minecraft:cutout',
            'textures': {'w': 'minecraft:block/spruce_planks', 'f': 'minecraft:block/calcite', 'g': 'minecraft:block/glass', 'particle': 'minecraft:block/calcite'},
            'elements': els}


def main():
    md = os.path.join(ROOT, 'models/block')
    for f in os.listdir(md):
        if f.startswith('arched_window'):
            os.remove(os.path.join(md, f))
    variants, needed = {}, set()
    for fi, face in enumerate(('north', 'east', 'south', 'west')):
        for W in range(1, 7):
            R = full_h(W)
            for H in range(1, 7):
                Hc = min(H, R)
                for col in range(6):
                    for row in range(6):
                        c, r = min(col, W - 1), min(row, H - 1)
                        sill = 1 if r == H - 1 else 0
                        r = R if r >= R else r
                        needed.add((W, Hc, c, r, sill))
                        for lit in ('false', 'true'):
                            key = 'facing=%s,width=%d,height=%d,col=%d,row=%d,lit=%s' % (face, W, H, col, row, lit)
                            variants[key] = {'model': 'mikexxx_flowerbeds:block/arched_window_%d_%d_%d_%d_%d' % ((W, Hc, c, r, sill)), 'y': fi * 90}
    for n in sorted(needed):
        json.dump(model(*n), open(os.path.join(md, 'arched_window_%d_%d_%d_%d_%d.json' % n), 'w'), separators=(',', ':'))
    json.dump({'variants': variants}, open(os.path.join(ROOT, 'blockstates/arched_window.json'), 'w'))
    json.dump({'parent': 'mikexxx_flowerbeds:block/arched_window_1_1_0_0_1'}, open(os.path.join(ROOT, 'models/item/arched_window.json'), 'w'))


if __name__ == '__main__':
    main()
