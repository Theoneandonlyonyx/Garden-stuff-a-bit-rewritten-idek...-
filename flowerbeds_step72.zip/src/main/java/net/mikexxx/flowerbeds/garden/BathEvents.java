package net.mikexxx.flowerbeds.garden;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.BirdbathBlock;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Sneak-clicks. A sneaking player with an item in hand never reaches a block's own use method, so this one
 * goes through the right-click event: a vanilla lily pad on a birdbath with water puts a small waterlily and a few
 * pads on the water. (Aromatizing water is done by the sakura and violet bathbombs only.)
 */
@Mod.EventBusSubscriber(modid = PmpMikexxx.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class BathEvents {
    private BathEvents() {
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        var player = event.getEntity();
        ItemStack held = event.getItemStack();
        if (!player.isShiftKeyDown() && !held.is(ModItems.BUBBLER.get())) {
            return;
        }
        Level level = event.getLevel();
        if (!(level.getBlockEntity(event.getPos()) instanceof LargePotBlockEntity pot)) {
            return;
        }
        if (held.isEmpty()) {
            // Sneak with an empty hand takes the bubbler back out.
            if (pot.hasBubbler() && player.isShiftKeyDown() && event.getHand() == net.minecraft.world.InteractionHand.MAIN_HAND) {
                event.setCanceled(true);
                if (!level.isClientSide) {
                    pot.setBubbler(false);
                    ItemStack back = new ItemStack(ModItems.BUBBLER.get());
                    if (!player.getInventory().add(back)) {
                        player.drop(back, false);
                    }
                }
                event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide));
            }
            return;
        }
        LargePotBlockEntity source = pot.liquidSource();
        boolean water = source.getLiquid() == LargePotBlock.Liquid.WATER;
        boolean creative = player.getAbilities().instabuild;

        if (held.is(ModItems.BUBBLER.get())) {
            event.setCanceled(true);
            if (!water || pot.hasBubbler()) {
                if (!water && !level.isClientSide) {
                    player.displayClientMessage(Component.translatable("message.mikexxx_flowerbeds.bubbler_needs_water"), true);
                }
                event.setCancellationResult(water ? InteractionResult.FAIL : InteractionResult.sidedSuccess(level.isClientSide));
                return;
            }
            if (!level.isClientSide) {
                pot.setBubbler(true);
                level.playSound(null, event.getPos(), SoundEvents.BUBBLE_COLUMN_UPWARDS_AMBIENT, SoundSource.BLOCKS, 1.0F, 1.2F);
                if (!creative) {
                    held.shrink(1);
                }
            }
            event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide));
            return;
        }
        if (held.is(Items.LILY_PAD) && pot.getBlockState().getBlock() instanceof BirdbathBlock) {
            event.setCanceled(true);
            if (!water) {
                if (!level.isClientSide) {
                    player.displayClientMessage(Component.translatable("message.mikexxx_flowerbeds.lily_needs_water"), true);
                }
                event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide));
                return;
            }
            if (pot.hasLily()) {
                event.setCancellationResult(InteractionResult.FAIL);
                return;
            }
            if (!level.isClientSide) {
                pot.setLily(true);
                level.playSound(null, event.getPos(), SoundEvents.LILY_PAD_PLACE, SoundSource.BLOCKS, 1.0F, 1.1F);
                if (!creative) {
                    held.shrink(1);
                }
            }
            event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide));
            return;
        }
    }
}
