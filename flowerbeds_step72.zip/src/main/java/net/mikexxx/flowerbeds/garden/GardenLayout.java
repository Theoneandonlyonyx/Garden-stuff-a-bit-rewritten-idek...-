package net.mikexxx.flowerbeds.garden;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.BeddingBlock;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.PlantBedBlock;
import net.mikexxx.flowerbeds.block.SoilBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AbstractSkullBlock;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.AmethystClusterBlock;
import net.minecraft.world.level.block.BambooStalkBlock;
import net.minecraft.world.level.block.BigDripleafBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.CactusBlock;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.CocoaBlock;
import net.minecraft.world.level.block.GrowingPlantBlock;
import net.minecraft.world.level.block.HangingRootsBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.MultifaceBlock;
import net.minecraft.world.level.block.SporeBlossomBlock;
import net.minecraft.world.level.block.SugarCaneBlock;
import net.minecraft.world.level.block.TorchBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.IPlantable;

/**
 * Slot layout shared by Soil Blocks and Large Pots.
 *
 * Each bed has a 5x5 grid of quarter-block positions (0..4 in each direction).
 *   - 5 core slots: the centre and the four inner diagonals. They are always available.
 *   - 12 border slots: three per side. Each side's three slots sit on that side only, at the
 *     quarter points between its corners. A side's slots exist when a plantable block is on that
 *     side, and they are shared with that neighbour. Nothing is shared with a diagonal block.
 *   - 1 groundcover slot, drawn flat over the bed.
 */
public final class GardenLayout {
    private GardenLayout() {}

    public static final int CORE_SLOTS = 5;
    public static final int SIDE_SLOTS = 3;
    public static final int PLANT_SLOTS = CORE_SLOTS + 4 * SIDE_SLOTS;
    /** A large pot always has this many of its own plant places, in an even 3x3. They are never shared. */
    public static final int POT_PLANT_SLOTS = 9;
    public static final int GROUNDCOVER_SLOT = PLANT_SLOTS;
    public static final int SLOT_COUNT = GROUNDCOVER_SLOT + 1;

    /** Soil inside a pot: from the floor up to one pixel under the rim. */
    public static final float POT_FILL_BOTTOM = 2.0F / 16.0F;
    public static final float POT_FILL_TOP = 15.0F / 16.0F;
    /** Water sits a little under the rim so the lip still reads, and plants stand just over it. */
    public static final float POT_WATER_TOP = 14.75F / 16.0F;

    /** Grid position (0..4) of each plant slot, in slot order. Border slots: N, E, S, W, three each. */
    public static final int[] GRID_X = {2, 1, 3, 1, 3,   0, 2, 4,   -1, 4, -1,   0, 2, 4,   -1, 0, -1};
    public static final int[] GRID_Z = {2, 1, 1, 3, 3,   0, 0, 0,   -1, 2, -1,   4, 4, 4,   -1, 2, -1};

    /**
     * The layout is the original Garden Stuff one: a 5x5 checkerboard of 13 places. The middle and the four
     * diagonal places belong to the block. The four edge middles are shared with the neighbour on that side,
     * and the four corners with the (up to three) other blocks around that corner. The slot numbers of the
     * old layout are kept, so slots that the new layout does not use have grid position -1 and never exist.
     */
    public static boolean isUsed(int slot) {
        return slot >= GRID_X.length || GRID_X[slot] >= 0;
    }

    /** The slot at a grid cell, or -1 if there is none. */
    public static int slotAt(int gx, int gz) {
        for (int i = 0; i < PLANT_SLOTS; i++) {
            if (GRID_X[i] == gx && GRID_Z[i] == gz) {
                return i;
            }
        }
        return -1;
    }

    /** Sides in slot order. The side index of a border slot is (slot - CORE_SLOTS) / SIDE_SLOTS. */
    public static final Direction[] SIDES = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

    /** Scaled fruit (pumpkins, melons, jack-o'-lanterns and modded fruit) is drawn at this size. */
    public static final float SCALED_FRUIT_SCALE = 0.3F;
    /** In a window box a decorative fruit is a small one that fits the box. */
    public static final float WINDOW_FRUIT_SCALE = 0.2F;
    /** Light given by candles and lanterns that do not emit light themselves. */
    public static final int CANDLE_LIGHT = 12;
    public static final int LANTERN_LIGHT = 15;

    public static final TagKey<Block> PLANTABLE =
            TagKey.create(Registries.BLOCK, new ResourceLocation(PmpMikexxx.MODID, "plantable"));
    /** Blocks that can fill a pot as a growing medium: soil, dirt, sand and the like. */
    public static final TagKey<Block> SUBSTRATES =
            TagKey.create(Registries.BLOCK, new ResourceLocation(PmpMikexxx.MODID, "substrates"));
    public static final TagKey<Item> LANTERNS =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "lanterns"));
    public static final TagKey<Item> CANDLES =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "candles"));
    public static final TagKey<Item> SCALED_FRUIT =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "scaled_fruit"));

    /** Result of resolving a slot: whether it exists, and which bed stores its item. */
    public record Owner(boolean active, BlockPos pos, int slot) {}

    public static int sideSlot(int side, int index) {
        return CORE_SLOTS + side * SIDE_SLOTS + index;
    }

    /** Column (0..4) of a plant slot in the GUI. The GUI never turns: west is left, east is right. */
    public static int guiX(int slot) {
        return GRID_X[slot];
    }

    /** Row (0..4) of a plant slot in the GUI. North is always the top row. */
    public static int guiZ(int slot) {
        return GRID_Z[slot];
    }

    /**
     * Where each grid line (0..4) sits inside the block. The inner lines are pulled in from the quarter points
     * so neighbouring plants keep a small gap. The outer lines stay on the block edge, which is what lets two
     * connected blocks agree on where a shared border slot is.
     */
    private static final float[] COORD = {0.0F, 0.2F, 0.5F, 0.8F, 1.0F};

    public static float localX(int slot) {
        return GRID_X[slot] < 0 ? 0.5F : COORD[GRID_X[slot]];
    }

    public static float localZ(int slot) {
        return GRID_Z[slot] < 0 ? 0.5F : COORD[GRID_Z[slot]];
    }

    /** Even 3x3 inside a pot, kept off the two-pixel walls. */
    public static float potLocalX(int slot) {
        return 0.25F + (slot % 3) * 0.25F;
    }

    public static float potLocalZ(int slot) {
        return 0.25F + (slot / 3) * 0.25F;
    }

    public static boolean isPot(BlockState state) {
        return state.getBlock() instanceof LargePotBlock;
    }

    public static boolean isPlantableState(BlockState state) {
        return state.getBlock() instanceof PlantBedBlock || state.is(PLANTABLE);
    }

    /** Whether the item is a block that something grows on (see {@link #isSubstrateState}). */
    public static boolean isSubstrate(ItemStack stack, BlockGetter level, BlockPos pos) {
        return stack.getItem() instanceof BlockItem blockItem
                && isSubstrateState(blockItem.getBlock().defaultBlockState(), level, pos);
    }

    /**
     * Whether a block is something that grows plants: anything in the substrates tag, or any full block
     * that vanilla/Forge plant rules say can hold a sapling, a cactus or sugar cane. Blocks with a block
     * entity (chests, furnaces, our own beds) are never substrates.
     */
    public static boolean isSubstrateState(BlockState state, BlockGetter level, BlockPos pos) {
        Block block = state.getBlock();
        // The substrates tag wins, so the mod's own soil block can fill a pot. Other plant beds
        // (pots, bedding, window boxes) stay excluded even if a pack adds them to the tag.
        if (state.is(SUBSTRATES)) {
            return !(block instanceof PlantBedBlock) || block instanceof SoilBlock;
        }
        if (block instanceof PlantBedBlock || state.hasBlockEntity()) {
            return false;
        }
        try {
            if (!state.isCollisionShapeFullBlock(level, pos)) {
                return false;
            }
            for (Block plant : new Block[] {Blocks.OAK_SAPLING, Blocks.CACTUS, Blocks.SUGAR_CANE}) {
                if (plant instanceof IPlantable plantable
                        && state.canSustainPlant(level, pos, Direction.UP, plantable)) {
                    return true;
                }
            }
        } catch (RuntimeException ignored) {
            // A modded block that cannot answer without a real world position is not a substrate.
        }
        return false;
    }

    /** Extra blocks packs allow as the thin floor layer of a water-filled pot or tank. */
    public static final TagKey<Item> BOTTOM_LAYERS =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "bottom_layers"));

    /**
     * Whether a block item can be laid on the floor of a water-filled pot as a thin layer: every substrate, plus
     * sand, gravel and other falling blocks, dirt of any kind, clay, soul sand and soul soil. Beds and blocks
     * with a block entity never are.
     */
    public static boolean isBottomLayer(ItemStack stack, BlockGetter level, BlockPos pos) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        Block block = blockItem.getBlock();
        BlockState state = block.defaultBlockState();
        if (block instanceof PlantBedBlock && !(block instanceof SoilBlock)) {
            return false;
        }
        if (stack.is(BOTTOM_LAYERS) || isSubstrateState(state, level, pos)) {
            return true;
        }
        if (state.hasBlockEntity()) {
            return false;
        }
        return block instanceof FallingBlock
                || state.is(BlockTags.DIRT)
                || state.is(BlockTags.SAND)
                || block == Blocks.CLAY
                || block == Blocks.SOUL_SAND
                || block == Blocks.SOUL_SOIL;
    }

    /** Plants and groundcover: any block item. Non-block items have no world model to draw. */
    public static boolean isBlockItem(ItemStack stack) {
        return stack.getItem() instanceof BlockItem;
    }

    /** Extra items packs may allow in beds (anything decorative or plant-like the built-in rules do not know). */
    public static final TagKey<Item> EXTRA_PLACEABLE =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "extra_placeable"));

    /**
     * Whether an item may be put into a bed, pot or window box: plants of every kind (flowers, saplings, crops
     * and seeds, mushrooms, ferns, vines, cacti, sugar cane, bamboo, kelp, coral, leaves ...), groundcover
     * (petals, carpets, moss), and decorations (candles, lanterns, torches, fruit, heads, amethyst). Ordinary
     * building blocks such as a gold block or stone are not accepted.
     */
    public static boolean isPlaceable(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        if (stack.is(EXTRA_PLACEABLE) || stack.is(CANDLES) || stack.is(LANTERNS) || stack.is(SCALED_FRUIT)) {
            return true;
        }
        return isPlantOrDecoration(blockItem.getBlock().defaultBlockState());
    }

    private static boolean isPlantOrDecoration(BlockState state) {
        Block block = state.getBlock();
        if (block instanceof PlantBedBlock) {
            return false;
        }
        return block instanceof BushBlock          // flowers, saplings, crops, seeds, mushrooms, ferns, lily pads, petals ...
                || block instanceof IPlantable
                || block instanceof VineBlock
                || block instanceof MultifaceBlock  // glow lichen
                || block instanceof GrowingPlantBlock // kelp, cave vines, weeping and twisting vines
                || block instanceof BambooStalkBlock
                || block instanceof SugarCaneBlock
                || block instanceof CactusBlock
                || block instanceof LeavesBlock
                || block instanceof CarpetBlock     // moss carpet and the like (groundcover)
                || block instanceof CocoaBlock
                || block instanceof BigDripleafBlock
                || block instanceof SporeBlossomBlock
                || block instanceof HangingRootsBlock
                || block instanceof TorchBlock
                || block instanceof AmethystClusterBlock
                || block instanceof AbstractSkullBlock
                || state.is(BlockTags.FLOWERS)
                || state.is(BlockTags.SAPLINGS)
                || state.is(BlockTags.CROPS)
                || state.is(BlockTags.CORALS)
                || state.is(BlockTags.CORAL_PLANTS)
                || state.is(BlockTags.WALL_CORALS)
                || state.is(BlockTags.FLOWER_POTS);
    }

    public static boolean isScaled(ItemStack stack) {
        return stack.getItem() instanceof BlockItem && stack.is(SCALED_FRUIT);
    }

    /** Light of a stored item. A candle only gives light once it has been lit (its slot age is 1). */
    public static int lightOf(ItemStack stack, int age) {
        return stack.is(CANDLES) && age <= 0 ? 0 : lightOf(stack);
    }

    /** Light the item gives while it sits in a bed (0 if none). */
    public static int lightOf(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return 0;
        }
        int emitted = blockItem.getBlock().defaultBlockState().getLightEmission();
        if (stack.is(CANDLES)) {
            return Math.max(emitted, CANDLE_LIGHT);
        }
        if (stack.is(LANTERNS)) {
            return Math.max(emitted, LANTERN_LIGHT);
        }
        return emitted;
    }

    /**
     * Works out whether a slot of the bed at {@code bed} exists, and which bed stores it.
     * Core slots always belong to the bed. A border slot exists when the neighbour on its side is
     * plantable, and it is stored by whichever of the two beds has the smaller position.
     */
    public static Owner resolve(Level level, BlockPos bed, int slot) {
        if (slot < CORE_SLOTS) {
            return new Owner(true, bed, slot);
        }
        if (!isUsed(slot)) {
            return new Owner(false, bed, slot);
        }
        int rel = slot - CORE_SLOTS;
        int side = rel / SIDE_SLOTS;
        int index = rel % SIDE_SLOTS;
        if (index != 1) {
            return resolveCorner(level, bed, slot);
        }

        BlockPos neighbor = bed.relative(SIDES[side]);
        if (!sharesSide(level, bed, neighbor)) {
            return new Owner(false, bed, slot);
        }
        if (level.getBlockState(neighbor).getBlock() instanceof PlantBedBlock && compare(neighbor, bed) < 0) {
            // The neighbour's slot on the opposite side covers the same boundary.
            return new Owner(true, neighbor, sideSlot((side + 2) % 4, index));
        }
        return new Owner(true, bed, slot);
    }

    /** Corner slot of a block for the corner at (sx, sz), each -1 (west/north) or +1 (east/south). */
    private static int cornerSlot(int sx, int sz) {
        if (sz < 0) {
            return sideSlot(0, sx < 0 ? 0 : 2);
        }
        return sideSlot(2, sx < 0 ? 0 : 2);
    }

    /**
     * A corner is shared by the up to four blocks around it. A block has the corner when it is connected to
     * both of its neighbours in that group of four; the slot is stored by the block with the smallest position
     * of those that have it. Every block works this out from the same four positions, so all agree.
     */
    private static Owner resolveCorner(Level level, BlockPos bed, int slot) {
        int sx = GRID_X[slot] == 0 ? -1 : 1;
        int sz = GRID_Z[slot] == 0 ? -1 : 1;
        BlockPos self = bed;
        BlockPos alongX = bed.offset(sx, 0, 0);
        BlockPos alongZ = bed.offset(0, 0, sz);
        BlockPos diagonal = bed.offset(sx, 0, sz);
        if (!sharesSide(level, self, alongX) || !sharesSide(level, self, alongZ)) {
            return new Owner(false, bed, slot);
        }
        BlockPos best = self;
        int bestSlot = slot;
        // Members of the group, with the corner each of them sees (the corner point is on the opposite side).
        BlockPos[] members = {alongX, alongZ, diagonal};
        int[] slots = {cornerSlot(-sx, sz), cornerSlot(sx, -sz), cornerSlot(-sx, -sz)};
        BlockPos[][] adjacent = {{self, diagonal}, {self, diagonal}, {alongX, alongZ}};
        for (int m = 0; m < members.length; m++) {
            BlockPos member = members[m];
            if (!(level.getBlockState(member).getBlock() instanceof PlantBedBlock)) {
                continue;
            }
            if (!sharesSide(level, member, adjacent[m][0]) || !sharesSide(level, member, adjacent[m][1])) {
                continue;
            }
            if (compare(member, best) < 0) {
                best = member;
                bestSlot = slots[m];
            }
        }
        return new Owner(true, best, bestSlot);
    }

    /** Bit i is set when plant slot i of the bed exists. */
    public static int activeMask(Level level, BlockPos bed) {
        int mask = 0;
        for (int i = 0; i < PLANT_SLOTS; i++) {
            if (resolve(level, bed, i).active()) {
                mask |= 1 << i;
            }
        }
        return mask;
    }

    /** Whether a bed of this kind opens its side toward the other block. Soil and bedding open to any plantable block; a pot only to pots of the same kind. */
    public static boolean bedOpensTo(BlockState bed, BlockState other) {
        if (bed.getBlock() instanceof SoilBlock || bed.getBlock() instanceof BeddingBlock) {
            return isPlantableState(other);
        }
        if (bed.getBlock() instanceof LargePotBlock) {
            return other.getBlock() == bed.getBlock();
        }
        return false;
    }

    /**
     * A side has shared border slots only when the two blocks open toward each other. Two beds must both
     * open toward each other; a plain plantable block (dirt, grass, ...) only needs to be opened to by the bed.
     */
    public static boolean sharesSide(Level level, BlockPos bed, BlockPos neighbor) {
        BlockState self = level.getBlockState(bed);
        BlockState other = level.getBlockState(neighbor);
        if (other.getBlock() instanceof PlantBedBlock) {
            return bedOpensTo(self, other) && bedOpensTo(other, self);
        }
        return bedOpensTo(self, other);
    }

    private static int compare(BlockPos a, BlockPos b) {
        int c = Integer.compare(a.getX(), b.getX());
        return c != 0 ? c : Integer.compare(a.getZ(), b.getZ());
    }
}
