package net.mikexxx.flowerbeds.registry;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** The three particles of aromatized water. Their look lives in assets/.../particles and the client class. */
public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, PmpMikexxx.MODID);

    /** A rosy twinkle that shrinks away, like the green happy-villager sparkle. */
    public static final RegistryObject<SimpleParticleType> AROMA_GLINT =
            PARTICLES.register("aroma_glint", () -> new SimpleParticleType(false));
    /** A bubble of the bubbler: white, tinted by the water colour, spiralling up like a whirlpool. */
    public static final RegistryObject<SimpleParticleType> BUBBLER_BUBBLE =
            PARTICLES.register("bubbler_bubble", () -> new SimpleParticleType(false));
    /** A pale pink bubble. */
    public static final RegistryObject<SimpleParticleType> AROMA_BUBBLE =
            PARTICLES.register("aroma_bubble", () -> new SimpleParticleType(false));
    /** A sakura petal of varying size. */
    public static final RegistryObject<SimpleParticleType> AROMA_PETAL =
            PARTICLES.register("aroma_petal", () -> new SimpleParticleType(false));
    /** The pop of a bubble that reaches the end of its life. */
    public static final RegistryObject<SimpleParticleType> AROMA_POP =
            PARTICLES.register("aroma_pop", () -> new SimpleParticleType(false));
    /** A violet flower that floats up, hangs, and shrinks away like glitter. */
    public static final RegistryObject<SimpleParticleType> AROMA_VIOLET_FLOWER =
            PARTICLES.register("aroma_violet_flower", () -> new SimpleParticleType(false));
    /** The purple twin of the happy-villager sparkle. */
    public static final RegistryObject<SimpleParticleType> AROMA_VIOLET_HAPPY =
            PARTICLES.register("aroma_violet_happy", () -> new SimpleParticleType(false));
    /** The violet bubble and its pop (the sprites carry the colour). */
    public static final RegistryObject<SimpleParticleType> AROMA_VIOLET_BUBBLE =
            PARTICLES.register("aroma_violet_bubble", () -> new SimpleParticleType(false));
    public static final RegistryObject<SimpleParticleType> AROMA_VIOLET_POP =
            PARTICLES.register("aroma_violet_pop", () -> new SimpleParticleType(false));
    /** A drop of the birdbath fountain. */
    public static final RegistryObject<SimpleParticleType> FOUNTAIN_DROP =
            PARTICLES.register("fountain_drop", () -> new SimpleParticleType(false));
}
