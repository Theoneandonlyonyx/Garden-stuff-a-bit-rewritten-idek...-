package net.mikexxx.flowerbeds.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.core.BlockPos;

/** A bubble that spirals up around the bubbler like a small whirlpool and pops at the surface. */
public class BubblerParticle extends TextureSheetParticle {
    private final double cx;
    private final double cz;
    private final float turn;
    private float angle;
    private float radius;
    private final float spin;

    protected BubblerParticle(ClientLevel level, double x, double y, double z, float r, float g, float b, SpriteSet sprites) {
        super(level, x, y, z);
        this.cx = x;
        this.cz = z;
        this.rCol = r;
        this.gCol = g;
        this.bCol = b;
        this.alpha = 0.9F;
        this.angle = random.nextFloat() * 6.2831855F;
        this.radius = 0.01F;
        this.turn = random.nextBoolean() ? 1.0F : 1.0F;
        this.spin = 0.38F + random.nextFloat() * 0.16F;
        this.quadSize = 0.025F + random.nextFloat() * 0.03F;
        this.lifetime = 18 + random.nextInt(12);
        this.yd = 0.02 + random.nextDouble() * 0.02;
        this.hasPhysics = false;
        pickSprite(sprites);
    }

    @Override
    public void tick() {
        this.xo = x;
        this.yo = y;
        this.zo = z;
        if (age++ >= lifetime) {
            remove();
            return;
        }
        // Stop at the water surface.
        BlockPos above = BlockPos.containing(x, y + 0.04, z);
        if (!level.getFluidState(above).is(Fluids.WATER) && level.getBlockState(above).isAir() && age > 3) {
            remove();
            return;
        }
        angle += spin;
        radius = Math.min(0.2F, radius + 0.012F);
        y += yd;
        x = cx + Math.cos(angle) * radius;
        z = cz + Math.sin(angle) * radius;
        if (age > lifetime - 4) {
            quadSize *= 0.8F;
            alpha *= 0.8F;
        }
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double r, double g, double b) {
            return new BubblerParticle(level, x, y, z, (float) r, (float) g, (float) b, sprites);
        }
    }
}
