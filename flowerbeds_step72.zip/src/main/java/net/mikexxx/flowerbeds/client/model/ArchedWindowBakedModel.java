package net.mikexxx.flowerbeds.client.model;

import net.mikexxx.flowerbeds.block.ArchedWindowBlock;
import net.mikexxx.flowerbeds.block.entity.ArchedWindowBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.BlockElementFace;
import net.minecraft.client.renderer.block.model.BlockFaceUV;
import net.minecraft.client.renderer.block.model.FaceBakery;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.BlockModelRotation;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.ChunkRenderTypeSet;
import net.minecraftforge.client.model.BakedModelWrapper;
import net.minecraftforge.client.model.data.ModelData;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Arched window model. When a block has been put into the lattice, the wooden lattice quads are dropped and the
 * lattice area itself (the cell minus the arch, one block deep) is rebuilt out of the texture of that block, face by
 * face, with the real quads' sprites and tint. Texture coordinates follow the cell grid, so neighbouring cells and
 * the real blocks around the window continue the same texture.
 */
public class ArchedWindowBakedModel extends BakedModelWrapper<BakedModel> {

    private static final ResourceLocation SPRUCE = new ResourceLocation("minecraft", "block/spruce_planks");
    private static final ResourceLocation NAME = new ResourceLocation("mikexxx_flowerbeds", "arched_window_lattice");
    private static final FaceBakery BAKERY = new FaceBakery();

    public ArchedWindowBakedModel(BakedModel base) {
        super(base);
    }

    private static BakedModel modelOf(BlockState s) {
        return Minecraft.getInstance().getBlockRenderer().getBlockModel(s);
    }

    @Override
    public List<BakedQuad> getQuads(BlockState state, Direction side, RandomSource rand, ModelData data,
                                    RenderType renderType) {
        BlockState mimic = data.get(ArchedWindowBlockEntity.MIMIC);
        BlockState candle = data.get(ArchedWindowBlockEntity.CANDLE);
        List<BakedQuad> base = super.getQuads(state, side, rand, data, renderType);
        if (candle != null && state != null && (renderType == null || renderType == RenderType.cutout() || renderType == RenderType.cutoutMipped())
                && ArchedWindowBlock.hasSill(state)) {
            List<BakedQuad> with = new ArrayList<>(base);
            for (BakedQuad q : modelOf(candle).getQuads(candle, side, rand, ModelData.EMPTY, null)) {
                with.add(lift(q, 3.0F / 16.0F));
            }
            base = with;
        }
        BlockState decor = data.get(ArchedWindowBlockEntity.DECOR);
        if (decor != null && state != null && (renderType == null || renderType == RenderType.cutout() || renderType == RenderType.cutoutMipped())
                && ArchedWindowBlock.hasSill(state)) {
            List<BakedQuad> with = new ArrayList<>(base);
            float scale = decor.getBlock() instanceof net.minecraft.world.level.block.LanternBlock ? 0.75F
                    : decor.getBlock() instanceof net.minecraft.world.level.block.FlowerPotBlock ? 1.0F
                    : net.mikexxx.flowerbeds.garden.GardenLayout.SCALED_FRUIT_SCALE;
            for (BakedQuad q : modelOf(decor).getQuads(decor, side, rand, ModelData.EMPTY, null)) {
                with.add(scaleOnSill(q, scale, 3.0F / 16.0F));
            }
            base = with;
        }
        if (mimic == null || state == null) {
            return base;
        }
        List<BakedQuad> out = new ArrayList<>();
        if (renderType == null || originalTypes(state, rand, data).contains(renderType)) {
            for (BakedQuad q : base) {
                if (!q.getSprite().contents().name().equals(SPRUCE)) {
                    out.add(q);
                }
            }
        }
        if (side == null && (renderType == null || modelOf(mimic).getRenderTypes(mimic, rand, ModelData.EMPTY).contains(renderType))) {
            out.addAll(latticeQuads(state, mimic, rand));
        }
        return out;
    }

    /** The same quad, shrunk about the middle of the block's floor and set on the sill. */
    private static BakedQuad scaleOnSill(BakedQuad q, float scale, float dy) {
        int[] v = q.getVertices().clone();
        for (int i = 0; i < 4; i++) {
            float x = Float.intBitsToFloat(v[i * 8]);
            float y = Float.intBitsToFloat(v[i * 8 + 1]);
            float z = Float.intBitsToFloat(v[i * 8 + 2]);
            v[i * 8] = Float.floatToRawIntBits(0.5F + (x - 0.5F) * scale);
            v[i * 8 + 1] = Float.floatToRawIntBits(y * scale + dy);
            v[i * 8 + 2] = Float.floatToRawIntBits(0.5F + (z - 0.5F) * scale);
        }
        return new BakedQuad(v, q.getTintIndex(), q.getDirection(), q.getSprite(), q.isShade(), q.hasAmbientOcclusion());
    }

    /** The same quad, moved up onto the sill. */
    private static BakedQuad lift(BakedQuad q, float dy) {
        int[] v = q.getVertices().clone();
        for (int i = 0; i < 4; i++) {
            v[i * 8 + 1] = Float.floatToRawIntBits(Float.intBitsToFloat(v[i * 8 + 1]) + dy);
        }
        return new BakedQuad(v, q.getTintIndex(), q.getDirection(), q.getSprite(), q.isShade(), q.hasAmbientOcclusion());
    }

    private ChunkRenderTypeSet originalTypes(BlockState state, RandomSource rand, ModelData data) {
        return super.getRenderTypes(state, rand, data);
    }

    @Override
    public ChunkRenderTypeSet getRenderTypes(BlockState state, RandomSource rand, ModelData data) {
        BlockState mimic = data.get(ArchedWindowBlockEntity.MIMIC);
        ChunkRenderTypeSet base = super.getRenderTypes(state, rand, data);
        if (mimic == null) {
            return base;
        }
        return ChunkRenderTypeSet.union(base, modelOf(mimic).getRenderTypes(mimic, rand, ModelData.EMPTY));
    }

    private static int straight(int h) {
        return h == 1 ? 8 : 16;
    }

    private static int fullHeight(int w) {
        for (int h = 1; h < 9; h++) {
            if (16 * h - straight(h) >= 8 * w) {
                return h;
            }
        }
        return 8;
    }

    /** Which of the 16x16 pixels of this cell lie outside the arch (same maths as tools/gen_arch.py). */
    private static boolean[][] lattice(BlockState state) {
        int w = state.getValue(ArchedWindowBlock.WIDTH);
        int h = state.getValue(ArchedWindowBlock.HEIGHT);
        int col = Math.min(state.getValue(ArchedWindowBlock.COL), w - 1);
        int row = Math.min(state.getValue(ArchedWindowBlock.ROW), h - 1);
        int full = fullHeight(w);
        int hc = Math.min(h, full);
        if (row >= full) {
            row = full;
        }
        double wp = 16.0 * w;
        double hp = 16.0 * hc;
        double rise = Math.min(wp / 2.0, hp - straight(hc));
        double rho = (wp * wp / 4.0 + rise * rise) / (2 * rise);
        double cx = wp / 2.0;
        boolean[][] g = new boolean[16][16];
        for (int py = 0; py < 16; py++) {
            double y = (row < hc ? row * 16 : 16 * hc) + py + 0.5;
            for (int px = 0; px < 16; px++) {
                double x = col * 16 + px + 0.5;
                g[px][py] = y < rho && Math.hypot(x - cx, y - rho) >= rho;
            }
        }
        return g;
    }

    private static boolean at(boolean[][] g, int x, int y) {
        return x >= 0 && x < 16 && y >= 0 && y < 16 && g[x][y];
    }

    private List<BakedQuad> latticeQuads(BlockState state, BlockState mimic, RandomSource rand) {
        boolean[][] g = lattice(state);
        int yaw = switch (state.getValue(ArchedWindowBlock.FACING)) {
            case EAST -> 90;
            case SOUTH -> 180;
            case WEST -> 270;
            default -> 0;
        };
        BlockModelRotation rot = BlockModelRotation.by(0, yaw);
        BakedModel mm = modelOf(mimic);
        TextureAtlasSprite[] sprite = new TextureAtlasSprite[6];
        int[] tint = new int[6];
        for (Direction d : Direction.values()) {
            Direction fin = d;
            for (int i = 0; i < yaw / 90; i++) {
                fin = fin.getAxis().isHorizontal() ? fin.getClockWise() : fin;
            }
            List<BakedQuad> qs = mm.getQuads(mimic, fin, rand, ModelData.EMPTY, null);
            if (qs.isEmpty()) {
                for (BakedQuad q : mm.getQuads(mimic, null, rand, ModelData.EMPTY, null)) {
                    if (q.getDirection() == fin) {
                        qs = List.of(q);
                        break;
                    }
                }
            }
            if (qs.isEmpty()) {
                sprite[d.get3DDataValue()] = mm.getParticleIcon(ModelData.EMPTY);
                tint[d.get3DDataValue()] = -1;
            } else {
                sprite[d.get3DDataValue()] = qs.get(0).getSprite();
                tint[d.get3DDataValue()] = qs.get(0).getTintIndex();
            }
        }
        // greedy rectangles over the lattice pixels
        boolean[][] done = new boolean[16][16];
        List<BakedQuad> out = new ArrayList<>();
        for (int py = 0; py < 16; py++) {
            for (int px = 0; px < 16; px++) {
                if (!g[px][py] || done[px][py]) {
                    continue;
                }
                int w = 1;
                while (px + w < 16 && g[px + w][py] && !done[px + w][py]) {
                    w++;
                }
                int h = 1;
                boolean grow = true;
                while (grow && py + h < 16) {
                    for (int i = 0; i < w; i++) {
                        if (!g[px + i][py + h] || done[px + i][py + h]) {
                            grow = false;
                        }
                    }
                    if (grow) {
                        h++;
                    }
                }
                for (int i = 0; i < w; i++) {
                    for (int j = 0; j < h; j++) {
                        done[px + i][py + j] = true;
                    }
                }
                rect(out, g, px, py, w, h, sprite, tint, rot);
            }
        }
        return out;
    }

    /** One rectangle of lattice, a block deep: front and back whole, the edge faces only where nothing continues. */
    private static void rect(List<BakedQuad> out, boolean[][] g, int px, int py, int w, int h,
                             TextureAtlasSprite[] sprite, int[] tint, BlockModelRotation rot) {
        float x0 = px;
        float x1 = px + w;
        float y0 = 16 - py - h;
        float y1 = 16 - py;
        face(out, new Vector3f(x0, y0, 0), new Vector3f(x1, y1, 16), Direction.NORTH, sprite, tint, rot);
        face(out, new Vector3f(x0, y0, 0), new Vector3f(x1, y1, 16), Direction.SOUTH, sprite, tint, rot);
        for (int i = 0; i < w; i++) {
            if (!at(g, px + i, py - 1)) {
                face(out, new Vector3f(px + i, y1 - 0.0F, 0), new Vector3f(px + i + 1, y1, 16), Direction.UP, sprite, tint, rot);
            }
            if (!at(g, px + i, py + h)) {
                face(out, new Vector3f(px + i, y0, 0), new Vector3f(px + i + 1, y0, 16), Direction.DOWN, sprite, tint, rot);
            }
        }
        for (int j = 0; j < h; j++) {
            float ya = 16 - py - j - 1;
            if (!at(g, px - 1, py + j)) {
                face(out, new Vector3f(x0, ya, 0), new Vector3f(x0, ya + 1, 16), Direction.WEST, sprite, tint, rot);
            }
            if (!at(g, px + w, py + j)) {
                face(out, new Vector3f(x1, ya, 0), new Vector3f(x1, ya + 1, 16), Direction.EAST, sprite, tint, rot);
            }
        }
    }

    private static void face(List<BakedQuad> out, Vector3f from, Vector3f to, Direction dir,
                             TextureAtlasSprite[] sprite, int[] tint, BlockModelRotation rot) {
        float[] uv = switch (dir) {
            case DOWN -> new float[]{from.x, 16 - to.z, to.x, 16 - from.z};
            case UP -> new float[]{from.x, from.z, to.x, to.z};
            case NORTH -> new float[]{16 - to.x, 16 - to.y, 16 - from.x, 16 - from.y};
            case SOUTH -> new float[]{from.x, 16 - to.y, to.x, 16 - from.y};
            case WEST -> new float[]{from.z, 16 - to.y, to.z, 16 - from.y};
            default -> new float[]{16 - to.z, 16 - to.y, 16 - from.z, 16 - from.y};
        };
        BlockElementFace f = new BlockElementFace(null, tint[dir.get3DDataValue()], "#t", new BlockFaceUV(uv, 0));
        out.add(BAKERY.bakeQuad(from, to, f, sprite[dir.get3DDataValue()], dir, rot, null, true, NAME));
    }
}
