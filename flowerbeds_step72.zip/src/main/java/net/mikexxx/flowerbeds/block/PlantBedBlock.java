package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.PlantBedBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.mikexxx.flowerbeds.menu.PlantBedMenu;
import net.mikexxx.flowerbeds.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/**
 * Shared behaviour of Soil Blocks and Large Pots: the trowel opens Arrange Plants, bone meal moves
 * the plants one growth stage, and neighbouring beds are told when a bed appears or disappears.
 */
public abstract class PlantBedBlock extends Block implements EntityBlock {

    /** Light level the bed gives off, from the lanterns and candles stored in it. */
    /**
     * Light given off by what is planted, in four steps instead of sixteen. Every extra value multiplies the
     * number of block states (and the models and memory the game spends on them), so the light is rounded up to
     * the nearest of 0, 7, 12 and 15, which covers candles, torches, lanterns and glowing blocks.
     */
    public static final IntegerProperty LIGHT = IntegerProperty.create("light", 0, 3);
    private static final int[] LIGHT_LEVELS = {0, 7, 12, 15};

    /** The real light level a block state gives off. */
    public static int lightOf(BlockState state) {
        return state.hasProperty(LIGHT) ? LIGHT_LEVELS[state.getValue(LIGHT)] : 0;
    }

    /** The LIGHT step that gives at least this much light. */
    public static int lightStep(int light) {
        return light <= 0 ? 0 : light <= 7 ? 1 : light <= 12 ? 2 : 3;
    }

    public PlantBedBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LIGHT);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);

        if (held.is(ModItems.TROWEL.get())) {
            // Sneaking with the trowel on bedding lets the item turn it back into the original block.
            if (player.isShiftKeyDown() && state.getBlock() instanceof BeddingBlock) {
                return InteractionResult.PASS;
            }
            if (!level.isClientSide
                    && level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed
                    && player instanceof ServerPlayer serverPlayer) {
                if (canOpenMenu(state, level, pos)) {
                    openPlantMenu(serverPlayer, menuTarget(bed), pos);
                } else {
                    player.displayClientMessage(Component.translatable(
                            "message.mikexxx_flowerbeds.needs_substrate"), true);
                }
            }
            return InteractionResult.SUCCESS;
        }

        // Flint and steel or a fire charge lights every unlit candle in the bed.
        if ((held.is(Items.FLINT_AND_STEEL) || held.is(Items.FIRE_CHARGE))
                && level.getBlockEntity(pos) instanceof PlantBedBlockEntity candleBed) {
            boolean any = false;
            for (int i = 0; i < GardenLayout.SLOT_COUNT; i++) {
                ItemStack stored = candleBed.getSlot(i);
                if (stored.is(GardenLayout.CANDLES) && candleBed.getAge(i) <= 0) {
                    any = true;
                    if (!level.isClientSide) {
                        candleBed.setSlot(i, stored, 1, candleBed.getRotation(i));
                    }
                }
            }
            if (any) {
                if (!level.isClientSide) {
                    level.playSound(null, pos, held.is(Items.FIRE_CHARGE) ? SoundEvents.FIRECHARGE_USE
                            : SoundEvents.FLINTANDSTEEL_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
                    if (!player.getAbilities().instabuild) {
                        if (held.is(Items.FIRE_CHARGE)) {
                            held.shrink(1);
                        } else {
                            held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                        }
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        }

        if (held.is(Items.BONE_MEAL)) {
            if (level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed && bed.canGrowAny()) {
                if (!level.isClientSide) {
                    bed.growPlants();
                    level.levelEvent(2005, pos, 0);
                    if (!player.getAbilities().instabuild) {
                        held.shrink(1);
                    }
                }
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        }

        if (allowsLoosePlanting()) {
            InteractionResult planted = loosePlant(level, pos, player, hand, held, hit);
            if (planted != InteractionResult.PASS) {
                return planted;
            }
        }

        return extraUse(state, level, pos, player, hand, held);
    }

    /** Soil and bedding take a plant from the hand. The spot is only approximate; the trowel is exact. */
    protected boolean allowsLoosePlanting() {
        return this instanceof SoilBlock || this instanceof BeddingBlock;
    }

    /**
     * Puts one plant onto the nearest of the five core places, snapped to the half of the block that was
     * clicked. Border places stay for the trowel. Groundcover goes to the groundcover place.
     */
    private InteractionResult loosePlant(Level level, BlockPos pos, Player player, InteractionHand hand,
                                         ItemStack held, BlockHitResult hit) {
        if (!GardenLayout.isPlaceable(held) || !(level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed)) {
            return InteractionResult.PASS;
        }
        if (GardenLayout.isSubstrate(held, level, pos) && !PlantStates.isGroundcover(held)) {
            return InteractionResult.PASS;
        }
        int slot;
        boolean stacking;
        if (PlantStates.isGroundcover(held)) {
            slot = GardenLayout.GROUNDCOVER_SLOT;
            ItemStack present = bed.getSlot(slot);
            int max = PlantStates.maxAmount(held);
            if (present.isEmpty()) {
                stacking = false;
            } else if (ItemStack.isSameItemSameTags(present, held) && present.getCount() < max) {
                stacking = true;
            } else {
                return InteractionResult.PASS;
            }
        } else {
            int found = nearestCoreSlot(level, pos, bed, held, hit);
            if (found < 0) {
                return InteractionResult.PASS;
            }
            slot = found;
            stacking = !bed.getSlot(slot).isEmpty();
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (stacking) {
            ItemStack present = bed.getSlot(slot);
            ItemStack grown = present.copy();
            grown.grow(1);
            bed.setSlot(slot, grown, bed.getAge(slot), bed.getRotation(slot));
        } else {
            bed.setSlot(slot, held.copyWithCount(1), 0, player.getDirection().get2DDataValue());
        }
        level.playSound(null, pos, SoundEvents.GRASS_PLACE, SoundSource.BLOCKS, 0.8F, 1.0F);
        if (!player.getAbilities().instabuild) {
            held.shrink(1);
        }
        return InteractionResult.SUCCESS;
    }

    /** Closest core slot to the clicked half of the block. Matching stacks are preferred, then empty slots. */
    private static int nearestCoreSlot(Level level, BlockPos pos, PlantBedBlockEntity bed, ItemStack held,
                                       BlockHitResult hit) {
        Vec3 loc = hit.getLocation();
        double qx = (loc.x - pos.getX()) < 0.5 ? 0.25 : 0.75;
        double qz = (loc.z - pos.getZ()) < 0.5 ? 0.25 : 0.75;
        int bestStack = -1;
        int bestEmpty = -1;
        double bestStackD = Double.MAX_VALUE;
        double bestEmptyD = Double.MAX_VALUE;
        int max = PlantStates.maxAmount(held);
        for (int i = 0; i < GardenLayout.CORE_SLOTS; i++) {
            GardenLayout.Owner owner = GardenLayout.resolve(level, pos, i);
            if (!owner.active() || !owner.pos().equals(pos)) {
                continue;
            }
            double dx = GardenLayout.localX(i) - qx;
            double dz = GardenLayout.localZ(i) - qz;
            double d = dx * dx + dz * dz;
            ItemStack present = bed.getSlot(i);
            if (present.isEmpty()) {
                if (d < bestEmptyD) {
                    bestEmptyD = d;
                    bestEmpty = i;
                }
            } else if (ItemStack.isSameItemSameTags(present, held) && present.getCount() < max && d < bestStackD) {
                bestStackD = d;
                bestStack = i;
            }
        }
        if (bestStack >= 0 && (bestEmpty < 0 || bestStackD <= bestEmptyD)) {
            return bestStack;
        }
        return bestEmpty;
    }

    /** Whether the trowel may open Arrange Plants here. A pot first needs a substrate or a liquid. */
    protected boolean canOpenMenu(BlockState state, Level level, BlockPos pos) {
        return true;
    }

    /** Hook for block-specific interaction (the Large Pot uses it for liquids and dye). */
    protected InteractionResult extraUse(BlockState state, Level level, BlockPos pos, Player player,
                                         InteractionHand hand, ItemStack held) {
        return InteractionResult.PASS;
    }

    /** The bed whose plants the menu arranges when this block is clicked. A tank block above the floor hands over to the bottom pot. */
    protected PlantBedBlockEntity menuTarget(PlantBedBlockEntity bed) {
        return bed;
    }

    private static void openPlantMenu(ServerPlayer player, PlantBedBlockEntity bed, BlockPos openedAt) {
        BlockPos pos = bed.getBlockPos();
        int mask = GardenLayout.activeMask(bed.getLevel(), pos);
        NetworkHooks.openScreen(player,
                new SimpleMenuProvider((id, inv, p) -> new PlantBedMenu(id, inv, bed, openedAt),
                        Component.translatable("container.mikexxx_flowerbeds.plant_bed")),
                buf -> {
                    buf.writeBlockPos(pos);
                    buf.writeInt(mask);
                });
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);
        if (!level.isClientSide && !state.is(oldState.getBlock())) {
            reconcileAround(level, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock())) {
            if (level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed) {
                bed.dropContents();
            }
            level.removeBlockEntity(pos);
            if (!level.isClientSide) {
                reconcileAround(level, pos);
            }
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    private static void reconcileAround(Level level, BlockPos pos) {
        for (Direction side : GardenLayout.SIDES) {
            if (level.getBlockEntity(pos.relative(side)) instanceof PlantBedBlockEntity bed) {
                bed.reconcile();
            }
        }
    }
}
