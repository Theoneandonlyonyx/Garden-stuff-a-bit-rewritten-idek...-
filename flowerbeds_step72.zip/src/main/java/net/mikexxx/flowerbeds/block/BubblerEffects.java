package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.registry.ModParticles;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Client side of the bubbler: a spiral of bubbles in the colour of the water (dye, sakura or violet aroma, biome). */
public final class BubblerEffects {
    private static final double RANGE = 24.0;

    private BubblerEffects() {
    }

    /** True when this pot or any pot joined to it gets a redstone signal: one powered pot runs every joined bubbler. */
    private static boolean groupPowered(Level level, BlockPos start, BlockState startState) {
        java.util.ArrayDeque<BlockPos> queue = new java.util.ArrayDeque<>();
        java.util.HashSet<BlockPos> seen = new java.util.HashSet<>();
        queue.add(start);
        seen.add(start);
        while (!queue.isEmpty() && seen.size() <= 128) {
            BlockPos p = queue.poll();
            if (level.hasNeighborSignal(p)) {
                return true;
            }
            BlockState st = p.equals(start) ? startState : level.getBlockState(p);
            if (!(st.getBlock() instanceof LargePotBlock)) {
                continue;
            }
            for (net.minecraft.core.Direction d : net.minecraft.core.Direction.values()) {
                BlockPos q = p.relative(d);
                if (seen.contains(q) || !joined(st, d)) {
                    continue;
                }
                BlockState other = level.getBlockState(q);
                if (other.getBlock() instanceof LargePotBlock) {
                    seen.add(q);
                    queue.add(q);
                }
            }
        }
        return false;
    }

    private static boolean joined(BlockState st, net.minecraft.core.Direction d) {
        return switch (d) {
            case NORTH -> st.getValue(LargePotBlock.NORTH);
            case SOUTH -> st.getValue(LargePotBlock.SOUTH);
            case WEST -> st.getValue(LargePotBlock.WEST);
            case EAST -> st.getValue(LargePotBlock.EAST);
            case UP -> st.hasProperty(GlassPotBlock.UP) && st.getValue(GlassPotBlock.UP);
            case DOWN -> st.hasProperty(GlassPotBlock.DOWN) && st.getValue(GlassPotBlock.DOWN);
        };
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, LargePotBlockEntity pot) {
        if (!pot.hasBubbler() || pot.liquidSource().getLiquid() != LargePotBlock.Liquid.WATER) {
            return;
        }
        if (level.getNearestPlayer(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, RANGE, false) == null) {
            return;
        }
        if (!groupPowered(level, pos, state)) {
            return;
        }
        RandomSource random = level.random;
        if (random.nextFloat() > 0.55F) {
            return;
        }
        int rgb;
        LargePotBlockEntity source = pot.liquidSource();
        if (pot.isVioletWater()) {
            rgb = 0xC9A8F5;
        } else if (pot.isAromaticWater()) {
            rgb = 0xF8BFD6;
        } else if (source.getDyeColor() >= 0) {
            rgb = source.getDyeColor();
        } else {
            rgb = BiomeColors.getAverageWaterColor(level, pos);
        }
        // Lighter than the water so the bubbles read against it.
        float r = Math.min(1.0F, ((rgb >> 16 & 255) / 255.0F) * 0.45F + 0.55F);
        float g = Math.min(1.0F, ((rgb >> 8 & 255) / 255.0F) * 0.45F + 0.55F);
        float b = Math.min(1.0F, ((rgb & 255) / 255.0F) * 0.45F + 0.55F);
        boolean bath = state.getBlock() instanceof BirdbathBlock;
        double y = pos.getY() + (bath ? 14.4 / 16.0 : 3.0 / 16.0);
        double top = pos.getY() + (bath ? 15.1 / 16.0 : 14.4 / 16.0);
        level.addParticle(ModParticles.BUBBLER_BUBBLE.get(), pos.getX() + 0.5, y, pos.getZ() + 0.5, r, g, b);
        // encode how far it may rise through the lifetime: the particle reads the height from the world itself
        if (random.nextInt(4) == 0) {
            level.addParticle(ModParticles.BUBBLER_BUBBLE.get(), pos.getX() + 0.5, y, pos.getZ() + 0.5, r, g, b);
        }
    }
}
