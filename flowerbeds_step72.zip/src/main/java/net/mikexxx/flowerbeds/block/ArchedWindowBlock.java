package net.mikexxx.flowerbeds.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.mikexxx.flowerbeds.block.entity.ArchedWindowBlockEntity;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Roman arched window. Windows of the same facing that touch form one window up to 6 wide. Its top is a true
 * semicircle over the whole width (the top ceil(width / 2) rows), everything below is straight. Each block works
 * out its own place in the window: width, column, row from the top (4 = straight part) and whether it has the sill.
 */
public class ArchedWindowBlock extends Block implements EntityBlock {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final IntegerProperty WIDTH = IntegerProperty.create("width", 1, 6);
    public static final IntegerProperty COL = IntegerProperty.create("col", 0, 5);
    public static final IntegerProperty ROW = IntegerProperty.create("row", 0, 5);
    public static final net.minecraft.world.level.block.state.properties.BooleanProperty LIT = BlockStateProperties.LIT;
    public static final IntegerProperty HEIGHT = IntegerProperty.create("height", 1, 6);
    private static final VoxelShape NS = Block.box(0, 0, 5, 16, 16, 11);
    private static final VoxelShape EW = Block.box(5, 0, 0, 11, 16, 16);

    public ArchedWindowBlock(BlockBehaviour.Properties properties) {
        super(properties.noOcclusion().lightLevel(st -> st.getValue(LIT) ? 11 : 0));
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(WIDTH, 1)
                .setValue(COL, 0).setValue(ROW, 0).setValue(HEIGHT, 1).setValue(LIT, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, WIDTH, COL, ROW, HEIGHT, LIT);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return fit(context.getLevel(), context.getClickedPos(),
                defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite()));
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return state.getValue(FACING).getAxis() == Direction.Axis.Z ? NS : EW;
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState old, boolean moving) {
        if (!old.is(this)) {
            refresh(level, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState next, boolean moving) {
        if (!next.is(this) && !level.isClientSide && level.getBlockEntity(pos) instanceof ArchedWindowBlockEntity be
                && be.getCandle() != null) {
            net.minecraft.world.Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    new ItemStack(be.getCandle().getBlock(), be.getCandle().getValue(net.minecraft.world.level.block.CandleBlock.CANDLES)));
        }
        if (!next.is(this) && !level.isClientSide && level.getBlockEntity(pos) instanceof ArchedWindowBlockEntity be
                && be.getDecor() != null) {
            for (ItemStack drop : decorStacks(be.getDecor())) {
                net.minecraft.world.Containers.dropItemStack(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, drop);
            }
        }
        super.onRemove(state, level, pos, next, moving);
        if (!next.is(this)) {
            refresh(level, pos);
        }
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                  BlockPos pos, BlockPos neighborPos) {
        return fit(level, pos, state);
    }

    /** Recomputes every window block around a change: the runs reach 12 sideways, and rows/sills 6 up or down. */
    private void refresh(Level level, BlockPos pos) {
        if (level.isClientSide) {
            return;
        }
        for (Direction side : Direction.Plane.HORIZONTAL) {
            for (int dx = -12; dx <= 12; dx++) {
                for (int dy = -6; dy <= 2; dy++) {
                    BlockPos p = pos.relative(side, dx).above(dy);
                    BlockState s = level.getBlockState(p);
                    if (s.is(this)) {
                        BlockState fitted = fit(level, p, s);
                        if (fitted != s) {
                            level.setBlock(p, fitted, 2);
                        }
                    }
                }
            }
        }
    }

    private boolean same(LevelAccessor level, BlockPos pos, Direction facing) {
        BlockState s = level.getBlockState(pos);
        return s.is(this) && s.getValue(FACING) == facing;
    }

    /** True for the cell that carries the sill (the bottom row of the window). */
    public static boolean hasSill(BlockState state) {
        return Math.min(state.getValue(ROW), state.getValue(HEIGHT) - 1) == state.getValue(HEIGHT) - 1;
    }

    /** Anything besides candles that can stand on a sill: lanterns, flower pots (and plants into them), fruit, jack o'lanterns. */
    private static boolean isDecorItem(ItemStack held) {
        return held.getItem() instanceof BlockItem bi && (bi.getBlock() instanceof net.minecraft.world.level.block.LanternBlock
                || bi.getBlock() instanceof net.minecraft.world.level.block.FlowerPotBlock)
                || held.is(net.mikexxx.flowerbeds.garden.GardenLayout.SCALED_FRUIT);
    }

    /** The potted version of a plant, or null when vanilla has none. */
    private static BlockState potted(ItemStack held) {
        if (!(held.getItem() instanceof BlockItem bi)) {
            return null;
        }
        net.minecraft.resources.ResourceLocation id = net.minecraftforge.registries.ForgeRegistries.BLOCKS.getKey(bi.getBlock());
        if (id == null) {
            return null;
        }
        net.minecraft.world.level.block.Block pot = net.minecraftforge.registries.ForgeRegistries.BLOCKS.getValue(
                new net.minecraft.resources.ResourceLocation(id.getNamespace(), "potted_" + id.getPath()));
        return pot instanceof net.minecraft.world.level.block.FlowerPotBlock fp && fp.getContent() == bi.getBlock()
                ? pot.defaultBlockState() : null;
    }

    private InteractionResult useDecor(BlockState state, Level level, BlockPos pos, Player player,
                                       InteractionHand hand, ItemStack held) {
        if (!hasSill(state) || !(level.getBlockEntity(pos) instanceof ArchedWindowBlockEntity be) || be.getCandle() != null) {
            return null;
        }
        BlockState decor = be.getDecor();
        boolean bare = held.isEmpty() && hand == InteractionHand.MAIN_HAND;
        if (decor == null && isDecorItem(held)) {
            BlockState placed = ((BlockItem) held.getItem()).getBlock().defaultBlockState();
            if (placed.hasProperty(net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING)) {
                placed = placed.setValue(net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING, state.getValue(FACING));
            }
            if (!level.isClientSide) {
                be.setDecor(placed);
                if (placed.getLightEmission() > 0) {
                    level.setBlock(pos, state.setValue(LIT, true), 3);
                }
                level.playSound(null, pos, SoundEvents.LANTERN_PLACE, SoundSource.BLOCKS, 1.0F, 1.0F);
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (decor == null) {
            return null;
        }
        if (decor.getBlock() == net.minecraft.world.level.block.Blocks.FLOWER_POT && potted(held) != null) {
            if (!level.isClientSide) {
                be.setDecor(potted(held));
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                level.playSound(null, pos, SoundEvents.GRASS_PLACE, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (bare && player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                java.util.List<ItemStack> back = decorStacks(decor);
                be.setDecor(null);
                if (!state.getValue(LIT).equals(false)) {
                    level.setBlock(pos, state.setValue(LIT, false), 3);
                }
                for (ItemStack stack : back) {
                    if (!player.getInventory().add(stack)) {
                        player.drop(stack, false);
                    }
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return null;
    }

    /** What a sill decoration gives back: the block itself, or for a potted plant the empty pot and the plant. */
    private static java.util.List<ItemStack> decorStacks(BlockState decor) {
        java.util.List<ItemStack> out = new java.util.ArrayList<>();
        if (decor.getBlock() instanceof net.minecraft.world.level.block.FlowerPotBlock fp) {
            out.add(new ItemStack(net.minecraft.world.level.block.Blocks.FLOWER_POT));
            if (fp.getContent() != net.minecraft.world.level.block.Blocks.AIR) {
                out.add(new ItemStack(fp.getContent()));
            }
        } else {
            out.add(new ItemStack(decor.getBlock()));
        }
        return out;
    }

    /**
     * Candles stand on the sill, up to four per sill block, any colour (one colour per block). Flint and steel or a
     * fire charge lights them, an empty hand snuffs them, sneak with an empty hand takes one back off.
     * Returns null when the click is not about candles.
     */
    private InteractionResult useCandles(BlockState state, Level level, BlockPos pos, Player player,
                                         InteractionHand hand, ItemStack held, BlockHitResult hit) {
        if (!hasSill(state) || !(level.getBlockEntity(pos) instanceof ArchedWindowBlockEntity be)) {
            return null;
        }
        boolean isCandle = held.getItem() instanceof BlockItem bi && bi.getBlock() instanceof net.minecraft.world.level.block.CandleBlock;
        boolean light = held.is(net.minecraft.world.item.Items.FLINT_AND_STEEL) || held.is(net.minecraft.world.item.Items.FIRE_CHARGE);
        boolean bare = held.isEmpty() && hand == InteractionHand.MAIN_HAND;
        BlockState candle = be.getCandle();
        if (be.getDecor() != null) {
            return null;
        }
        if (isCandle) {
            net.minecraft.world.level.block.Block block = ((BlockItem) held.getItem()).getBlock();
            if (candle != null && (candle.getBlock() != block || candle.getValue(net.minecraft.world.level.block.CandleBlock.CANDLES) >= 4)) {
                return InteractionResult.PASS;
            }
            if (!level.isClientSide) {
                int n = candle == null ? 1 : candle.getValue(net.minecraft.world.level.block.CandleBlock.CANDLES) + 1;
                BlockState placed = block.defaultBlockState().setValue(net.minecraft.world.level.block.CandleBlock.CANDLES, n)
                        .setValue(net.minecraft.world.level.block.CandleBlock.LIT, candle != null && candle.getValue(net.minecraft.world.level.block.CandleBlock.LIT));
                be.setCandle(placed);
                level.playSound(null, pos, SoundEvents.CANDLE_PLACE, SoundSource.BLOCKS, 1.0F, 1.0F);
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (candle == null) {
            return null;
        }
        boolean lit = candle.getValue(net.minecraft.world.level.block.CandleBlock.LIT);
        if (light && !lit) {
            if (!level.isClientSide) {
                be.setCandle(candle.setValue(net.minecraft.world.level.block.CandleBlock.LIT, true));
                level.setBlock(pos, state.setValue(LIT, true), 3);
                level.playSound(null, pos, SoundEvents.FLINTANDSTEEL_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
                if (!player.getAbilities().instabuild) {
                    held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (bare && !player.isShiftKeyDown() && lit) {
            if (!level.isClientSide) {
                be.setCandle(candle.setValue(net.minecraft.world.level.block.CandleBlock.LIT, false));
                level.setBlock(pos, state.setValue(LIT, false), 3);
                level.playSound(null, pos, SoundEvents.CANDLE_EXTINGUISH, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (bare && player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                int n = candle.getValue(net.minecraft.world.level.block.CandleBlock.CANDLES);
                ItemStack back = new ItemStack(candle.getBlock());
                be.setCandle(n <= 1 ? null : candle.setValue(net.minecraft.world.level.block.CandleBlock.CANDLES, n - 1));
                if (n <= 1) {
                    level.setBlock(pos, state.setValue(LIT, false), 3);
                }
                if (!player.getInventory().add(back)) {
                    player.drop(back, false);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return null;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ArchedWindowBlockEntity(pos, state);
    }

    /**
     * Right-click with a full block: its texture fills the lattice area (the corners outside the arch) of the whole
     * connected window, in the very same spot. Sneak with an empty hand puts the wooden lattice back.
     */
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand,
                                 BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        boolean creative = player.getAbilities().instabuild;
        InteractionResult decorResult = useDecor(state, level, pos, player, hand, held);
        if (decorResult != null) {
            return decorResult;
        }
        InteractionResult candleResult = useCandles(state, level, pos, player, hand, held, hit);
        if (candleResult != null) {
            return candleResult;
        }
        BlockState next = null;
        if (held.getItem() instanceof BlockItem bi && !(bi.getBlock() instanceof ArchedWindowBlock)) {
            BlockState candidate = bi.getBlock().defaultBlockState();
            if (!candidate.hasBlockEntity() && candidate.isCollisionShapeFullBlock(level, pos)) {
                next = candidate;
            }
        } else if (!(held.isEmpty() && player.isShiftKeyDown() && hand == InteractionHand.MAIN_HAND)) {
            return InteractionResult.PASS;
        }
        if (next == null && !held.isEmpty()) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        Direction facing = state.getValue(FACING);
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        queue.add(pos);
        seen.add(pos);
        ItemStack back = ItemStack.EMPTY;
        while (!queue.isEmpty() && seen.size() < 400) {
            BlockPos p = queue.poll();
            if (level.getBlockEntity(p) instanceof ArchedWindowBlockEntity be) {
                if (be.getMimic() != null && back.isEmpty() && !be.getMimic().equals(next)) {
                    back = new ItemStack(be.getMimic().getBlock());
                }
                be.setMimic(next);
            }
            for (Direction d : new Direction[]{Direction.UP, Direction.DOWN, facing.getClockWise(), facing.getCounterClockWise()}) {
                BlockPos q = p.relative(d);
                if (!seen.contains(q) && same(level, q, facing)) {
                    seen.add(q);
                    queue.add(q);
                }
            }
        }
        if (next != null) {
            level.playSound(null, pos, next.getSoundType().getPlaceSound(), SoundSource.BLOCKS, 1.0F, 1.0F);
            if (!creative) {
                held.shrink(1);
            }
        }
        if (!back.isEmpty() && !creative && !player.getInventory().add(back)) {
            player.drop(back, false);
        }
        return InteractionResult.CONSUME;
    }

    private int columnTop(LevelAccessor level, BlockPos bottom, Direction facing) {
        int n = 0;
        while (n < 5 && same(level, bottom.above(n + 1), facing)) {
            n++;
        }
        return n;
    }

    /**
     * Works out the window from its bottom row: a replaced corner does not break it. Run of the bottom row = width
     * (chunks of 6), the tallest column = height (up to 6), this block's row counts down from that top.
     */
    private BlockState fit(LevelAccessor level, BlockPos pos, BlockState state) {
        Direction facing = state.getValue(FACING);
        Direction along = facing.getClockWise();
        BlockPos bottom = pos;
        while (bottom.getY() > pos.getY() - 8 && same(level, bottom.below(), facing)) {
            bottom = bottom.below();
        }
        int behind = 0;
        while (behind < 48 && same(level, bottom.relative(along, -(behind + 1)), facing)) {
            behind++;
        }
        int ahead = 0;
        while (ahead < 48 && same(level, bottom.relative(along, ahead + 1), facing)) {
            ahead++;
        }
        int start = behind / 6 * 6;
        int width = Math.min(6, behind + 1 + ahead - start);
        int tallest = 0;
        for (int i = 0; i < width; i++) {
            tallest = Math.max(tallest, columnTop(level, bottom.relative(along, i - (behind - start)), facing));
        }
        int height = Math.min(6, tallest + 1);
        int row = Math.max(0, Math.min(5, tallest - (pos.getY() - bottom.getY())));
        return state.setValue(WIDTH, width).setValue(COL, behind - start).setValue(HEIGHT, height).setValue(ROW, row);
    }
}
