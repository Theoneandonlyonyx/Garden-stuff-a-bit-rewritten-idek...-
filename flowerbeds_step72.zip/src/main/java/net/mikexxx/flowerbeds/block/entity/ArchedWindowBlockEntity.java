package net.mikexxx.flowerbeds.block.entity;

import net.mikexxx.flowerbeds.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.client.model.data.ModelProperty;

/** Remembers the block whose texture fills the lattice part of an arched window cell (null = the wooden lattice). */
public class ArchedWindowBlockEntity extends BlockEntity {

    public static final ModelProperty<BlockState> MIMIC = new ModelProperty<>();

    public static final ModelProperty<BlockState> CANDLE = new ModelProperty<>();

    public static final ModelProperty<BlockState> DECOR = new ModelProperty<>();

    private BlockState mimic;
    private BlockState candle;
    /** Lantern, flower pot, fruit or jack o'lantern standing on the sill (instead of candles). */
    private BlockState decor;

    public ArchedWindowBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ARCHED_WINDOW.get(), pos, state);
    }

    public BlockState getMimic() {
        return mimic;
    }

    public void setMimic(BlockState state) {
        this.mimic = state;
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
        requestModelDataUpdate();
    }

    public BlockState getCandle() {
        return candle;
    }

    public BlockState getDecor() {
        return decor;
    }

    public void setDecor(BlockState state) {
        this.decor = state;
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
        requestModelDataUpdate();
    }

    public void setCandle(BlockState state) {
        this.candle = state;
        setChanged();
        if (level != null) {
            level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
        requestModelDataUpdate();
    }

    @Override
    public ModelData getModelData() {
        ModelData.Builder b = ModelData.builder();
        if (mimic != null) {
            b.with(MIMIC, mimic);
        }
        if (candle != null) {
            b.with(CANDLE, candle);
        }
        if (decor != null) {
            b.with(DECOR, decor);
        }
        return b.build();
    }

    @Override
    public void onLoad() {
        super.onLoad();
        requestModelDataUpdate();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (mimic != null) {
            tag.put("Mimic", NbtUtils.writeBlockState(mimic));
        }
        if (candle != null) {
            tag.put("Candle", NbtUtils.writeBlockState(candle));
        }
        if (decor != null) {
            tag.put("Decor", NbtUtils.writeBlockState(decor));
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        mimic = tag.contains("Mimic")
                ? NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), tag.getCompound("Mimic")) : null;
        candle = tag.contains("Candle")
                ? NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), tag.getCompound("Candle")) : null;
        decor = tag.contains("Decor")
                ? NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), tag.getCompound("Decor")) : null;
        requestModelDataUpdate();
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
