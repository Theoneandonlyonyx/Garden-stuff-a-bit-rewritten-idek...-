package net.mikexxx.flowerbeds.block.entity;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.WindowBoxBlock;
import net.mikexxx.flowerbeds.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * A window box starts empty. It takes a substrate or a liquid, and then holds five plants in slots 0..4. Slots 0-2 are the three evenly spaced places and slots 3 and
 * 4 are the gaps between the middle one and its neighbours, so filling in order gives the classic three
 * first. Vines in a slot hang down over the box, and bone meal makes them hang longer.
 */
public class WindowBoxBlockEntity extends PlantBedBlockEntity {

    public static final int SLOTS = 5;
    /** Highest growth age of a trailing plant. Each age makes the hanging strands longer. */
    public static final int MAX_TRAIL_AGE = 4;
    public static final TagKey<Block> TRAILING_PLANTS =
            TagKey.create(Registries.BLOCK, new ResourceLocation(PmpMikexxx.MODID, "trailing_plants"));

    /** The block the box is filled with (dirt, sand, ...), or null. A box holds a substrate or a liquid, not both. */
    private Block substrate;
    private LargePotBlock.Liquid liquid = LargePotBlock.Liquid.NONE;

    public WindowBoxBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.WINDOW_BOX.get(), pos, state);
    }

    /** The soil inside the box sits just under 6/16 up. */
    @Override
    public float bedHeight() {
        return 0.33F;
    }

    public Block getSubstrate() {
        return substrate;
    }

    @Override
    public BlockState substrateState() {
        return substrate == null ? null : substrate.defaultBlockState();
    }

    public LargePotBlock.Liquid getLiquid() {
        return liquid;
    }

    public boolean hasFill() {
        return substrate != null || liquid != LargePotBlock.Liquid.NONE;
    }

    /** Fills with a substrate block (emptying any liquid), or empties the substrate with null. */
    public void setSubstrate(Block block) {
        this.substrate = block;
        if (block != null) {
            liquid = LargePotBlock.Liquid.NONE;
        }
        updateBlockState();
        onSlotsChanged();
    }

    /** Fills with a liquid (emptying any substrate), or empties the liquid with NONE. */
    public void setLiquid(LargePotBlock.Liquid newLiquid) {
        this.liquid = newLiquid;
        if (newLiquid != LargePotBlock.Liquid.NONE) {
            substrate = null;
        }
        updateBlockState();
        onSlotsChanged();
    }

    /** What the box holds, as the item that gives it back (block item or bucket). */
    public ItemStack removeFill() {
        if (substrate != null) {
            return new ItemStack(substrate);
        }
        return switch (liquid) {
            case WATER -> new ItemStack(Items.WATER_BUCKET);
            case LAVA -> new ItemStack(Items.LAVA_BUCKET);
            case MILK -> new ItemStack(Items.MILK_BUCKET);
            default -> ItemStack.EMPTY;
        };
    }

    /** Lava lights the box. */
    @Override
    public int lightLevel() {
        return Math.max(super.lightLevel(), liquid == LargePotBlock.Liquid.LAVA ? 15 : 0);
    }

    @Override
    protected int maxAgeOf(ItemStack stack) {
        if (stack.getItem() instanceof BlockItem blockItem) {
            BlockState state = blockItem.getBlock().defaultBlockState();
            if (WindowBoxBlock.isTrailing(state)) {
                return MAX_TRAIL_AGE;
            }
        }
        return super.maxAgeOf(stack);
    }

    @Override
    public void dropContents() {
        super.dropContents();
        if (level != null && !level.isClientSide && substrate != null) {
            Block.popResource(level, worldPosition, new ItemStack(substrate));
            substrate = null;
        }
    }

    /** Vines hang down to more than a block below the box, so the draw box reaches down as well. */
    @Override
    public AABB getRenderBoundingBox() {
        return new AABB(worldPosition.getX() - 1, worldPosition.getY() - 2, worldPosition.getZ() - 1,
                worldPosition.getX() + 2, worldPosition.getY() + 10, worldPosition.getZ() + 2);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putString("Liquid", liquid.getSerializedName());
        if (substrate != null) {
            ResourceLocation key = ForgeRegistries.BLOCKS.getKey(substrate);
            if (key != null) {
                tag.putString("Substrate", key.toString());
            }
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        substrate = null;
        liquid = LargePotBlock.Liquid.NONE;
        for (LargePotBlock.Liquid candidate : LargePotBlock.Liquid.values()) {
            if (candidate.getSerializedName().equals(tag.getString("Liquid"))) {
                liquid = candidate;
            }
        }
        if (tag.contains("Substrate")) {
            ResourceLocation key = ResourceLocation.tryParse(tag.getString("Substrate"));
            if (key != null && ForgeRegistries.BLOCKS.containsKey(key)) {
                substrate = ForgeRegistries.BLOCKS.getValue(key);
            }
        }
    }
}
