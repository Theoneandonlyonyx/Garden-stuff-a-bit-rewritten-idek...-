package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.WindowBoxBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.mikexxx.flowerbeds.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;


/**
 * Window box: a long, shallow planter. Right-click with a plant to add it: the first three go to the three
 * evenly spaced places, the fourth and fifth fill the gaps next to the middle one. An empty hand takes the
 * last one back out (and, once it is empty, scoops out a custom substrate). A window box starts empty: fill it with soil, sand or
 * any other growing block, or a liquid bucket, before planting. Bone meal grows the plants.
 */
public class WindowBoxBlock extends PlantBedBlock {

    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

    private static final VoxelShape NORTH = Block.box(0, 0, 0, 16, 6, 6);
    private static final VoxelShape SOUTH = Block.box(0, 0, 10, 16, 6, 16);
    private static final VoxelShape WEST = Block.box(0, 0, 0, 6, 6, 16);
    private static final VoxelShape EAST = Block.box(10, 0, 0, 16, 6, 16);

    public WindowBoxBlock(boolean wood) {
        super((wood
                ? Properties.of().mapColor(MapColor.WOOD).strength(0.8F).sound(SoundType.WOOD)
                : Properties.of().mapColor(MapColor.STONE).strength(1.2F).sound(SoundType.STONE).requiresCorrectToolForDrops())
                .noOcclusion().dynamicShape()
                .lightLevel(state -> state.getValue(LIGHT)));
        registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(LIGHT, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(FACING);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return switch (state.getValue(FACING)) {
            case SOUTH -> SOUTH;
            case WEST -> WEST;
            case EAST -> EAST;
            default -> NORTH;
        };
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new WindowBoxBlockEntity(pos, state);
    }

    /** Window boxes are planted by clicking, so the trowel does nothing special here. */
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (player.getItemInHand(hand).is(ModItems.TROWEL.get())) {
            return InteractionResult.PASS;
        }
        return super.use(state, level, pos, player, hand, hit);
    }

    /** Plants, vines, tall growers, and the candles, lanterns and fruit that the other beds take. */
    public static boolean accepts(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        BlockState state = blockItem.getBlock().defaultBlockState();
        return state.getBlock() instanceof BushBlock || isTrailing(state) || PlantStates.isVerticalGrower(state)
                || stack.is(GardenLayout.CANDLES) || stack.is(GardenLayout.LANTERNS) || stack.is(GardenLayout.SCALED_FRUIT);
    }

    /** Vines and other trailing plants hang down over the box instead of standing in it. */
    public static boolean isTrailing(BlockState state) {
        return state.getBlock() instanceof VineBlock || state.is(WindowBoxBlockEntity.TRAILING_PLANTS);
    }

    @Override
    protected InteractionResult extraUse(BlockState state, Level level, BlockPos pos, Player player,
                                         InteractionHand hand, ItemStack held) {
        if (!(level.getBlockEntity(pos) instanceof WindowBoxBlockEntity box)) {
            return InteractionResult.PASS;
        }
        boolean creative = player.getAbilities().instabuild;

        // Fill with a substrate block or a liquid bucket. The new fill replaces the old one, which comes back.
        LargePotBlock.Liquid incomingLiquid = liquidOf(held);
        boolean incomingSubstrate = incomingLiquid == null && !held.isEmpty()
                && GardenLayout.isSubstrate(held, level, pos);
        if (incomingLiquid != null || incomingSubstrate) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            Block incoming = incomingSubstrate ? ((BlockItem) held.getItem()).getBlock() : null;
            if ((incomingLiquid != null && box.getLiquid() == incomingLiquid)
                    || (incoming != null && box.getSubstrate() == incoming)) {
                return InteractionResult.SUCCESS;
            }
            ItemStack old = box.removeFill();
            if (incomingLiquid != null) {
                box.setLiquid(incomingLiquid);
            } else {
                box.setSubstrate(incoming);
            }
            level.playSound(null, pos, incomingLiquid == LargePotBlock.Liquid.LAVA ? SoundEvents.BUCKET_EMPTY_LAVA
                    : incomingLiquid != null ? SoundEvents.BUCKET_EMPTY
                    : incoming.defaultBlockState().getSoundType().getPlaceSound(), SoundSource.BLOCKS, 1.0F, 1.0F);
            if (!creative) {
                boolean oldIsBucket = old.is(Items.WATER_BUCKET) || old.is(Items.LAVA_BUCKET) || old.is(Items.MILK_BUCKET);
                held.shrink(1);
                if (incomingLiquid != null && !oldIsBucket) {
                    give(player, hand, new ItemStack(Items.BUCKET));
                }
                give(player, hand, old);
            }
            return InteractionResult.SUCCESS;
        }

        // An empty bucket takes the liquid out again.
        if (held.is(Items.BUCKET)) {
            if (box.getLiquid() != LargePotBlock.Liquid.NONE) {
                if (!level.isClientSide) {
                    ItemStack filled = box.removeFill();
                    box.setLiquid(LargePotBlock.Liquid.NONE);
                    player.setItemInHand(hand, ItemUtils.createFilledResult(held, player, filled));
                    level.playSound(null, pos, SoundEvents.BUCKET_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
                }
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        }

        // A plant goes into the next free place: three even ones first, then the two gaps.
        if (!held.isEmpty() && accepts(held)) {
            if (!box.hasFill()) {
                if (!level.isClientSide) {
                    player.displayClientMessage(Component.translatable(
                            "message.mikexxx_flowerbeds.box_needs_substrate"), true);
                }
                return InteractionResult.SUCCESS;
            }
            for (int i = 0; i < WindowBoxBlockEntity.SLOTS; i++) {
                if (box.getSlot(i).isEmpty()) {
                    if (!level.isClientSide) {
                        box.setSlot(i, held.copyWithCount(1), 0, 0);
                        level.playSound(null, pos, net.minecraft.sounds.SoundEvents.GRASS_PLACE,
                                SoundSource.BLOCKS, 0.8F, 1.0F);
                        if (!creative) {
                            held.shrink(1);
                        }
                    }
                    return InteractionResult.sidedSuccess(level.isClientSide);
                }
            }
            return InteractionResult.PASS;
        }

        // Empty hand: take the last plant back; with no plants left, scoop out a custom substrate.
        if (held.isEmpty() && hand == InteractionHand.MAIN_HAND) {
            for (int i = WindowBoxBlockEntity.SLOTS - 1; i >= 0; i--) {
                ItemStack plant = box.getSlot(i);
                if (!plant.isEmpty()) {
                    if (!level.isClientSide) {
                        ItemStack back = plant.copy();
                        box.setSlot(i, ItemStack.EMPTY, 0, 0);
                        give(player, hand, back);
                    }
                    return InteractionResult.sidedSuccess(level.isClientSide);
                }
            }
            if (box.getSubstrate() != null) {
                if (!level.isClientSide) {
                    ItemStack back = new ItemStack(box.getSubstrate());
                    box.setSubstrate(null);
                    give(player, hand, back);
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return InteractionResult.PASS;
    }

    private static LargePotBlock.Liquid liquidOf(ItemStack held) {
        if (held.is(Items.WATER_BUCKET)) return LargePotBlock.Liquid.WATER;
        if (held.is(Items.LAVA_BUCKET)) return LargePotBlock.Liquid.LAVA;
        if (held.is(Items.MILK_BUCKET)) return LargePotBlock.Liquid.MILK;
        return null;
    }

    private static void give(Player player, InteractionHand hand, ItemStack stack) {
        if (stack.isEmpty()) {
            return;
        }
        if (player.getItemInHand(hand).isEmpty()) {
            player.setItemInHand(hand, stack);
        } else if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }
}
