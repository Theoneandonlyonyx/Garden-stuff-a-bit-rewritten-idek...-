package net.mikexxx.flowerbeds;

import net.mikexxx.flowerbeds.registry.ModBlockEntities;
import net.mikexxx.flowerbeds.registry.ModBlocks;
import net.mikexxx.flowerbeds.registry.ModCreativeTabs;
import net.mikexxx.flowerbeds.registry.ModItems;
import net.mikexxx.flowerbeds.registry.ModMenus;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(PmpMikexxx.MODID)
public class PmpMikexxx {
    public static final String MODID = "mikexxx_flowerbeds";

    public PmpMikexxx() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModMenus.MENUS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
