package net.mikexxx.flowerbeds.client.renderer;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;

/** Tint colours for blocks that are drawn by a bed instead of by the chunk renderer. */
public final class PlantTint {
    private PlantTint() {}

    /** Plain green, used when a block's own colour handler cannot give a colour at this position. */
    public static final int PLACEHOLDER_GREEN = 0x7CBD6B;

    /**
     * RGB colour for a tint index of the state at the given position: the real biome colour for grass,
     * foliage and water, or white when the block has no colour handler.
     */
    public static int color(BlockState state, BlockAndTintGetter level, BlockPos pos, int tintIndex) {
        if (tintIndex < 0) {
            return 0xFFFFFF;
        }
        try {
            int color = Minecraft.getInstance().getBlockColors().getColor(state, level, pos, tintIndex);
            return color == -1 ? 0xFFFFFF : color;
        } catch (RuntimeException e) {
            return PLACEHOLDER_GREEN;
        }
    }
}
