# Step 24 (on step 23)
- Quartz Pot (`quartz_pot`), separate from the square Quartz Large Pot. A single pot is round. Put another Quartz Pot against a side and that side opens; the corner between two open sides stays until a Quartz Pot sits across that corner too.
- It uses the large-pot behaviour: the trowel opens Arrange Plants, and it takes soil, sand and the other substrates, water, lava and milk, dyed water, a thin floor layer under water, and a whirlpool from a magma block. Plants are drawn in it. It connects only to other Quartz Pots, not to the square quartz large pot.
- Crafted from smooth quartz in the pot pattern (the square quartz pot still uses quartz blocks). Mined with a pickaxe. In the flowerbeds tab.
- The model pack had no textures. Stand-ins are `textures/block/quartz_pot_side.png`, `quartz_pot_band.png`, `quartz_pot_top.png` and `quartz_pot_inner.png`. Replace those four files to use the real ones.
- The `quartz_pot_round_*` models are included. The block does not stack them on the connected models: `quartz_pot_0000_0000` and the other full models already are the whole pot, and drawing the round pieces as well would paint it twice.
