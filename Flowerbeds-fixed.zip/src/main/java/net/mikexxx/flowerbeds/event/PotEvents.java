package net.mikexxx.flowerbeds.event;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Left-clicking a water pot or tank with a magma block in the hand starts a whirlpool in the water (and a second
 * click stops it again), the way magma makes a bubble column in the world. The click does not damage the pot.
 */
@Mod.EventBusSubscriber(modid = PmpMikexxx.MODID)
public final class PotEvents {
    private PotEvents() {}

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND || !event.getItemStack().is(Items.MAGMA_BLOCK)) {
            return;
        }
        Level level = event.getLevel();
        BlockPos pos = event.getPos();
        if (!(level.getBlockState(pos).getBlock() instanceof LargePotBlock)
                || !(level.getBlockEntity(pos) instanceof LargePotBlockEntity pot)) {
            return;
        }
        LargePotBlockEntity source = pot.liquidSource();
        if (source.getLiquid() != LargePotBlock.Liquid.WATER) {
            return;
        }
        // Never start breaking the pot with a magma block in the hand.
        event.setCanceled(true);
        if (level.isClientSide || event.getAction() != PlayerInteractEvent.LeftClickBlock.Action.START) {
            return;
        }
        boolean on = !source.isWhirlpool();
        source.setWhirlpool(on);
        level.playSound(null, pos, on ? SoundEvents.BUBBLE_COLUMN_WHIRLPOOL_INSIDE : SoundEvents.BUBBLE_COLUMN_BUBBLE_POP,
                SoundSource.BLOCKS, 0.9F, 1.0F);
    }
}
