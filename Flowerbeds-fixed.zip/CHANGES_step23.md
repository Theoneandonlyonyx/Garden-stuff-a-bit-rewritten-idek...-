# Step 23 (on step 22)
- Water and the floor layer in glass pots no longer leave a hairline gap. They now run a hair into the glass wall and the pot floor instead of stopping short of them (water meets the glass, and the faces never sit in the same plane).
- Pots now also say no when a fluid asks to replace them (`canBeReplaced(state, fluid)` is false), on top of refusing flowing liquid (`LiquidBlockContainer`, from step 22). Water or lava placed next to or on top of a pot, glass included, cannot break it into an item.
- No gap between joined pots: the glass models are exactly as in step 22 (an inset I tried first was taken out again).
