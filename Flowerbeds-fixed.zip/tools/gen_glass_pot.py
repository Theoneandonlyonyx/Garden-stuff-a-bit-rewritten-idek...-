#!/usr/bin/env python3
"""
Generates everything the Glass Large Pot looks like: two textures, ~100 small block models and the blockstate.
Run from the project root:  python3 tools/gen_glass_pot.py

Design (classic connected glass):
  * Every wall is ONE slab. It runs the whole block edge, so two pots side by side form one flat wall with
    no seam, no post and no face between them (this is what caused the vertical lines and the doubled wall).
  * A wall is only shortened where it meets a wall of the same pot at a corner, and it only gets an end cap
    where the glass really ends. A pot corner pillar exists only for an inner corner (two open sides, empty
    diagonal), and only draws its two inside faces.
  * Only the OUTER border of a connected glass build is outlined: the top rim, the bottom edge and the
    corner edges. Seams between joined pots are plain glass.
  * The rim on top is one solid pale-glass line, not two lines with a clear gap.
"""
import itertools
import json
import os

from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
ASSETS = os.path.join(ROOT, "src/main/resources/assets/mikexxx_flowerbeds")
MODELS = os.path.join(ASSETS, "models/block")
TEXTURES = os.path.join(ASSETS, "textures/block")
MODID = "mikexxx_flowerbeds"

EDGE = (232, 244, 250, 255)
SHEEN = (246, 251, 253, 255)

# ---------------------------------------------------------------------------------------------- textures


def tile_index(top, bottom, left, right):
    return (1 if top else 0) | (2 if bottom else 0) | (4 if left else 0) | (8 if right else 0)


def make_textures():
    os.makedirs(TEXTURES, exist_ok=True)
    sheet = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    for idx in range(16):
        top, bottom, left, right = bool(idx & 1), bool(idx & 2), bool(idx & 4), bool(idx & 8)
        tile = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
        px = tile.load()
        # a few bright pixels of sheen, like vanilla glass, but nothing at the borders
        for x, y in [(3, 3), (4, 3), (3, 4), (6, 6), (9, 10), (10, 9)]:
            px[x, y] = SHEEN
        for i in range(16):
            if top:
                px[i, 0] = EDGE
            if bottom:
                px[i, 15] = EDGE
            if left:
                px[0, i] = EDGE
            if right:
                px[15, i] = EDGE
        sheet.paste(tile, ((idx % 4) * 16, (idx // 4) * 16))
    sheet.save(os.path.join(TEXTURES, "glass_pot_ctm.png"))
    Image.new("RGBA", (16, 16), EDGE).save(os.path.join(TEXTURES, "glass_pot_edge.png"))

    # a small round bubble for the whirlpool
    b = Image.new("RGBA", (8, 8), (0, 0, 0, 0))
    bp = b.load()
    ring = [(2, 0), (3, 0), (4, 0), (5, 0), (1, 1), (6, 1), (0, 2), (7, 2), (0, 3), (7, 3), (0, 4), (7, 4),
            (0, 5), (7, 5), (1, 6), (6, 6), (2, 7), (3, 7), (4, 7), (5, 7)]
    for x, y in ring:
        bp[x, y] = (214, 236, 255, 235)
    for x, y in [(2, 1), (3, 1), (4, 1), (5, 1), (1, 2), (2, 2), (3, 2), (4, 2), (5, 2), (6, 2),
                 (1, 3), (2, 3), (3, 3), (4, 3), (5, 3), (6, 3), (1, 4), (2, 4), (3, 4), (4, 4), (5, 4), (6, 4),
                 (1, 5), (2, 5), (3, 5), (4, 5), (5, 5), (6, 5), (2, 6), (3, 6), (4, 6), (5, 6)]:
        bp[x, y] = (170, 210, 255, 90)
    bp[2, 2] = (255, 255, 255, 255)
    bp[3, 2] = (255, 255, 255, 255)
    bp[2, 3] = (255, 255, 255, 255)
    b.save(os.path.join(TEXTURES, "tank_bubble.png"))


# ---------------------------------------------------------------------------------------------- uv helpers

CTM = "#glass"
EDGE_TEX = "#edge"


def side_uv(direction, h0, h1, y0, y1):
    """uv pixel box (in the 16x16 tile) of a vertical face; viewer-left end differs per direction."""
    if direction in ("north", "east"):
        c0, c1 = 16 - h0, 16 - h1
    else:
        c0, c1 = h0, h1
    return min(c0, c1), 16 - y1, max(c0, c1), 16 - y0


def tile_face(direction, h0, h1, y0, y1, top=False, bottom=False, left=False, right=False):
    idx = tile_index(top, bottom, left, right)
    tc, tr = idx % 4, idx // 4
    u0, v0, u1, v1 = side_uv(direction, h0, h1, y0, y1)
    uv = [(tc * 16 + u0) / 4.0, (tr * 16 + v0) / 4.0, (tc * 16 + u1) / 4.0, (tr * 16 + v1) / 4.0]
    return {"texture": CTM, "uv": uv}


def solid_face():
    return {"texture": EDGE_TEX, "uv": [0, 0, 4, 4]}


def sheen_face():
    return {"texture": CTM, "uv": [0, 0, 4, 4]}


def element(frm, to, faces):
    return {"from": list(frm), "to": list(to), "faces": faces}


# ---------------------------------------------------------------------------------------------- geometry


def floor_elements(n, e, s, w):
    """n/e/s/w = that side is open to a joined pot (no wall, no outer face)."""
    faces = {"up": sheen_face(), "down": sheen_face()}
    if not n:
        faces["north"] = tile_face("north", 0, 16, 0, 2, bottom=True, left=not e, right=not w)
    if not s:
        faces["south"] = tile_face("south", 0, 16, 0, 2, bottom=True, left=not w, right=not e)
    if not e:
        faces["east"] = tile_face("east", 0, 16, 0, 2, bottom=True)
    if not w:
        faces["west"] = tile_face("west", 0, 16, 0, 2, bottom=True)
    return [element((0, 0, 0), (16, 2, 16), faces)]


def wall_elements(side, a_open, b_open, up, down):
    """
    side: 'n', 'e', 's', 'w' - the wall that exists (that side is closed).
    a_open/b_open: for n/s walls (west open, east open); for e/w walls (north open, south open).
    up/down: another glass pot sits above / below.
    """
    y0 = 0 if down else 2
    top_line = not up
    els = []
    if side in ("n", "s"):
        w_open, e_open = a_open, b_open
        west_exposed, east_exposed = not w_open, not e_open
        z0, z1 = (0, 2) if side == "n" else (14, 16)
        outer = "north" if side == "n" else "south"
        inner = "south" if side == "n" else "north"
        if side == "n":
            left, right = east_exposed, west_exposed   # viewer at north looks south: east is on the left
        else:
            left, right = west_exposed, east_exposed
        faces = {outer: tile_face(outer, 0, 16, y0, 16, top=top_line, left=left, right=right)}
        if top_line:
            faces["up"] = solid_face()
        if west_exposed:
            faces["west"] = solid_face()
        if east_exposed:
            faces["east"] = solid_face()
        els.append(element((0, y0, z0), (16, 16, z1), faces))
        lo = 2 if west_exposed else 0
        hi = 14 if east_exposed else 16
        if hi > lo:
            zi = 2 if side == "n" else 14
            els.append(element((lo, y0, zi), (hi, 16, zi),
                               {inner: tile_face(inner, lo, hi, y0, 16, top=top_line)}))
    else:
        n_open, s_open = a_open, b_open
        lo = 0 if n_open else 2
        hi = 16 if s_open else 14
        x0, x1 = (14, 16) if side == "e" else (0, 2)
        outer = "east" if side == "e" else "west"
        inner = "west" if side == "e" else "east"
        faces = {outer: tile_face(outer, lo, hi, y0, 16, top=top_line)}
        if top_line:
            faces["up"] = solid_face()
        els.append(element((x0, y0, lo), (x1, 16, hi), faces))
        xi = 14 if side == "e" else 2
        els.append(element((xi, y0, lo), (xi, 16, hi),
                           {inner: tile_face(inner, lo, hi, y0, 16, top=top_line)}))
    return els


# inner-corner pillar: (x0, x1, z0, z1, face a, face b)
POSTS = {
    "northeast": ((14, 16, 0, 2), ("west", "south")),
    "southeast": ((14, 16, 14, 16), ("west", "north")),
    "southwest": ((0, 2, 14, 16), ("east", "north")),
    "northwest": ((0, 2, 0, 2), ("east", "south")),
}


def post_elements(corner, up, down):
    (x0, x1, z0, z1), dirs = POSTS[corner]
    y0 = 0 if down else 2
    faces = {}
    for d in dirs:
        h0, h1 = (x0, x1) if d in ("north", "south") else (z0, z1)
        faces[d] = tile_face(d, h0, h1, y0, 16, top=not up)
    if not up:
        faces["up"] = solid_face()
    return [element((x0, y0, z0), (x1, 16, z1), faces)]


# ---------------------------------------------------------------------------------------------- output

TEXTURE_BLOCK = {
    "glass": "%s:block/glass_pot_ctm" % MODID,
    "edge": "%s:block/glass_pot_edge" % MODID,
    "particle": "#edge",
}


def write_model(name, elements, extra=None):
    model = dict(extra or {})
    model["textures"] = TEXTURE_BLOCK
    model["elements"] = elements
    model["render_type"] = "minecraft:cutout"
    with open(os.path.join(MODELS, name + ".json"), "w") as f:
        json.dump(model, f, indent=1)


def bits(*values):
    return "".join("1" if v else "0" for v in values)


def main():
    make_textures()
    # remove the previous glass pot models
    for fn in os.listdir(MODELS):
        if fn.startswith("glass_large_pot_") and fn.endswith(".json"):
            os.remove(os.path.join(MODELS, fn))

    parts = []

    def add(model, when):
        parts.append({"when": when, "apply": {"model": "%s:block/%s" % (MODID, model)}})

    def b(v):
        return "true" if v else "false"

    for n, e, s, w in itertools.product([False, True], repeat=4):
        name = "glass_large_pot_floor_" + bits(n, e, s, w)
        write_model(name, floor_elements(n, e, s, w))
        add(name, {"down": "false", "north": b(n), "east": b(e), "south": b(s), "west": b(w)})

    for up, down in itertools.product([False, True], repeat=2):
        for a, c in itertools.product([False, True], repeat=2):
            for side, props in (("n", ("west", "east", "north")), ("s", ("west", "east", "south")),
                                ("e", ("north", "south", "east")), ("w", ("north", "south", "west"))):
                name = "glass_large_pot_wall_%s_%s_%s" % (side, bits(a, c), bits(up, down))
                write_model(name, wall_elements(side, a, c, up, down))
                add(name, {props[0]: b(a), props[1]: b(c), props[2]: "false", "up": b(up), "down": b(down)})
        for corner, (p1, p2, diag) in (("northeast", ("north", "east", "northeast")),
                                       ("southeast", ("south", "east", "southeast")),
                                       ("southwest", ("south", "west", "southwest")),
                                       ("northwest", ("north", "west", "northwest"))):
            name = "glass_large_pot_post_%s_%s" % (corner, bits(up, down))
            write_model(name, post_elements(corner, up, down))
            add(name, {p1: "true", p2: "true", diag: "false", "up": b(up), "down": b(down)})

    with open(os.path.join(ASSETS, "blockstates/glass_large_pot.json"), "w") as f:
        json.dump({"multipart": parts}, f, indent=1)

    # item: a closed single pot
    els = floor_elements(False, False, False, False)
    for side in ("n", "e", "s", "w"):
        els += wall_elements(side, False, False, False, False)
    write_model("glass_large_pot_item", els, {"parent": "minecraft:block/block"})
    print("models:", len([f for f in os.listdir(MODELS) if f.startswith("glass_large_pot_")]),
          "multipart entries:", len(parts))


if __name__ == "__main__":
    main()
