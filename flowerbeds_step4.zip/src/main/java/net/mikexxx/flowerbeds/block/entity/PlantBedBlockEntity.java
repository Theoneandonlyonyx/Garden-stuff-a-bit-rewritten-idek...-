package net.mikexxx.flowerbeds.block.entity;

import net.mikexxx.flowerbeds.block.PlantBedBlock;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

/**
 * Stores the items of a bed. Only the bed that owns a slot stores its item, so a shared border slot
 * is never duplicated. Nothing here ticks, drops or grows by itself.
 */
public abstract class PlantBedBlockEntity extends BlockEntity {

    protected final NonNullList<ItemStack> slots = NonNullList.withSize(GardenLayout.SLOT_COUNT, ItemStack.EMPTY);
    /** Growth age per slot, used by plants with growth stages. */
    protected final int[] ages = new int[GardenLayout.SLOT_COUNT];
    /** Facing per slot, 0..3 quarter turns, used by scaled fruit. */
    protected final int[] rotations = new int[GardenLayout.SLOT_COUNT];
    /** How tall the draw box has to be so plants are not cut off. At least five blocks, more when grown. */
    private int renderSpan = 6;
    /** The blocks drawn for each slot, bottom to top. Built once per change instead of every frame. */
    private final List<List<BlockState>> columns = new ArrayList<>();

    protected PlantBedBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    /** Height of the planting surface within this block, in block units. */
    public abstract float bedHeight();

    /** The full block this bed looks like (bedding blocks), or null if the bed's own model is drawn. */
    public BlockState baseState() {
        return null;
    }

    /** The block drawn as the growing medium of this bed, or null if the bed draws none of its own. */
    public BlockState substrateState() {
        return null;
    }

    public ItemStack getSlot(int index) {
        return slots.get(index);
    }

    public int getAge(int index) {
        return ages[index];
    }

    public int getRotation(int index) {
        return rotations[index];
    }

    public void setSlot(int index, ItemStack stack, int age, int rotation) {
        if (stack.isEmpty()) {
            slots.set(index, ItemStack.EMPTY);
            ages[index] = 0;
            rotations[index] = 0;
        } else {
            slots.set(index, stack.copyWithCount(Math.min(stack.getCount(), PlantStates.maxAmount(stack))));
            ages[index] = age;
            rotations[index] = rotation & 3;
        }
        onSlotsChanged();
    }

    public boolean hasContents() {
        for (ItemStack stack : slots) {
            if (!stack.isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /** Light this bed gives off: the strongest light of anything stored in it. */
    public int lightLevel() {
        int light = 0;
        for (ItemStack stack : slots) {
            light = Math.max(light, GardenLayout.lightOf(stack));
        }
        return Math.min(15, light);
    }

    /** Subclasses extend this to keep their own block state flags in step with the contents. */
    protected void updateBlockState() {
        if (level == null) {
            return;
        }
        BlockState state = level.getBlockState(worldPosition);
        if (!(state.getBlock() instanceof PlantBedBlock)) {
            return;
        }
        int light = lightLevel();
        if (state.getValue(PlantBedBlock.LIGHT) != light) {
            level.setBlock(worldPosition, state.setValue(PlantBedBlock.LIGHT, light), Block.UPDATE_ALL);
        }
    }

    /** The blocks drawn for a slot, bottom to top, cached until the slots change. */
    public List<BlockState> getColumn(int index) {
        while (columns.size() < GardenLayout.SLOT_COUNT) {
            columns.add(null);
        }
        List<BlockState> column = columns.get(index);
        if (column == null) {
            ItemStack stack = slots.get(index);
            column = stack.isEmpty() ? List.of() : PlantStates.columnFor(stack, ages[index]);
            columns.set(index, column);
        }
        return column;
    }

    private void clearColumnCache() {
        columns.clear();
    }

    protected void onSlotsChanged() {
        clearColumnCache();
        updateBlockState();
        recomputeRenderSpan();
        setChanged();
        syncToClients();
    }

    protected void syncToClients() {
        if (level == null) {
            return;
        }
        BlockState state = level.getBlockState(worldPosition);
        level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
    }

    /**
     * Bone meal: every plant that would grow from bone meal in the world moves on exactly one stage.
     * A plant that does not accept bone meal does not grow here either. Stacking plants have no height cap
     * short of {@link PlantStates#MAX_HEIGHT}. Returns true if at least one plant grew.
     */
    public boolean canGrowAny() {
        for (int i = 0; i < GardenLayout.SLOT_COUNT; i++) {
            ItemStack stack = slots.get(i);
            if (stack.isEmpty()) {
                continue;
            }
            int maxAge = maxAgeOf(stack);
            if (maxAge >= 0 && ages[i] < maxAge) {
                return true;
            }
        }
        return false;
    }

    public boolean growPlants() {
        if (level != null && level.isClientSide) {
            return canGrowAny();
        }
        boolean grew = false;
        for (int i = 0; i < GardenLayout.SLOT_COUNT; i++) {
            ItemStack stack = slots.get(i);
            if (stack.isEmpty()) {
                continue;
            }
            int maxAge = maxAgeOf(stack);
            if (maxAge >= 0 && ages[i] < maxAge) {
                ages[i]++;
                grew = true;
            }
        }
        if (grew) {
            onSlotsChanged();
        }
        return grew;
    }

    /** The highest growth age bone meal can bring the stored plant to, or -1 if it does not grow. */
    protected int maxAgeOf(ItemStack stack) {
        if (stack.getItem() instanceof BlockItem blockItem) {
            return PlantStates.maxAge(blockItem.getBlock().defaultBlockState());
        }
        return -1;
    }

    /** Breaking the bed drops whatever it stores. */
    public void dropContents() {
        if (level == null || level.isClientSide) {
            return;
        }
        for (int i = 0; i < GardenLayout.SLOT_COUNT; i++) {
            ItemStack stack = slots.get(i);
            if (!stack.isEmpty()) {
                Block.popResource(level, worldPosition, stack);
                slots.set(i, ItemStack.EMPTY);
                ages[i] = 0;
                rotations[i] = 0;
            }
        }
    }

    /**
     * Called when a neighbouring bed appears or disappears. A border slot that this bed no longer owns
     * is handed to its new owner, or dropped if the owner's slot is occupied or the slot no longer exists.
     */
    public void reconcile() {
        if (level == null || level.isClientSide) {
            return;
        }
        boolean changed = false;
        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            ItemStack stack = slots.get(i);
            if (stack.isEmpty()) {
                continue;
            }
            GardenLayout.Owner owner = GardenLayout.resolve(level, worldPosition, i);
            if (owner.active() && owner.pos().equals(worldPosition)) {
                continue;
            }
            int age = ages[i];
            int rotation = rotations[i];
            slots.set(i, ItemStack.EMPTY);
            ages[i] = 0;
            rotations[i] = 0;
            changed = true;
            if (owner.active()
                    && level.getBlockEntity(owner.pos()) instanceof PlantBedBlockEntity other
                    && other.getSlot(owner.slot()).isEmpty()) {
                other.setSlot(owner.slot(), stack, age, rotation);
            } else {
                Block.popResource(level, worldPosition, stack);
            }
        }
        if (changed) {
            onSlotsChanged();
        }
    }

    /**
     * Plants reach past the edges of the block. The box is at least five blocks tall so a tall model is not
     * culled, and it grows with stacking plants. The client renderer widens it further to the real model.
     */
    @Override
    public AABB getRenderBoundingBox() {
        return new AABB(worldPosition.getX() - 2, worldPosition.getY(), worldPosition.getZ() - 2,
                worldPosition.getX() + 3, worldPosition.getY() + renderSpan, worldPosition.getZ() + 3);
    }

    /** Draw box height: the tallest plant in the bed plus a little headroom, never less than five blocks. */
    private void recomputeRenderSpan() {
        int span = 6;
        for (int i = 0; i < GardenLayout.SLOT_COUNT; i++) {
            if (slots.get(i).isEmpty()) {
                continue;
            }
            span = Math.max(span, getColumn(i).size() + 3);
        }
        this.renderSpan = span;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, slots);
        tag.putIntArray("Ages", ages);
        tag.putIntArray("Rot", rotations);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        // loadAllItems only fills the slots present in the tag, so empty the rest first. Otherwise a plant that
        // was taken out would stay on the client's copy of the bed.
        for (int i = 0; i < slots.size(); i++) {
            slots.set(i, ItemStack.EMPTY);
        }
        ContainerHelper.loadAllItems(tag, slots);
        int[] savedAges = tag.getIntArray("Ages");
        int[] savedRot = tag.getIntArray("Rot");
        for (int i = 0; i < ages.length; i++) {
            ages[i] = i < savedAges.length ? savedAges[i] : 0;
            rotations[i] = i < savedRot.length ? savedRot[i] : 0;
        }
        clearColumnCache();
        recomputeRenderSpan();
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
