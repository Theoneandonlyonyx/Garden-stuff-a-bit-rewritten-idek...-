package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.block.entity.PlantBedBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Large Pot: a hollow, closed-bottom container with walls two units thick, the same as a glass pane.
 * A side opens only toward a neighbouring pot of the same kind, so a 3x3 of same-coloured pots has no inner
 * walls. Next to any other block (including other coloured pots) the wall stays.
 */
public class LargePotBlock extends PlantBedBlock {

    public enum Liquid implements StringRepresentable {
        NONE("none"), WATER("water"), LAVA("lava"), MILK("milk");

        private final String serializedName;

        Liquid(String serializedName) {
            this.serializedName = serializedName;
        }

        @Override
        public String getSerializedName() {
            return serializedName;
        }
    }

    /** true = this side is open to a neighbour, so no wall is drawn. */
    public static final BooleanProperty NORTH = BlockStateProperties.NORTH;
    public static final BooleanProperty EAST = BlockStateProperties.EAST;
    public static final BooleanProperty SOUTH = BlockStateProperties.SOUTH;
    public static final BooleanProperty WEST = BlockStateProperties.WEST;
    /** true = the pot diagonally across that corner is a connected pot of the same kind. */
    public static final BooleanProperty NORTH_EAST = BooleanProperty.create("northeast");
    public static final BooleanProperty SOUTH_EAST = BooleanProperty.create("southeast");
    public static final BooleanProperty SOUTH_WEST = BooleanProperty.create("southwest");
    public static final BooleanProperty NORTH_WEST = BooleanProperty.create("northwest");
    /** true while the pot holds anything, which shows the soil surface. */
    public static final BooleanProperty SUBSTRATE = BooleanProperty.create("substrate");
    public static final EnumProperty<Liquid> LIQUID = EnumProperty.create("liquid", Liquid.class);

    /** Dye palette, indexed by DyeColor ordinal. Used to tint dyed water. */
    public static final int[] DYE_RGB = {
            0xF0F0F0, 0xF9801D, 0xC74EBD, 0x3AB3DA,
            0xFED83D, 0x80C71F, 0xF38BAA, 0x474F52,
            0x9D9D97, 0x169C9C, 0x8932B8, 0x3C44AA,
            0x835432, 0x5E7C16, 0xB02E26, 0x1D1D21
    };

    private static final VoxelShape FLOOR = Block.box(0, 0, 0, 16, 2, 16);
    /** Each wall runs between the corner posts and is left out on a side that opens to a connected pot. */
    private static final VoxelShape NORTH_WALL = Block.box(2, 2, 0, 14, 16, 2);
    private static final VoxelShape EAST_WALL = Block.box(14, 2, 2, 16, 16, 14);
    private static final VoxelShape SOUTH_WALL = Block.box(2, 2, 14, 14, 16, 16);
    private static final VoxelShape WEST_WALL = Block.box(0, 2, 2, 2, 16, 14);
    private static final VoxelShape POST_NE = Block.box(14, 2, 0, 16, 16, 2);
    private static final VoxelShape POST_SE = Block.box(14, 2, 14, 16, 16, 16);
    private static final VoxelShape POST_SW = Block.box(0, 2, 14, 2, 16, 16);
    private static final VoxelShape POST_NW = Block.box(0, 2, 0, 2, 16, 2);
    /** Bits: 1 N, 2 E, 4 S, 8 W (side open), 16 NE, 32 SE, 64 SW, 128 NW (diagonal pot connected). */
    private static final VoxelShape[] SHAPES = new VoxelShape[256];

    static {
        for (int mask = 0; mask < 256; mask++) {
            boolean n = (mask & 1) != 0;
            boolean e = (mask & 2) != 0;
            boolean s = (mask & 4) != 0;
            boolean w = (mask & 8) != 0;
            VoxelShape shape = FLOOR;
            if (!n) shape = Shapes.or(shape, NORTH_WALL);
            if (!e) shape = Shapes.or(shape, EAST_WALL);
            if (!s) shape = Shapes.or(shape, SOUTH_WALL);
            if (!w) shape = Shapes.or(shape, WEST_WALL);
            // A corner gets a post unless the pot is surrounded there: both sides open and the pot across the
            // corner connected too. That leaves a straight wall straight, an inner corner an L, and no pillar
            // in the middle of a big bed.
            if (!(n && e && (mask & 16) != 0)) shape = Shapes.or(shape, POST_NE);
            if (!(s && e && (mask & 32) != 0)) shape = Shapes.or(shape, POST_SE);
            if (!(s && w && (mask & 64) != 0)) shape = Shapes.or(shape, POST_SW);
            if (!(n && w && (mask & 128) != 0)) shape = Shapes.or(shape, POST_NW);
            SHAPES[mask] = shape.optimize();
        }
    }

    public LargePotBlock(BlockBehaviour.Properties properties) {
        super(properties.noOcclusion().lightLevel(state ->
                Math.max(state.getValue(LIGHT), state.getValue(LIQUID) == Liquid.LAVA ? 15 : 0)));
        registerDefaultState(this.stateDefinition.any()
                .setValue(NORTH, false)
                .setValue(EAST, false)
                .setValue(SOUTH, false)
                .setValue(WEST, false)
                .setValue(NORTH_EAST, false)
                .setValue(SOUTH_EAST, false)
                .setValue(SOUTH_WEST, false)
                .setValue(NORTH_WEST, false)
                .setValue(SUBSTRATE, false)
                .setValue(LIQUID, Liquid.NONE)
                .setValue(LIGHT, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(NORTH, EAST, SOUTH, WEST, NORTH_EAST, SOUTH_EAST, SOUTH_WEST, NORTH_WEST, SUBSTRATE, LIQUID);
    }

    /**
     * A side is open only toward another pot of exactly the same kind (same colour). Any other block,
     * including other pots, plantable blocks and solid blocks, leaves the wall in place.
     */
    private boolean connects(BlockState neighbor) {
        return neighbor.is(this);
    }

    private static BooleanProperty propertyFor(Direction direction) {
        if (direction == Direction.NORTH) return NORTH;
        if (direction == Direction.EAST) return EAST;
        if (direction == Direction.SOUTH) return SOUTH;
        return WEST;
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockPos pos = context.getClickedPos();
        BlockGetter level = context.getLevel();
        return this.defaultBlockState()
                .setValue(NORTH, connects(level.getBlockState(pos.north())))
                .setValue(EAST, connects(level.getBlockState(pos.east())))
                .setValue(SOUTH, connects(level.getBlockState(pos.south())))
                .setValue(WEST, connects(level.getBlockState(pos.west())))
                .setValue(NORTH_EAST, connects(level.getBlockState(pos.north().east())))
                .setValue(SOUTH_EAST, connects(level.getBlockState(pos.south().east())))
                .setValue(SOUTH_WEST, connects(level.getBlockState(pos.south().west())))
                .setValue(NORTH_WEST, connects(level.getBlockState(pos.north().west())));
    }

    /** Diagonal neighbours do not send shape updates, so a pot tells the ring around it when it appears or goes. */
    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);
        if (!level.isClientSide && !state.is(oldState.getBlock())) {
            refreshAround(level, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        super.onRemove(state, level, pos, newState, isMoving);
        if (!level.isClientSide && !state.is(newState.getBlock())) {
            refreshAround(level, pos);
        }
    }

    private static void refreshAround(Level level, BlockPos pos) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                refresh(level, pos.offset(dx, 0, dz));
            }
        }
    }

    private static void refresh(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (!(state.getBlock() instanceof LargePotBlock pot)) {
            return;
        }
        BlockState next = state
                .setValue(NORTH, pot.connects(level.getBlockState(pos.north())))
                .setValue(EAST, pot.connects(level.getBlockState(pos.east())))
                .setValue(SOUTH, pot.connects(level.getBlockState(pos.south())))
                .setValue(WEST, pot.connects(level.getBlockState(pos.west())))
                .setValue(NORTH_EAST, pot.connects(level.getBlockState(pos.north().east())))
                .setValue(SOUTH_EAST, pot.connects(level.getBlockState(pos.south().east())))
                .setValue(SOUTH_WEST, pot.connects(level.getBlockState(pos.south().west())))
                .setValue(NORTH_WEST, pot.connects(level.getBlockState(pos.north().west())));
        if (next != state) {
            level.setBlock(pos, next, Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                  LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (direction.getAxis().isHorizontal()) {
            return state.setValue(propertyFor(direction), connects(neighborState));
        }
        return state;
    }

    private static int maskOf(BlockState state) {
        int mask = 0;
        if (state.getValue(NORTH)) mask |= 1;
        if (state.getValue(EAST)) mask |= 2;
        if (state.getValue(SOUTH)) mask |= 4;
        if (state.getValue(WEST)) mask |= 8;
        if (state.getValue(NORTH_EAST)) mask |= 16;
        if (state.getValue(SOUTH_EAST)) mask |= 32;
        if (state.getValue(SOUTH_WEST)) mask |= 64;
        if (state.getValue(NORTH_WEST)) mask |= 128;
        return mask;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPES[maskOf(state)];
    }

    /** A pot filled with substrate is solid on top, so you can stand on it. A liquid pot stays open. */
    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        if (state.getValue(SUBSTRATE) && state.getValue(LIQUID) == Liquid.NONE) {
            return Shapes.block();
        }
        return SHAPES[maskOf(state)];
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new LargePotBlockEntity(pos, state);
    }

    @Override
    protected boolean canOpenMenu(BlockState state, Level level, BlockPos pos) {
        return state.getValue(LIQUID) != Liquid.NONE
                || (level.getBlockEntity(pos) instanceof LargePotBlockEntity pot && pot.getSubstrate() != null);
    }

    private static Liquid liquidOf(ItemStack held) {
        if (held.is(Items.WATER_BUCKET)) return Liquid.WATER;
        if (held.is(Items.LAVA_BUCKET)) return Liquid.LAVA;
        if (held.is(Items.MILK_BUCKET)) return Liquid.MILK;
        return null;
    }

    /** Hands an item to the player: into the emptied hand slot if there is one, else into the inventory. */
    private static void give(Player player, InteractionHand hand, ItemStack stack) {
        if (stack.isEmpty()) {
            return;
        }
        if (player.getItemInHand(hand).isEmpty()) {
            player.setItemInHand(hand, stack);
        } else if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }

    @Override
    protected InteractionResult extraUse(BlockState state, Level level, BlockPos pos, Player player,
                                         InteractionHand hand, ItemStack held) {
        if (!(level.getBlockEntity(pos) instanceof LargePotBlockEntity pot)) {
            return InteractionResult.PASS;
        }
        Liquid liquid = state.getValue(LIQUID);
        boolean creative = player.getAbilities().instabuild;

        // Sneaking with an empty hand scoops the substrate out again (plants in it are dropped).
        if (held.isEmpty() && player.isShiftKeyDown() && hand == InteractionHand.MAIN_HAND
                && pot.getSubstrate() != null) {
            if (!level.isClientSide) {
                pot.dropContents();
                pot.setSubstrate(null);
            }
            return InteractionResult.SUCCESS;
        }

        // Fill with whatever is in the hand: a liquid bucket or a substrate block. It replaces the old
        // contents, and the old contents come back to the player as an item.
        Liquid incomingLiquid = liquidOf(held);
        boolean incomingIsSubstrate = incomingLiquid == null && GardenLayout.isSubstrate(held, level, pos);
        if (incomingLiquid != null || incomingIsSubstrate) {
            if (level.isClientSide) {
                return InteractionResult.SUCCESS;
            }
            Block incomingBlock = incomingIsSubstrate ? ((BlockItem) held.getItem()).getBlock() : null;
            if (incomingLiquid != null && liquid == incomingLiquid) {
                return InteractionResult.SUCCESS;
            }
            if (incomingBlock != null && pot.getSubstrate() == incomingBlock) {
                return InteractionResult.SUCCESS;
            }
            ItemStack old = pot.removeFill();
            if (incomingLiquid != null) {
                pot.setLiquid(incomingLiquid);
            } else {
                pot.setSubstrate(incomingBlock);
            }
            SoundEvent sound = incomingLiquid == Liquid.LAVA ? SoundEvents.BUCKET_EMPTY_LAVA
                    : incomingLiquid != null ? SoundEvents.BUCKET_EMPTY
                    : incomingBlock.defaultBlockState().getSoundType().getPlaceSound();
            level.playSound(null, pos, sound, SoundSource.BLOCKS, 1.0F, 1.0F);
            if (!creative) {
                boolean oldIsBucket = old.is(Items.WATER_BUCKET) || old.is(Items.LAVA_BUCKET) || old.is(Items.MILK_BUCKET);
                held.shrink(1);
                if (incomingLiquid != null && !oldIsBucket) {
                    give(player, hand, new ItemStack(Items.BUCKET));
                }
                give(player, hand, old);
            }
            return InteractionResult.SUCCESS;
        }

        // An empty bucket removes the liquid and gives back the matching bucket.
        if (held.is(Items.BUCKET)) {
            if (liquid == Liquid.NONE) {
                return InteractionResult.SUCCESS;
            }
            if (!level.isClientSide) {
                ItemStack filled = pot.removeFill();
                SoundEvent sound = liquid == Liquid.LAVA ? SoundEvents.BUCKET_FILL_LAVA : SoundEvents.BUCKET_FILL;
                pot.setLiquid(Liquid.NONE);
                player.setItemInHand(hand, ItemUtils.createFilledResult(held, player, filled));
                level.playSound(null, pos, sound, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.SUCCESS;
        }

        // Dye tints water, the same way it tints water in a cauldron.
        if (held.getItem() instanceof DyeItem dye) {
            if (liquid != Liquid.WATER) {
                return InteractionResult.PASS;
            }
            if (!level.isClientSide) {
                pot.setDyeColor(DYE_RGB[dye.getDyeColor().ordinal()]);
                if (!creative) {
                    held.shrink(1);
                }
            }
            return InteractionResult.SUCCESS;
        }

        // With soil or water in the pot, a plant or groundcover can be tossed in. The trowel is what
        // places them precisely; this just fills the next open spot.
        if (held.getItem() instanceof BlockItem && !GardenLayout.isSubstrate(held, level, pos)) {
            boolean filled = liquid != Liquid.NONE || pot.getSubstrate() != null;
            if (!filled) {
                if (!level.isClientSide) {
                    player.displayClientMessage(Component.translatable(
                            "message.mikexxx_flowerbeds.needs_substrate"), true);
                }
                return InteractionResult.SUCCESS;
            }
            InteractionResult placed = tossIn(level, pos, player, hand, held, pot, creative);
            if (placed != InteractionResult.PASS) {
                return placed;
            }
        }

        return InteractionResult.PASS;
    }

    /** Groundcover stacks into its own spot. Anything else takes the first open place of the 3x3. */
    private static InteractionResult tossIn(Level level, BlockPos pos, Player player, InteractionHand hand,
                                            ItemStack held, LargePotBlockEntity pot, boolean creative) {
        if (PlantStates.isGroundcover(held)) {
            ItemStack present = pot.getSlot(GardenLayout.GROUNDCOVER_SLOT);
            int max = PlantStates.maxAmount(held);
            if (present.isEmpty()) {
                if (!level.isClientSide) {
                    pot.setSlot(GardenLayout.GROUNDCOVER_SLOT, held.copyWithCount(1), 0,
                            player.getDirection().get2DDataValue());
                    finishToss(level, pos, player, hand, held, creative);
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
            if (ItemStack.isSameItemSameTags(present, held) && present.getCount() < max) {
                if (!level.isClientSide) {
                    ItemStack grown = present.copy();
                    grown.grow(1);
                    pot.setSlot(GardenLayout.GROUNDCOVER_SLOT, grown, pot.getAge(GardenLayout.GROUNDCOVER_SLOT),
                            pot.getRotation(GardenLayout.GROUNDCOVER_SLOT));
                    finishToss(level, pos, player, hand, held, creative);
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
            return InteractionResult.PASS;
        }
        int max = PlantStates.maxAmount(held);
        PlantBedBlockEntity stackBed = null;
        int stackSlot = -1;
        PlantBedBlockEntity emptyBed = null;
        int emptySlot = -1;
        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            GardenLayout.Owner owner = GardenLayout.resolve(level, pos, i);
            if (!owner.active() || !(level.getBlockEntity(owner.pos()) instanceof PlantBedBlockEntity ownerBed)) {
                continue;
            }
            ItemStack present = ownerBed.getSlot(owner.slot());
            if (present.isEmpty()) {
                if (emptyBed == null) {
                    emptyBed = ownerBed;
                    emptySlot = owner.slot();
                }
            } else if (stackBed == null && ItemStack.isSameItemSameTags(present, held) && present.getCount() < max) {
                stackBed = ownerBed;
                stackSlot = owner.slot();
            }
        }
        if (stackBed == null && emptyBed == null) {
            return InteractionResult.PASS;
        }
        if (!level.isClientSide) {
            if (stackBed != null) {
                ItemStack present = stackBed.getSlot(stackSlot);
                ItemStack grown = present.copy();
                grown.grow(1);
                stackBed.setSlot(stackSlot, grown, stackBed.getAge(stackSlot), stackBed.getRotation(stackSlot));
            } else {
                emptyBed.setSlot(emptySlot, held.copyWithCount(1), 0, player.getDirection().get2DDataValue());
            }
            finishToss(level, pos, player, hand, held, creative);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    private static void finishToss(Level level, BlockPos pos, Player player, InteractionHand hand,
                                   ItemStack held, boolean creative) {
        level.playSound(null, pos, SoundEvents.GRASS_PLACE, SoundSource.BLOCKS, 0.8F, 1.0F);
        if (!creative) {
            held.shrink(1);
        }
    }
}
