package net.mikexxx.flowerbeds.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.WindowBoxBlock;
import net.mikexxx.flowerbeds.block.entity.WindowBoxBlockEntity;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.client.RenderTypeHelper;
import net.minecraftforge.client.model.data.ModelData;

import java.util.List;

/**
 * Draws the five places of a window box. Slots 0-2 are the classic three, evenly spaced; slots 3 and 4 sit in the
 * gaps beside the middle one, a little smaller and nudged forward and back so the box looks full without the
 * plants lying on top of each other. Vines are not drawn as blocks: they hang down over both long sides in a
 * tapering, roughly triangular drape.
 */
public class WindowBoxRenderer implements BlockEntityRenderer<WindowBoxBlockEntity> {

    /** Position along the box (0..1) of each slot. */
    private static final float[] ALONG = {0.20F, 0.50F, 0.80F, 0.35F, 0.65F};
    /** Plant scale per slot. The classic three keep the original size; the gap plants are a tad smaller. */
    private static final float[] SCALE = {0.50F, 0.50F, 0.50F, 0.45F, 0.45F};
    /** Sideways nudge per slot, toward the back of the box (+, against the wall) or the front (-). */
    private static final float[] NUDGE = {0.0F, 0.0F, 0.0F, 0.075F, 0.075F};
    /** A little turn per slot so neighbouring plants do not look stamped from one mould. */
    private static final float[] YAW = {0.0F, 12.0F, -9.0F, 24.0F, -20.0F};
    private static final ResourceLocation VINE = new ResourceLocation("minecraft", "block/vine");

    public WindowBoxRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(WindowBoxBlockEntity box, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffers, int packedLight, int packedOverlay) {
        Level level = box.getLevel();
        BlockState hostState = box.getBlockState();
        if (level == null || !(hostState.getBlock() instanceof WindowBoxBlock)) {
            return;
        }
        BlockPos pos = box.getBlockPos();
        Direction facing = hostState.getValue(WindowBoxBlock.FACING);
        boolean alongX = facing.getAxis() == Direction.Axis.Z;
        boolean outwardIsPositive = facing == Direction.SOUTH || facing == Direction.EAST;
        float across = outwardIsPositive ? 0.81F : 0.19F;
        float baseY = box.bedHeight();
        int light = LevelRenderer.getLightColor(level, pos.above());

        BlockState substrate = box.substrateState();
        if (substrate != null) {
            float a0 = outwardIsPositive ? 11.0F / 16.0F : 1.0F / 16.0F;
            float a1 = a0 + 4.0F / 16.0F;
            float x0 = alongX ? 1.0F / 16.0F : a0;
            float x1 = alongX ? 15.0F / 16.0F : a1;
            float z0 = alongX ? a0 : 1.0F / 16.0F;
            float z1 = alongX ? a1 : 15.0F / 16.0F;
            renderSubstrate(substrate, level, pos, poseStack, buffers, x0, z0, x1, z1, 5.0F / 16.0F + 0.002F,
                    light, packedOverlay);
        }

        if (box.getLiquid() != LargePotBlock.Liquid.NONE) {
            float a0 = outwardIsPositive ? 11.0F / 16.0F : 1.0F / 16.0F;
            float a1 = a0 + 4.0F / 16.0F;
            renderLiquid(box.getLiquid(), level, pos, poseStack, buffers,
                    alongX ? 1.0F / 16.0F : a0, alongX ? a0 : 1.0F / 16.0F,
                    alongX ? 15.0F / 16.0F : a1, alongX ? a1 : 15.0F / 16.0F, light, packedOverlay);
        }

        int vines = 0;
        int vineAge = 0;
        for (int i = 0; i < WindowBoxBlockEntity.SLOTS; i++) {
            ItemStack stack = box.getSlot(i);
            if (stack.isEmpty()) {
                continue;
            }
            BlockState plant = PlantStates.stateFor(stack, box.getAge(i));
            if (WindowBoxBlock.isTrailing(plant)) {
                vines++;
                vineAge = Math.max(vineAge, box.getAge(i));
                continue;
            }
            List<BlockState> column = box.getColumn(i);
            float nudge = outwardIsPositive ? NUDGE[i] : -NUDGE[i];
            float cx = alongX ? ALONG[i] : across + nudge;
            float cz = alongX ? across + nudge : ALONG[i];
            float scale = SCALE[i];
            for (int k = 0; k < column.size(); k++) {
                poseStack.pushPose();
                poseStack.translate(cx, baseY, cz);
                poseStack.mulPose(Axis.YP.rotationDegrees(YAW[i]));
                poseStack.scale(scale, scale, scale);
                poseStack.translate(-0.5, k, -0.5);
                renderState(column.get(k), level, pos, poseStack, buffers, light, packedOverlay);
                poseStack.popPose();
            }
        }
        if (vines > 0) {
            renderTrail(vines, vineAge, level, pos, poseStack, buffers, alongX, light, packedOverlay);
        }
    }


    /**
     * One vine drape for the whole box, like trailing plants on a real window box: it starts as wide as the box
     * along the top of both long sides and tapers to a point in the middle. More vines in the box make it
     * longer and add shorter, narrower layers in front for a fuller look, and every bone meal makes it hang
     * longer. Drawn with the vine texture, tinted with the biome foliage colour (plain green as the fallback).
     */
    private void renderTrail(int vines, int age, Level level, BlockPos pos, PoseStack poseStack,
                             MultiBufferSource buffers, boolean alongX, int light, int overlay) {
        TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(VINE);
        int rgb = PlantTint.color(Blocks.VINE.defaultBlockState(), level, pos, 0);
        float r = (rgb >> 16 & 255) / 255.0F * 0.85F;
        float g = (rgb >> 8 & 255) / 255.0F * 0.85F;
        float b = (rgb & 255) / 255.0F * 0.85F;
        VertexConsumer consumer = buffers.getBuffer(RenderType.cutout());
        PoseStack.Pose pose = poseStack.last();
        BlockState host = level.getBlockState(pos);
        boolean outwardIsPositive = host.getValue(WindowBoxBlock.FACING) == Direction.SOUTH
                || host.getValue(WindowBoxBlock.FACING) == Direction.EAST;

        float baseLength = (0.7F + 0.12F * (vines - 1)) * (0.6F + 0.4F * age / WindowBoxBlockEntity.MAX_TRAIL_AGE);
        int layers = Math.min(3, vines);
        float inner = outwardIsPositive ? 10.0F / 16.0F : 0.0F;
        float nx = alongX ? 0.0F : 1.0F;
        float nz = alongX ? 1.0F : 0.0F;
        float top = 6.0F / 16.0F - 0.01F;
        for (int layer = 0; layer < layers; layer++) {
            float length = baseLength * (1.0F - 0.2F * layer);
            float halfTop = 0.46F - 0.06F * layer;
            int rows = Math.max(3, Math.round(length * 16.0F));
            float rowHeight = length / rows;
            float push = 0.008F + layer * 0.004F;
            float[] planes = {inner - push, inner + 6.0F / 16.0F + push};
            for (float plane : planes) {
                for (int row = 0; row < rows; row++) {
                    // Tapers to a point; a slight wobble keeps the edge from looking ruled with a straight edge.
                    float taper = 1.0F - (row + 0.5F) / rows;
                    float wobble = 1.0F + 0.08F * (float) Math.sin(row * 1.7F + layer * 2.0F);
                    float halfWidth = Math.max(0.02F, halfTop * taper * wobble);
                    float yTop = top - row * rowHeight;
                    float yBottom = yTop - rowHeight;
                    float a0 = 0.5F - halfWidth;
                    float a1 = 0.5F + halfWidth;
                    float u0 = sprite.getU(a0 * 16.0F);
                    float u1 = sprite.getU(a1 * 16.0F);
                    float vTopPx = (row * rowHeight % 1.0F) * 16.0F;
                    float v0 = sprite.getV(vTopPx);
                    float v1 = sprite.getV(Math.min(16.0F, vTopPx + rowHeight * 16.0F));
                    if (alongX) {
                        vertex(consumer, pose, a0, yTop, plane, r, g, b, u0, v0, overlay, light, nx, nz);
                        vertex(consumer, pose, a0, yBottom, plane, r, g, b, u0, v1, overlay, light, nx, nz);
                        vertex(consumer, pose, a1, yBottom, plane, r, g, b, u1, v1, overlay, light, nx, nz);
                        vertex(consumer, pose, a1, yTop, plane, r, g, b, u1, v0, overlay, light, nx, nz);
                        vertex(consumer, pose, a1, yTop, plane, r, g, b, u1, v0, overlay, light, -nx, -nz);
                        vertex(consumer, pose, a1, yBottom, plane, r, g, b, u1, v1, overlay, light, -nx, -nz);
                        vertex(consumer, pose, a0, yBottom, plane, r, g, b, u0, v1, overlay, light, -nx, -nz);
                        vertex(consumer, pose, a0, yTop, plane, r, g, b, u0, v0, overlay, light, -nx, -nz);
                    } else {
                        vertex(consumer, pose, plane, yTop, a0, r, g, b, u0, v0, overlay, light, nx, nz);
                        vertex(consumer, pose, plane, yBottom, a0, r, g, b, u0, v1, overlay, light, nx, nz);
                        vertex(consumer, pose, plane, yBottom, a1, r, g, b, u1, v1, overlay, light, nx, nz);
                        vertex(consumer, pose, plane, yTop, a1, r, g, b, u1, v0, overlay, light, nx, nz);
                        vertex(consumer, pose, plane, yTop, a1, r, g, b, u1, v0, overlay, light, -nx, -nz);
                        vertex(consumer, pose, plane, yBottom, a1, r, g, b, u1, v1, overlay, light, -nx, -nz);
                        vertex(consumer, pose, plane, yBottom, a0, r, g, b, u0, v1, overlay, light, -nx, -nz);
                        vertex(consumer, pose, plane, yTop, a0, r, g, b, u0, v0, overlay, light, -nx, -nz);
                    }
                }
            }
        }
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, float x, float y, float z,
                               float r, float g, float b, float u, float v, int overlay, int light,
                               float nx, float nz) {
        consumer.vertex(pose.pose(), x, y, z).color(r, g, b, 1.0F).uv(u, v).overlayCoords(overlay)
                .uv2(light).normal(pose.normal(), nx, 0.0F, nz).endVertex();
    }

    /** Biome-tinted block drawing, same as the other beds. */
    private void renderState(BlockState state, Level level, BlockPos tintPos, PoseStack poseStack,
                             MultiBufferSource buffers, int light, int overlay) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        if (state.getRenderShape() != RenderShape.MODEL) {
            dispatcher.renderSingleBlock(state, poseStack, buffers, light, overlay);
            return;
        }
        BakedModel model = dispatcher.getBlockModel(state);
        int rgb = PlantTint.color(state, level, tintPos, 0);
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        for (RenderType renderType : model.getRenderTypes(state, RandomSource.create(42L), ModelData.EMPTY)) {
            dispatcher.getModelRenderer().renderModel(poseStack.last(),
                    buffers.getBuffer(renderType),
                    state, model, r, g, b, light, overlay, ModelData.EMPTY, renderType);
        }
    }

    /** Water (biome tinted), milk (untinted water texture) or lava, as a flat surface a little below the rim of the soil level. */
    private void renderLiquid(LargePotBlock.Liquid liquid, Level level, BlockPos pos, PoseStack poseStack,
                              MultiBufferSource buffers, float x0, float z0, float x1, float z1,
                              int light, int overlay) {
        boolean lava = liquid == LargePotBlock.Liquid.LAVA;
        TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS)
                .apply(new ResourceLocation("minecraft", lava ? "block/lava_still" : "block/water_still"));
        int rgb = liquid == LargePotBlock.Liquid.WATER
                ? PlantTint.color(Blocks.WATER.defaultBlockState(), level, pos, 0) : 0xFFFFFF;
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        float alpha = lava ? 1.0F : 0.85F;
        int lit = lava ? LightTexture.FULL_BRIGHT : light;
        VertexConsumer consumer = buffers.getBuffer(RenderType.translucent());
        PoseStack.Pose pose = poseStack.last();
        float y = 4.5F / 16.0F;
        float u0 = sprite.getU(x0 * 16.0F);
        float u1 = sprite.getU(x1 * 16.0F);
        float v0 = sprite.getV(z0 * 16.0F);
        float v1 = sprite.getV(z1 * 16.0F);
        liquidVertex(consumer, pose, x0, y, z0, r, g, b, alpha, u0, v0, overlay, lit);
        liquidVertex(consumer, pose, x0, y, z1, r, g, b, alpha, u0, v1, overlay, lit);
        liquidVertex(consumer, pose, x1, y, z1, r, g, b, alpha, u1, v1, overlay, lit);
        liquidVertex(consumer, pose, x1, y, z0, r, g, b, alpha, u1, v0, overlay, lit);
    }

    private static void liquidVertex(VertexConsumer consumer, PoseStack.Pose pose, float x, float y, float z,
                                     float r, float g, float b, float a, float u, float v, int overlay, int light) {
        consumer.vertex(pose.pose(), x, y, z).color(r, g, b, a).uv(u, v).overlayCoords(overlay)
                .uv2(light).normal(pose.normal(), 0.0F, 1.0F, 0.0F).endVertex();
    }

    /** The top face of the custom substrate, laid over the box's own soil. */
    private void renderSubstrate(BlockState substrate, Level level, BlockPos pos, PoseStack poseStack,
                                 MultiBufferSource buffers, float x0, float z0, float x1, float z1, float y,
                                 int light, int overlay) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        BakedModel model = dispatcher.getBlockModel(substrate);
        List<BakedQuad> quads = model.getQuads(substrate, Direction.UP, RandomSource.create(42L), ModelData.EMPTY, null);
        TextureAtlasSprite sprite;
        int tint = -1;
        if (quads.isEmpty()) {
            sprite = model.getParticleIcon(ModelData.EMPTY);
        } else {
            sprite = quads.get(0).getSprite();
            tint = quads.get(0).getTintIndex();
        }
        int rgb = PlantTint.color(substrate, level, pos, tint);
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        VertexConsumer consumer = buffers.getBuffer(RenderType.cutout());
        PoseStack.Pose pose = poseStack.last();
        float u0 = sprite.getU(x0 * 16.0F);
        float u1 = sprite.getU(x1 * 16.0F);
        float v0 = sprite.getV(z0 * 16.0F);
        float v1 = sprite.getV(z1 * 16.0F);
        vertex(consumer, pose, x0, y, z0, r, g, b, u0, v0, overlay, light, 0.0F, 0.0F, 1.0F);
        vertex(consumer, pose, x0, y, z1, r, g, b, u0, v1, overlay, light, 0.0F, 0.0F, 1.0F);
        vertex(consumer, pose, x1, y, z1, r, g, b, u1, v1, overlay, light, 0.0F, 0.0F, 1.0F);
        vertex(consumer, pose, x1, y, z0, r, g, b, u1, v0, overlay, light, 0.0F, 0.0F, 1.0F);
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, float x, float y, float z,
                               float r, float g, float b, float u, float v, int overlay, int light,
                               float nx, float ny, float nz) {
        consumer.vertex(pose.pose(), x, y, z).color(r, g, b, 1.0F).uv(u, v).overlayCoords(overlay)
                .uv2(light).normal(pose.normal(), nx, ny, nz).endVertex();
    }
}
