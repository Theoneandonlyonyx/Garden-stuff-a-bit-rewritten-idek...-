# Credits

The soil texture (garden_dirt.png), the Large Pot wall textures (large_pot_*.png) and the
Arrange Plants GUI panel and slot tile (plant_bed.png, adapted from garden_layout.png) are taken from
**Garden Collection** by jaquadro, version 1.0.0 for Minecraft 1.20.1, which is released under the
MIT License.

The Garden Trowel texture (garden_trowel.png) is taken from the Garden Core part of **Garden Stuff / Garden Containers 1.7.10-1.7.0**
by jaquadro (the 1.7.10 original of this mod family).

Garden Collection's code is not used in this mod. Everything in src/ was written for this mod.
The Light Gray Large Pot uses large_pot_silver.png, because the jar has no separate light-gray texture.

MIT License, as stated in Garden Collection's mods.toml (license = "MIT"). The full license text is
published with the Garden Collection project at its original source; it is reproduced in part here
to meet the notice requirement of the MIT License:

    Copyright (c) jaquadro

    Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
    associated documentation files (the "Software"), to deal in the Software without restriction,
    including without limitation the rights to use, copy, modify, merge, publish, distribute,
    sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions: The above copyright notice and this
    permission notice shall be included in all copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
