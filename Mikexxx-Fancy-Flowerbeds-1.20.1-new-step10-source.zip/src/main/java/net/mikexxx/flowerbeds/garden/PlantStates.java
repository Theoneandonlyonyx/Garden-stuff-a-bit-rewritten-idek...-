package net.mikexxx.flowerbeds.garden;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.BambooStalkBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CactusBlock;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.SugarCaneBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BambooLeaves;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.ArrayList;
import java.util.List;

/** Turns a stored item into the block state(s) that are drawn and grown. */
public final class PlantStates {
    private PlantStates() {}

    /** Tallest a plant can grow in a bed, in blocks. */
    public static final int MAX_HEIGHT = 16;

    /**
     * Blocks that grow by stacking copies of themselves upward, one block per bone meal, like sugar cane.
     * Bamboo, sugar cane and cactus are built in; add modded plants of that kind to this tag.
     */
    public static final TagKey<Block> STACKED_PLANTS =
            TagKey.create(Registries.BLOCK, new ResourceLocation(PmpMikexxx.MODID, "stacked_plants"));

    /** Growth-stage property names, in priority order. */
    private static final String[] GROWTH_NAMES = {"age", "stage", "growth", "growth_stage"};

    /** The growth-stage property of a block state, or null if it has none. */
    public static IntegerProperty growthProperty(BlockState state) {
        for (String name : GROWTH_NAMES) {
            for (Property<?> property : state.getProperties()) {
                if (property instanceof IntegerProperty ip && property.getName().equals(name)) {
                    return ip;
                }
            }
        }
        return null;
    }

    public static int maxOf(IntegerProperty property) {
        return property.getPossibleValues().stream().max(Integer::compare).orElse(0);
    }

    public static int minOf(IntegerProperty property) {
        return property.getPossibleValues().stream().min(Integer::compare).orElse(0);
    }

    /**
     * The "how many" property of a block that stacks several of itself into one block: pink petals and
     * wildflowers (flower_amount), leaf litter (segment_amount), candles, sea pickles, turtle eggs, and any
     * modded block with an integer property named like "..._amount". Null if the block does not stack.
     */
    public static IntegerProperty amountProperty(BlockState state) {
        for (Property<?> property : state.getProperties()) {
            if (property instanceof IntegerProperty ip) {
                String name = property.getName();
                if (name.contains("amount") || name.equals("candles") || name.equals("pickles") || name.equals("eggs")) {
                    return ip;
                }
            }
        }
        return null;
    }

    /** How many of this item fit in one bed slot: the block's own maximum amount (4 for petals), or 1. */
    public static int maxAmount(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return 1;
        }
        IntegerProperty amount = amountProperty(blockItem.getBlock().defaultBlockState());
        if (amount == null) {
            return 1;
        }
        return Math.max(1, Math.min(maxOf(amount), stack.getMaxStackSize()));
    }

    /** Whether the item is a flat cover (petals, leaf litter, carpets) that belongs in the groundcover slot. */
    public static boolean isGroundcover(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        BlockState state = blockItem.getBlock().defaultBlockState();
        IntegerProperty amount = amountProperty(state);
        return state.getBlock() instanceof CarpetBlock || (amount != null && amount.getName().endsWith("_amount"));
    }

    /** Whether the plant grows taller (a column of blocks) instead of through growth stages. */
    public static boolean isVerticalGrower(BlockState state) {
        Block block = state.getBlock();
        return block instanceof BambooStalkBlock || block instanceof SugarCaneBlock
                || block instanceof CactusBlock || state.is(STACKED_PLANTS);
    }

    /** The highest growth age bone meal can bring a plant to, or -1 if the plant does not grow. */
    public static int maxAge(BlockState state) {
        if (isVerticalGrower(state)) {
            return MAX_HEIGHT - 1;
        }
        IntegerProperty growth = growthProperty(state);
        return growth == null ? -1 : maxOf(growth);
    }

    /** Block state drawn for a stored item at a given growth age. The stack size sets the amount (petals, candles). Candles are drawn lit. */
    public static BlockState stateFor(ItemStack stack, int age) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return Blocks.AIR.defaultBlockState();
        }
        BlockState state = blockItem.getBlock().defaultBlockState();
        IntegerProperty growth = isVerticalGrower(state) ? null : growthProperty(state);
        if (growth != null) {
            int clamped = Math.max(minOf(growth), Math.min(age, maxOf(growth)));
            state = state.setValue(growth, clamped);
        }
        IntegerProperty amount = amountProperty(state);
        if (amount != null) {
            int clamped = Math.max(minOf(amount), Math.min(stack.getCount(), maxOf(amount)));
            state = state.setValue(amount, clamped);
        }
        if (stack.is(GardenLayout.CANDLES)) {
            for (Property<?> property : state.getProperties()) {
                if (property instanceof BooleanProperty bp && property.getName().equals("lit")) {
                    state = state.setValue(bp, true);
                }
            }
        }
        return state;
    }

    /**
     * The blocks drawn for a stored item, bottom to top. A double plant is its lower and upper half; a
     * vertical grower (bamboo, sugar cane, cactus, ...) is one block per growth age, up to
     * {@link #MAX_HEIGHT}. Everything else is a single block.
     */
    public static List<BlockState> columnFor(ItemStack stack, int age) {
        BlockState state = stateFor(stack, age);
        List<BlockState> column = new ArrayList<>();
        if (state.isAir()) {
            return column;
        }
        if (state.hasProperty(BlockStateProperties.DOUBLE_BLOCK_HALF)) {
            column.add(state.setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.LOWER));
            column.add(state.setValue(BlockStateProperties.DOUBLE_BLOCK_HALF, DoubleBlockHalf.UPPER));
            return column;
        }
        if (isVerticalGrower(state)) {
            int height = Math.max(1, Math.min(age + 1, MAX_HEIGHT));
            for (int i = 0; i < height; i++) {
                column.add(state.getBlock() instanceof BambooStalkBlock ? bambooSegment(state, i, height) : state);
            }
            return column;
        }
        column.add(state);
        return column;
    }

    /** One block of a bamboo stalk: thick when tall, with small leaves second from the top and large leaves on top. */
    private static BlockState bambooSegment(BlockState state, int index, int height) {
        if (state.hasProperty(BlockStateProperties.AGE_1)) {
            state = state.setValue(BlockStateProperties.AGE_1, height >= 6 ? 1 : 0);
        }
        if (state.hasProperty(BlockStateProperties.BAMBOO_LEAVES)) {
            BambooLeaves leaves = BambooLeaves.NONE;
            if (index == height - 1 && height >= 3) {
                leaves = BambooLeaves.LARGE;
            } else if (index == height - 1 && height == 2 || index == height - 2 && height >= 3) {
                leaves = BambooLeaves.SMALL;
            }
            state = state.setValue(BlockStateProperties.BAMBOO_LEAVES, leaves);
        }
        return state;
    }
}
