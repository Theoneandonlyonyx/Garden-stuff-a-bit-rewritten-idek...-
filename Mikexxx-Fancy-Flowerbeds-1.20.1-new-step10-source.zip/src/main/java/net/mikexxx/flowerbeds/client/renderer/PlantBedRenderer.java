package net.mikexxx.flowerbeds.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.mikexxx.flowerbeds.block.entity.PlantBedBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraftforge.client.RenderTypeHelper;
import net.minecraft.util.RandomSource;
import net.minecraftforge.client.model.data.ModelData;
import java.util.List;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Draws the items of a bed at their real size, at the GUI positions. Scaled fruit is drawn at
 * {@link GardenLayout#SCALED_FRUIT_SCALE} and turned to the facing it was put in with. Everything is
 * lit from the air or block it occupies, so nothing is darker than its surroundings.
 */
public class PlantBedRenderer<T extends PlantBedBlockEntity> implements BlockEntityRenderer<T> {

    public PlantBedRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public void render(T bed, float partialTick, PoseStack poseStack, MultiBufferSource buffers,
                       int packedLight, int packedOverlay) {
        Level level = bed.getLevel();
        if (level == null) {
            return;
        }
        BlockPos pos = bed.getBlockPos();
        float baseY = bed.bedHeight();
        int light = LevelRenderer.getLightColor(level, baseY >= 1.0F ? pos.above() : pos);

        BlockState base = bed.baseState();
        if (base != null) {
            renderBaseBlock(base, level, pos, poseStack, buffers, packedOverlay);
        }

        BlockState substrate = bed.substrateState();
        if (substrate != null) {
            renderSubstrate(substrate, bed, level, pos, poseStack, buffers,
                    LevelRenderer.getLightColor(level, pos.above()), packedOverlay);
        }

        // Plants are drawn bottom to top; a tall plant is a column of blocks (double plants, bamboo, ...).
        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            ItemStack stack = bed.getSlot(i);
            if (stack.isEmpty()) {
                continue;
            }
            List<BlockState> column = PlantStates.columnFor(stack, bed.getAge(i));
            float x = GardenLayout.localX(i);
            float z = GardenLayout.localZ(i);
            boolean scaled = GardenLayout.isScaled(stack);
            for (int k = 0; k < column.size(); k++) {
                poseStack.pushPose();
                if (scaled) {
                    poseStack.translate(x, baseY, z);
                    poseStack.mulPose(Axis.YP.rotationDegrees(bed.getRotation(i) * 90.0F));
                    float s = GardenLayout.SCALED_FRUIT_SCALE;
                    poseStack.scale(s, s, s);
                    poseStack.translate(-0.5, 0.0, -0.5);
                } else {
                    poseStack.translate(x - 0.5, baseY + k, z - 0.5);
                }
                int blockLight = LevelRenderer.getLightColor(level, pos.above(k + (baseY >= 1.0F ? 1 : 0)));
                renderState(column.get(k), level, pos, poseStack, buffers, blockLight, packedOverlay);
                poseStack.popPose();
            }
        }

        ItemStack groundcover = bed.getSlot(GardenLayout.GROUNDCOVER_SLOT);
        if (!groundcover.isEmpty()) {
            poseStack.pushPose();
            poseStack.translate(0.0, baseY, 0.0);
            BlockState state = PlantStates.stateFor(groundcover, bed.getAge(GardenLayout.GROUNDCOVER_SLOT));
            renderState(state, level, pos, poseStack, buffers, light, packedOverlay);
            poseStack.popPose();
        }
    }

    /**
     * Draws one block state like the block renderer does, but tinted with the real colour of the bed's
     * position, so grass, ferns and leaves get their biome colour. When a colour handler cannot answer, a plain
     * green stands in.
     */
    private void renderState(BlockState state, Level level, BlockPos tintPos, PoseStack poseStack,
                             MultiBufferSource buffers, int light, int overlay) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        if (state.getRenderShape() != RenderShape.MODEL) {
            dispatcher.renderSingleBlock(state, poseStack, buffers, light, overlay);
            return;
        }
        BakedModel model = dispatcher.getBlockModel(state);
        int rgb = PlantTint.color(state, level, tintPos, 0);
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        for (RenderType renderType : model.getRenderTypes(state, RandomSource.create(42L), ModelData.EMPTY)) {
            dispatcher.getModelRenderer().renderModel(poseStack.last(),
                    buffers.getBuffer(RenderTypeHelper.getEntityRenderType(renderType, false)),
                    state, model, r, g, b, light, overlay, ModelData.EMPTY, renderType);
        }
    }

    /**
     * Draws the top face of the substrate block flat at the planting surface, using that block's own top
     * texture and tint (so grass is biome green). Pot walls hide the edges.
     */
    private void renderSubstrate(BlockState substrate, T bed, Level level, BlockPos pos, PoseStack poseStack,
                                 MultiBufferSource buffers, int light, int overlay) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        BakedModel model = dispatcher.getBlockModel(substrate);
        List<BakedQuad> quads = model.getQuads(substrate, Direction.UP, RandomSource.create(42L), ModelData.EMPTY, null);
        TextureAtlasSprite sprite;
        int tint = -1;
        if (quads.isEmpty()) {
            sprite = model.getParticleIcon(ModelData.EMPTY);
        } else {
            sprite = quads.get(0).getSprite();
            tint = quads.get(0).getTintIndex();
        }
        int rgb = PlantTint.color(substrate, level, pos, tint);
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(TextureAtlas.LOCATION_BLOCKS));
        PoseStack.Pose pose = poseStack.last();
        float y = bed.bedHeight() - 0.002F;
        float u0 = sprite.getU0();
        float u1 = sprite.getU1();
        float v0 = sprite.getV0();
        float v1 = sprite.getV1();
        vertex(consumer, pose, 0, y, 0, r, g, b, u0, v0, overlay, light);
        vertex(consumer, pose, 0, y, 1, r, g, b, u0, v1, overlay, light);
        vertex(consumer, pose, 1, y, 1, r, g, b, u1, v1, overlay, light);
        vertex(consumer, pose, 1, y, 0, r, g, b, u1, v0, overlay, light);
    }

    /**
     * Draws a full block (the original of a bedding block) face by face, the way the chunk renderer would:
     * faces hidden by an opaque neighbour are skipped, and each visible face is lit by the block in front of
     * it and shaded by its direction.
     */
    private void renderBaseBlock(BlockState base, Level level, BlockPos pos, PoseStack poseStack,
                                 MultiBufferSource buffers, int overlay) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        BakedModel model = dispatcher.getBlockModel(base);
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(TextureAtlas.LOCATION_BLOCKS));
        RandomSource random = RandomSource.create(42L);
        for (Direction face : Direction.values()) {
            BlockPos neighbor = pos.relative(face);
            if (!Block.shouldRenderFace(base, level, pos, face, neighbor)) {
                continue;
            }
            int light = LevelRenderer.getLightColor(level, neighbor);
            float shade = level.getShade(face, true);
            for (BakedQuad quad : model.getQuads(base, face, random, ModelData.EMPTY, null)) {
                int rgb = PlantTint.color(base, level, pos, quad.getTintIndex());
                float s = quad.isShade() ? shade : 1.0F;
                consumer.putBulkData(poseStack.last(), quad,
                        s * (rgb >> 16 & 255) / 255.0F, s * (rgb >> 8 & 255) / 255.0F, s * (rgb & 255) / 255.0F,
                        light, overlay);
            }
        }
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, float x, float y, float z,
                               float r, float g, float b, float u, float v, int overlay, int light) {
        consumer.vertex(pose.pose(), x, y, z).color(r, g, b, 1.0F).uv(u, v).overlayCoords(overlay)
                .uv2(light).normal(pose.normal(), 0.0F, 1.0F, 0.0F).endVertex();
    }
}
