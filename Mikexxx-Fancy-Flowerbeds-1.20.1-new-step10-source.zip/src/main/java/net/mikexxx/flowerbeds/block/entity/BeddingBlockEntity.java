package net.mikexxx.flowerbeds.block.entity;

import net.mikexxx.flowerbeds.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/** A bedding block remembers the block it was made from, which it looks like and gives back when broken. */
public class BeddingBlockEntity extends PlantBedBlockEntity {

    private Block original = Blocks.DIRT;

    public BeddingBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.BEDDING.get(), pos, state);
    }

    @Override
    public float bedHeight() {
        return 1.0F;
    }

    public Block getOriginal() {
        return original;
    }

    public void setOriginal(Block block) {
        this.original = block;
        onSlotsChanged();
    }

    @Override
    public BlockState baseState() {
        return original.defaultBlockState();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ResourceLocation key = ForgeRegistries.BLOCKS.getKey(original);
        if (key != null) {
            tag.putString("Original", key.toString());
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        original = Blocks.DIRT;
        if (tag.contains("Original")) {
            ResourceLocation key = ResourceLocation.tryParse(tag.getString("Original"));
            if (key != null && ForgeRegistries.BLOCKS.containsKey(key)) {
                original = ForgeRegistries.BLOCKS.getValue(key);
            }
        }
    }
}
