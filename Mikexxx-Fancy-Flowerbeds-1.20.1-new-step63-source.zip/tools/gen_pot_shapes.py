"""Makes pot_shapes.json: the collision shape of the china pot and the amphora, cut from their own models so the
hitbox follows the vase (nothing walkable behind a narrow neck). Run from the project root: python3 tools/gen_pot_shapes.py"""
import json, os
A = "src/main/resources/assets/mikexxx_flowerbeds/"
M = A + "models/block/"
SETS = {"china": "china_large_pot", "amphora": "quartz_amphora_pot"}
BITS = (("north", 1), ("east", 2), ("south", 4), ("west", 8), ("northeast", 16), ("southeast", 32), ("southwest", 64), ("northwest", 128))
ROUND = ["nw", "n", "ne", "w", "c", "e", "sw", "s", "se"]

_cache = {}
def voxels(model):
    """16x16x16 solid cells: a cell is solid when the model fills at least a quarter of it."""
    if model in _cache: return _cache[model]
    import math
    import numpy as np
    sub = np.zeros((32, 32, 32), dtype=bool)  # [y][z][x] in half pixels
    for e in json.load(open(M + model + ".json"))["elements"]:
        f, t = e["from"], e["to"]
        lo = [max(0, math.ceil(2 * f[i] - 0.5)) for i in range(3)]
        hi = [min(32, math.ceil(2 * t[i] - 0.5)) for i in range(3)]
        if all(hi[i] > lo[i] for i in range(3)):
            sub[lo[1]:hi[1], lo[2]:hi[2], lo[0]:hi[0]] = True
    cnt = sub.reshape(16, 2, 16, 2, 16, 2).sum(axis=(1, 3, 5))
    _cache[model] = (cnt >= 2).tolist()
    return _cache[model]

def boxes(v):
    """Greedy merge: rectangles per layer, then stacked while identical."""
    layers = []
    for y in range(16):
        used = [[False] * 16 for _ in range(16)]; rects = []
        for z in range(16):
            for x in range(16):
                if v[y][z][x] and not used[z][x]:
                    x1 = x
                    while x1 + 1 < 16 and v[y][z][x1 + 1] and not used[z][x1 + 1]: x1 += 1
                    z1 = z
                    while z1 + 1 < 16 and all(v[y][z1 + 1][i] and not used[z1 + 1][i] for i in range(x, x1 + 1)): z1 += 1
                    for zz in range(z, z1 + 1):
                        for xx in range(x, x1 + 1): used[zz][xx] = True
                    rects.append((x, z, x1 + 1, z1 + 1))
        layers.append(rects)
    out = []; open_ = {}
    for y in range(17):
        cur = set(layers[y]) if y < 16 else set()
        for r in list(open_):
            if r not in cur: out.append([r[0], open_[r], r[1], r[2], y, r[3]]); del open_[r]
        for r in cur:
            if r not in open_: open_[r] = y
    return out

def walkable(v, n, e, so, w, ne, se, sw, nw):
    """China pot: a hollow pot you can walk into. Walls (2 px) follow the outer outline of the vase's belly (so the
    corners are as round as the model and there are no corner posts), the open neck does not close the pot, and
    where a neighbour pot is joined there is no wall. Floor 1 px."""
    F = [[any(v[y][z][x] for y in range(16)) for x in range(16)] for z in range(16)]
    top = [[max([y + 1 for y in range(16) if v[y][z][x]] or [0]) for x in range(16)] for z in range(16)]
    def inside(x, z):
        if 0 <= x < 16 and 0 <= z < 16: return F[z][x]
        ox = -1 if x < 0 else 1 if x > 15 else 0
        oz = -1 if z < 0 else 1 if z > 15 else 0
        if ox and oz:
            return {(-1, -1): nw and n and w, (1, -1): ne and n and e, (-1, 1): sw and so and w, (1, 1): se and so and e}[(ox, oz)]
        if ox: return w if ox < 0 else e
        return n if oz < 0 else so
    B1 = [[False] * 16 for _ in range(16)]
    for z in range(16):
        for x in range(16):
            if F[z][x] and any(not inside(x + dx, z + dz) for dx in (-1, 0, 1) for dz in (-1, 0, 1)):
                B1[z][x] = True
    H = [[0] * 16 for _ in range(16)]
    wall = [[False] * 16 for _ in range(16)]
    for z in range(16):
        for x in range(16):
            if B1[z][x]:
                wall[z][x] = True; H[z][x] = top[z][x]
    for z in range(16):
        for x in range(16):
            if F[z][x] and not B1[z][x]:
                near = [(x + dx, z + dz) for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1))]
                near = [(a, b) for a, b in near if 0 <= a < 16 and 0 <= b < 16 and B1[b][a]]
                if near:
                    wall[z][x] = True; H[z][x] = max(top[b][a] for a, b in near)
    out = [[[False] * 16 for _ in range(16)] for _ in range(16)]
    for z in range(16):
        for x in range(16):
            if F[z][x]: out[0][z][x] = True
            if wall[z][x]:
                for y in range(max(1, min(16, H[z][x]))): out[y][z][x] = True
    return out

SIDES_OF_ROUND = {"nw": (0, 1, 1, 0), "n": (0, 1, 1, 1), "ne": (0, 0, 1, 1), "w": (1, 1, 1, 0), "c": (1, 1, 1, 1),
                  "e": (1, 0, 1, 1), "sw": (1, 1, 0, 0), "s": (1, 1, 0, 1), "se": (1, 0, 0, 1)}
result = {}
for key, state in SETS.items():
    bs = json.load(open(A + "blockstates/%s.json" % state))["multipart"]
    def resolve(props):
        for p in bs:
            if all(props.get(k) in str(v).split("|") for k, v in p["when"].items()):
                return p["apply"]["model"].split("/")[-1]
    table = {}
    for mask in range(256):
        props = {k: str(bool(mask & b)).lower() for k, b in BITS}; props["round3"] = "none"
        m = resolve(props)
        if m and key == "china":
            g = lambda b: bool(mask & b)
            table["m:%d" % mask] = boxes(walkable(voxels(m), g(1), g(2), g(4), g(8), g(16), g(32), g(64), g(128)))
        elif m: table["m:%d" % mask] = boxes(voxels(m))
    for r in ROUND:
        props = {k: "true" for k, _ in BITS}; props["round3"] = r
        m = resolve(props)
        if m and ("round3" in str(bs) and r != "none"):
            if key == "china":
                n_, e_, s_, w_ = SIDES_OF_ROUND[r]
                table["r:" + r] = boxes(walkable(voxels(m), n_, e_, s_, w_, n_ and e_, e_ and s_, s_ and w_, w_ and n_))
            else:
                table["r:" + r] = boxes(voxels(m))
    result[key] = table
    print(key, len(table), "shapes, boxes in m:0 =", len(table.get("m:0", [])), "total", sum(len(v) for v in table.values()))
json.dump(result, open(A + "pot_shapes.json", "w"), separators=(",", ":"))
print(os.path.getsize(A + "pot_shapes.json"), "bytes")
