#!/usr/bin/env python3
"""
Step 57: a finished 5x5 of birdbaths turns into one round bowl, like the 3x3 and the 4x4.

Writes, from the project root (python3 tools/gen_round5.py):
  - models/block/silver_birdbath_round5_XZ.json   25 bowl cells (X and Z 0..4)
  - birdbath_water.json                            keys "p:XZ", the water of each cell
  - blockstates/silver_birdbath.json               parts for group p_xz (the notch variants come from
                                                   tools/notch_models.py, run it afterwards)

The bowl is lathed the same way as the 3x3 and 4x4 bowls: five tiers (two solid discs, then three rings)
whose radii follow the bowl radius R (24 for 3x3, 32 for 4x4, 40 for 5x5). Everything is rasterised in
half-pixel cells over the whole 5x5 so the cells meet without gaps and faces only exist where a tier is exposed.
"""
import json, math, os

A = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src/main/resources/assets/mikexxx_flowerbeds")
N = 5
R = 8.0 * N          # bowl radius in sixteenths (centre of the 5x5 is at R, R)
STEP = 0.5
G = int(16 / STEP) * N   # subcells per side of the whole bath

# (y0, y1, outer radius, inner radius or None for a solid disc)
TIERS = [
    (13.0, 13.6, R - 3.9, None),
    (13.6, 14.2, R - 2.15, None),
    (14.2, 14.8, R - 1.15, R - 2.3),
    (14.8, 15.4, R - 0.4, R - 1.35),
    (15.4, 16.0, R, R - 0.7),
]
WATER_R = R - 1.4

TEXTURES = {
    "side": "mikexxx_flowerbeds:block/silver_birdbath_side",
    "band": "mikexxx_flowerbeds:block/silver_birdbath_band",
    "top": "mikexxx_flowerbeds:block/silver_birdbath_top",
    "inner": "mikexxx_flowerbeds:block/silver_birdbath_inner",
    "particle": "mikexxx_flowerbeds:block/silver_birdbath_side",
}


def dist(gx, gz):
    return math.hypot((gx + 0.5) * STEP - R, (gz + 0.5) * STEP - R)


def build_solid():
    solid = []
    for ro, ri in [(t[2], t[3]) for t in TIERS]:
        grid = [[False] * G for _ in range(G)]
        for gx in range(G):
            for gz in range(G):
                d = dist(gx, gz)
                grid[gx][gz] = d <= ro and (ri is None or d >= ri)
        solid.append(grid)
    return solid


SOLID = build_solid()


def is_solid(t, gx, gz):
    return 0 <= gx < G and 0 <= gz < G and SOLID[t][gx][gz]


def signature(t, gx, gz):
    """Which faces the half-pixel cell has, as a tuple of (face, texture)."""
    ri = TIERS[t][3]
    sig = []
    for face, dx, dz in (("west", -1, 0), ("east", 1, 0), ("north", 0, -1), ("south", 0, 1)):
        nx, nz = gx + dx, gz + dz
        if is_solid(t, nx, nz):
            continue
        inside_hole = 0 <= nx < G and 0 <= nz < G and ri is not None and dist(nx, nz) < ri
        sig.append((face, "#inner" if inside_hole else "#band"))
    if t == len(TIERS) - 1 or not is_solid(t + 1, gx, gz):
        sig.append(("up", "#inner"))
    if t == 0 or not is_solid(t - 1, gx, gz):
        sig.append(("down", "#top"))
    return tuple(sig)


def cell_model(ci, cj):
    elements = []
    for t, (y0, y1, _, _) in enumerate(TIERS):
        rows = []
        for lz in range(int(16 / STEP)):
            gz = cj * int(16 / STEP) + lz
            runs = []
            lx = 0
            while lx < int(16 / STEP):
                gx = ci * int(16 / STEP) + lx
                if not is_solid(t, gx, gz):
                    lx += 1
                    continue
                sig = signature(t, gx, gz)
                start = lx
                lx += 1
                while lx < int(16 / STEP):
                    g2 = ci * int(16 / STEP) + lx
                    if not is_solid(t, g2, gz) or signature(t, g2, gz) != sig:
                        break
                    lx += 1
                runs.append((start, lx, sig))
            rows.append(runs)
        # Merge consecutive rows that have identical runs into taller boxes.
        lz = 0
        while lz < len(rows):
            if not rows[lz]:
                lz += 1
                continue
            end = lz + 1
            while end < len(rows) and rows[end] == rows[lz] and not _row_edges_differ(rows[lz], t, ci, cj, lz, end):
                end += 1
            for (a, b, sig) in rows[lz]:
                faces = {}
                for face, tex in sig:
                    faces[face] = {"texture": tex}
                # North/south faces belong to the first/last merged row only; inside the box there are none.
                if (end - lz) > 1:
                    # recompute the end faces from the first and last row (they may differ)
                    first = signature(t, ci * 32 + a, cj * 32 + lz)
                    last = signature(t, ci * 32 + a, cj * 32 + end - 1)
                    faces = {k: {"texture": v} for k, v in first if k != "south"}
                    for k, v in last:
                        if k == "south":
                            faces["south"] = {"texture": v}
                elements.append({
                    "from": [a * STEP, y0, lz * STEP],
                    "to": [b * STEP, y1, end * STEP],
                    "faces": faces,
                })
            lz = end
    return {"ambientocclusion": False, "textures": TEXTURES, "elements": elements}


def _row_edges_differ(runs, t, ci, cj, first, row):
    """Rows can only be merged when every run has the same faces in this row as in the first one."""
    for (a, b, sig) in runs:
        s = signature(t, ci * 32 + a, cj * 32 + row)
        f = signature(t, ci * 32 + a, cj * 32 + first)
        strip = lambda x: tuple(p for p in x if p[0] not in ("north", "south"))
        if strip(s) != strip(f):
            return True
    return False


def water_rects(ci, cj):
    rects = []
    for lz in range(32):
        gz = cj * 32 + lz
        xs = [lx for lx in range(32) if dist(ci * 32 + lx, gz) <= WATER_R]
        if not xs:
            continue
        x0, x1 = min(xs) * STEP, (max(xs) + 1) * STEP
        z0, z1 = lz * STEP, (lz + 1) * STEP
        if rects and rects[-1][0] == x0 and rects[-1][2] == x1 and rects[-1][3] == z0:
            rects[-1][3] = z1
        else:
            rects.append([x0, z0, x1, z1])
    return rects


def main():
    models = os.path.join(A, "models/block")
    water_path = os.path.join(A, "birdbath_water.json")
    water = json.load(open(water_path))
    bs_path = os.path.join(A, "blockstates/silver_birdbath.json")
    bs = json.load(open(bs_path))
    bs["multipart"] = [p for p in bs["multipart"] if not p["when"].get("group", "").startswith("p_")]
    for cj in range(N):
        for ci in range(N):
            name = "silver_birdbath_round5_%d%d" % (ci, cj)
            json.dump(cell_model(ci, cj), open(os.path.join(models, name + ".json"), "w"), separators=(",", ":"))
            water["p:%d%d" % (ci, cj)] = water_rects(ci, cj)
            group = "p_%d%d" % (ci, cj)
            model = "mikexxx_flowerbeds:block/" + name
            if (ci, cj) == (N // 2, N // 2):
                bs["multipart"] += [
                    {"when": {"group": group}, "apply": {"model": model}},
                    {"when": {"group": group, "down": "false"},
                     "apply": {"model": "mikexxx_flowerbeds:block/silver_birdbath_foot_l_oo"}},
                    {"when": {"group": group, "down": "true"},
                     "apply": {"model": "mikexxx_flowerbeds:block/silver_birdbath_foot_l_oo_stacked"}},
                    {"when": {"group": group, "up": "true"},
                     "apply": {"model": "mikexxx_flowerbeds:block/silver_birdbath_post_l_oo"}},
                ]
            else:
                bs["multipart"].append({"when": {"group": group}, "apply": {"model": model}})
    json.dump(water, open(water_path, "w"), separators=(",", ":"))
    json.dump(bs, open(bs_path, "w"), indent=1)
    print("round5 cells written, water keys:", len([k for k in water if k.startswith("p:")]))


if __name__ == "__main__":
    main()
