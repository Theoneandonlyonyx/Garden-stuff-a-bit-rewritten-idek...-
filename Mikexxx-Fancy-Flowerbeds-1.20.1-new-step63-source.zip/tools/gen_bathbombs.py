"""Makes the Sakura and Violet bathbomb icons (16x16) from the approved artwork in tools/bathbomb_source.jpg:
the same pixels and colours, with the yellow flower bit taken out, a symmetrical round outline and two sparkles that
touch the bomb. Run from the project root: python3 tools/gen_bathbombs.py"""
import math, os
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'src/main/resources/assets/mikexxx_flowerbeds/textures/item')
SRC = np.array(Image.open(os.path.join(HERE, 'bathbomb_source.jpg')).convert('RGB')).astype(int)
OX, OY, PITCH = 1, 2, 16      # the artwork is drawn 16 screen pixels per texture pixel, starting at (1, 2)
PINK_COL, VIOLET_COL = 0, 17  # column of the first cell of each bomb in the artwork
# cells of the pink bomb that are not body: the tiny flower with the yellow centre, stray bumps
STRAY = {(3, 3), (10, 4), (11, 4), (12, 4), (10, 5), (11, 5), (12, 5), (10, 6), (11, 6), (12, 6),
         (1, 9), (1, 10), (13, 12), (3, 4)}
R = 6.3   # the bomb is a circle of 12x12 pixels exactly in the middle of the 16x16 icon (columns/rows 2..13)

def cell(col, row):
    x, y = OX + PITCH * col, OY + PITCH * row
    px = SRC[y + 4:y + 12, x + 4:x + 12].reshape(-1, 3)
    return tuple(int(v) for v in np.median(px, axis=0))

def is_bg(c): return all(abs(c[k] - 128) < 14 for k in range(3))

def make(first_col):
    src = {}
    for row in range(3, 17):
        for col in range(0, 15):
            c = cell(first_col + col, row)
            if not is_bg(c): src[(col, row)] = c
    # snap near-identical colours (jpeg noise) to one colour
    reps = []
    def snap(c):
        for r in reps:
            if sum(abs(c[k] - r[k]) for k in range(3)) < 14: return r
        reps.append(c); return c
    src = {k: snap(v) for k, v in src.items()}
    inside = lambda x, y: math.hypot(x + .5 - 8, y + .5 - 8) <= R
    body = {k: v for k, v in src.items() if k not in STRAY and 2 <= k[0] <= 12 and 4 <= k[1] <= 15}
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    for y in range(16):
        for x in range(16):
            if not inside(x, y): continue
            # the artwork body is 11x12 pixels: stretch it onto the 12x12 circle (face stays mirrored around the middle)
            sx = 2 + int((x - 2 + .5) * 11 / 12)
            sy = 4 + int((y - 2 + .5) * 12 / 12)
            if (sx, sy) in body: c = body[(sx, sy)]
            else:   # fill from the nearest body pixel
                c = min(body.items(), key=lambda kv: abs(kv[0][0] - sx) + abs(kv[0][1] - sy))[1]
            img.putpixel((x, y), c + (255,))
    return img

def sparkles(img, centre, arm):
    """Two plus-shaped sparkles that touch the bomb: upper left and lower right, opposite each other."""
    for (cx, cy) in [(2, 3), (13, 12)]:
        for (ox, oy) in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            img.putpixel((cx + ox, cy + oy), arm)
        img.putpixel((cx, cy), centre)

if __name__ == '__main__':
    for name, col, arm in (('sakura', PINK_COL, (255, 205, 223, 255)), ('violet', VIOLET_COL, (243, 235, 255, 255))):
        im = make(col); sparkles(im, (255, 255, 255, 255), arm)
        im.save(os.path.join(OUT, name + '_bathbomb.png'))
