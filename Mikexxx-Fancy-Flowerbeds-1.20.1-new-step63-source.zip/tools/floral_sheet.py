"""Builds textures/misc/floral_sheet.png: the floating petals and the waterlily parts in one sheet.
They are drawn from this sheet (not from the block atlas) so they are never mip-mapped: no pale squares
around small petals. Run from the project root:  python3 tools/floral_sheet.py"""
import math, os
from PIL import Image
SRC = 'tools/floral_src/'
OUT = 'src/main/resources/assets/mikexxx_flowerbeds/textures/misc/floral_sheet.png'
NAMES = ['aroma_petal_0','aroma_petal_1','aroma_petal_2','aroma_violet_0','aroma_violet_1','aroma_violet_2',
         'lily_petal_cream','lily_petal_lilac','lily_petal_pink','lily_petal_white',
         'lily_bud_cream','lily_bud_lilac','lily_bud_pink','lily_bud_white',
         'lily_sepal','lily_stamen','lily_pad_0','lily_pad_1','lily_pad_2']
COL = {'pink': ((222,104,156),(255,218,236)), 'white': ((214,218,236),(255,255,255)),
       'cream': ((236,208,140),(255,246,214)), 'lilac': ((160,118,214),(232,212,252))}


def lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def petal(deep, light, bud=False):
    im = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    px = im.load()
    top, base = (2.0, 14.5) if not bud else (1.5, 14.5)
    wmax = 5.6 if not bud else 4.3
    for y in range(16):
        for x in range(16):
            t = (base - (y + 0.5)) / (base - top)  # 0 at the base, 1 at the tip
            if t < 0 or t > 1:
                continue
            if bud:
                prof = math.sin(math.pi * min(1.0, t * 0.97) ** 0.95) ** 0.7
            else:
                prof = math.sin(math.pi * min(1.0, t * 0.97) ** 0.78) ** 0.8
            hw = wmax * prof * (1.0 - 0.15 * t)
            d = abs((x + 0.5) - 8.0)
            cov = max(0.0, min(1.0, hw - d + 0.5))
            if cov <= 0:
                continue
            c = lerp(deep, light, min(1.0, t * 1.15))
            if d < 0.6 and t > 0.1:
                c = lerp(c, deep, 0.18)  # faint centre vein
            if bud and t < 0.25:
                c = lerp((96, 150, 84), c, t / 0.25)  # green at the foot of a bud
            a = int(255 * (1.0 if cov > 0.85 else 0.35 + 0.6 * cov))
            px[x, y] = c + (a,)
    return im


def sepal():
    im = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    px = im.load()
    for y in range(16):
        for x in range(16):
            t = (14.5 - (y + 0.5)) / 12.0
            if t < 0 or t > 1:
                continue
            hw = 2.6 * math.sin(math.pi * t ** 0.8) ** 0.8
            cov = max(0.0, min(1.0, hw - abs(x + 0.5 - 8) + 0.5))
            if cov > 0:
                px[x, y] = lerp((70, 134, 64), (128, 184, 96), t) + (int(255 * (1 if cov > 0.85 else 0.4 + 0.6 * cov)),)
    return im


def bleed(im):
    """Give fully transparent texels the average colour of the sprite: no dark or pale fringe."""
    px = im.load()
    w, h = im.size
    op = [px[x, y][:3] for y in range(h) for x in range(w) if px[x, y][3] > 200]
    if not op:
        return im
    avg = tuple(sum(c[i] for c in op) // len(op) for i in range(3))
    for y in range(h):
        for x in range(w):
            if px[x, y][3] == 0:
                px[x, y] = avg + (0,)
    return im


sheet = Image.new('RGBA', (128, 128), (0, 0, 0, 0))
for i, n in enumerate(NAMES):
    if n.startswith('lily_petal_'):
        im = petal(*COL[n[11:]])
    elif n.startswith('lily_bud_'):
        im = petal(*COL[n[9:]], bud=True)
    elif n == 'lily_sepal':
        im = sepal()
    else:
        im = Image.open(SRC + n + '.png').convert('RGBA')
        if im.size != (16, 16):
            im = im.resize((16, 16), Image.NEAREST)
    sheet.paste(bleed(im), ((i % 8) * 16, (i // 8) * 16))
os.makedirs(os.path.dirname(OUT), exist_ok=True)
sheet.save(OUT)
print('sheet saved', len(NAMES), 'sprites')
