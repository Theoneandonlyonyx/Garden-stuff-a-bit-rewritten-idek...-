"""Design sheet for the stackable Viola odorata (sweet violet): block stages 1-4 (top view, like vanilla pink petals,
every stage already has flowers) and item icon options. Run: python3 tools/viola_designs.py"""
import os
from PIL import Image
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'designs', 'viola_odorata')
os.makedirs(OUT, exist_ok=True)
C = {'.': None, 'D': '#46267f', 'M': '#7a49c2', 'L': '#a77fe0', 'W': '#f4ecff', 'Y': '#ffe9a6',
     'g': '#2f6a33', 'G': '#4f9a45', 'H': '#86cc66', 'S': '#3b7a3a'}
def px(ch):
    v = C[ch]
    return None if v is None else tuple(int(v[i:i+2], 16) for i in (1, 3, 5)) + (255,)

# 8x8 cells of the top view: one violet with its heart-shaped leaves. Three variants so a stack never looks copied.
CELLS = {
 'a': ["g.gg....",
       "GgGGg.D.",
       "HGGGgDMD",
       ".GGG.MLM",
       "..G..MYM",
       "......M.",
       "........",
       "........"],
 'b': ["........",
       ".D.D....",
       "DMDMD.gg",
       ".MLM.gGG",
       ".MYM.GHG",
       "..M...GG",
       ".....g..",
       "........"],
 'c': ["........",
       "....gg..",
       "...gGGg.",
       ".D.GHGG.",
       "DMD.GG..",
       ".MLM....",
       ".MWM....",
       "..M....."],
 'd': ["..DD....",
       ".DMMD...",
       "DMLMMD..",
       ".MLWM...",
       "..M.gGg.",
       "....GHGg",
       ".....GG.",
       "........"],
}
def cell(name):
    im = Image.new('RGBA', (8, 8), (0, 0, 0, 0))
    for y, row in enumerate(CELLS[name]):
        for x, ch in enumerate(row):
            c = px(ch)
            if c: im.putpixel((x, y), c)
    return im

def stage(n):
    """n flowers (1-4) placed on a 16x16 top view; the cells fill the quadrants one after another."""
    im = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    slots = [(0, 8, 'a'), (8, 0, 'b'), (0, 0, 'c'), (8, 8, 'd')]
    for x, y, v in slots[:n]:
        im.alpha_composite(cell(v), (x, y))
    return im

ICONS = {
 # A: a little bunch of three violets with heart leaves, tilted like a posy
 'icon_a_posy': ["................",
                 "......D.D.......",
                 ".D.D.DMDMD......",
                 "DMDMD.MLM..D.D..",
                 ".MYM..MYM.DMDMD.",
                 "..M....M...MYM..",
                 "..g.g..S....M...",
                 "..gGgGgS..g.S.g.",
                 "...gGHGSg.GgS.G.",
                 "....gGGgSGGS.Gg.",
                 ".....gGGSGS.gG..",
                 "......gGSS.g....",
                 ".......SS.......",
                 "......SS........",
                 ".....SS.........",
                 "................"],
 # B: a single violet on a bent stem with one leaf
 'icon_b_single': ["................",
                   "................",
                   "......D..D......",
                   ".....DMDDMD.....",
                   ".....MMLLMM.....",
                   "....DMMLWMMD....",
                   ".....MMYYMM.....",
                   "......MMMM......",
                   ".......MM.......",
                   "........S.......",
                   "...gg...S.......",
                   "..gGGg..S.......",
                   "..GHGGgSS.......",
                   "...GGGGS........",
                   "....gGS.........",
                   "................"],
 # C: the flat pink-petals look: loose violet blossoms lying on a leaf
 'icon_c_blossoms': ["................",
                     "................",
                     "....gg..........",
                     "...gGGg..D.D....",
                     "..gGHGGg.DMDMD..",
                     "..GHGGGg.MLMLM..",
                     "...GGGg...MYM...",
                     "....GG....DMD...",
                     "..D.D.....g.....",
                     ".DMDMD...gGg....",
                     ".MLMLM..gGHGg...",
                     "..MYM...GHGGg...",
                     "...M.....GGg....",
                     "................",
                     "................",
                     "................"],
}
def icon(name):
    im = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    for y, row in enumerate(ICONS[name]):
        for x, ch in enumerate(row):
            c = px(ch)
            if c: im.putpixel((x, y), c)
    return im

if __name__ == '__main__':
    S = 12
    sheet = Image.new('RGBA', (16 * S * 4 + 5 * 16, 16 * S * 2 + 3 * 16), (122, 122, 122, 255))
    for i in range(4):
        st = stage(i + 1); st.save(os.path.join(OUT, 'stage_%d.png' % (i + 1)))
        big = st.resize((16 * S, 16 * S), Image.NEAREST)
        # soft ground tile behind, so the top view reads like lying on grass
        ground = Image.new('RGBA', big.size, (96, 140, 70, 255)); ground.alpha_composite(big)
        sheet.paste(ground, (16 + i * (16 * S + 16), 16))
    for i, n in enumerate(ICONS):
        ic = icon(n); ic.save(os.path.join(OUT, n + '.png'))
        sheet.paste(ic.resize((16 * S, 16 * S), Image.NEAREST), (16 + i * (16 * S + 16), 16 * S + 32), ic.resize((16 * S, 16 * S), Image.NEAREST))
    sheet.save(os.path.join(OUT, 'viola_designs.png'))
