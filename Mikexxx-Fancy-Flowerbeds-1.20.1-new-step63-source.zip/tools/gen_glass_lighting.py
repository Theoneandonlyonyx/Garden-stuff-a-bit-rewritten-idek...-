"""Step 55: cleans up the glass pot models.

- Faces that lie exactly on the block boundary take their light from the neighbouring block. Next to a solid
  block (or the ground) that is pitch dark, which showed up as black lines and dots along the glass pot. Every
  glass pot element is therefore pulled in by 0.02 sixteenths on each outer side, so the faces use the pot's own light.
- Ambient occlusion is off for the glass models (no dark corners on clear glass).
- The lip on top is gone: no rim faces on top of walls and posts. The top edge is a single thin line in the
  'rail' texture, which disappears where another glass pot sits on top (the "joined" models use plain glass).
"""
import json, glob, os
from PIL import Image

ROOT = os.path.join(os.path.dirname(__file__), '..', 'src', 'main', 'resources', 'assets', 'mikexxx_flowerbeds')
EPS = 0.02

def pull(v, hi):
    if v <= 0.0:
        return EPS
    if v >= 16.0:
        return 16.0 - EPS
    return v

for path in glob.glob(os.path.join(ROOT, 'models', 'block', 'glass_*.json')):
    d = json.load(open(path))
    for e in d.get('elements', []):
        e['from'] = [pull(v, False) for v in e['from']]
        e['to'] = [pull(v, True) for v in e['to']]
        if e['to'][1] >= 15.9:
            e['faces'].pop('up', None)
    d['ambientocclusion'] = False
    json.dump(d, open(path, 'w'), indent=1)

rail = os.path.join(ROOT, 'textures', 'block', 'glass_pot_rail.png')
im = Image.open(rail).convert('RGBA')
for x in range(16):
    im.putpixel((x, 0), (236, 252, 255, 190))
    im.putpixel((x, 1), (205, 235, 242, 36))
im.save(rail)
