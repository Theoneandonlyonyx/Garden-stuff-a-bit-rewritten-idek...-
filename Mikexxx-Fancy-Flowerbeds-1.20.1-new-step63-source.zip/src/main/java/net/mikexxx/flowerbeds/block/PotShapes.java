package net.mikexxx.flowerbeds.block;

import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The hitbox of the china pot and the amphora, cut from their models (pot_shapes.json, made by
 * tools/gen_pot_shapes.py), so it follows the vase: a narrow neck blocks the way into the belly.
 * Keys: "m:N" for neighbour mask N, "r:nw" .. "r:se" for a cell of a round 3x3.
 */
public final class PotShapes {
    private static Map<String, JsonObject> tables;
    private static final Map<String, VoxelShape> CACHE = new ConcurrentHashMap<>();
    private static final VoxelShape MISSING = Shapes.empty();

    private PotShapes() {
    }

    /** The hitbox for this set ("china" or "amphora") and key, or null when there is none (use the plain pot). */
    public static VoxelShape get(String set, String key) {
        VoxelShape shape = CACHE.computeIfAbsent(set + "/" + key, k -> build(set, key));
        return shape == MISSING ? null : shape;
    }

    private static VoxelShape build(String set, String key) {
        JsonObject table = load().get(set);
        if (table == null || !table.has(key)) {
            return MISSING;
        }
        VoxelShape shape = Shapes.empty();
        for (JsonElement e : table.getAsJsonArray(key)) {
            JsonArray b = e.getAsJsonArray();
            shape = Shapes.or(shape, Shapes.box(b.get(0).getAsInt() / 16.0, b.get(1).getAsInt() / 16.0,
                    b.get(2).getAsInt() / 16.0, b.get(3).getAsInt() / 16.0, b.get(4).getAsInt() / 16.0,
                    b.get(5).getAsInt() / 16.0));
        }
        return shape.optimize();
    }

    private static synchronized Map<String, JsonObject> load() {
        if (tables != null) {
            return tables;
        }
        Map<String, JsonObject> map = new HashMap<>();
        try (Reader reader = new InputStreamReader(
                PotShapes.class.getResourceAsStream("/assets/mikexxx_flowerbeds/pot_shapes.json"),
                StandardCharsets.UTF_8)) {
            for (Map.Entry<String, JsonElement> entry : JsonParser.parseReader(reader).getAsJsonObject().entrySet()) {
                map.put(entry.getKey(), entry.getValue().getAsJsonObject());
            }
        } catch (Exception e) {
            // No table: the pots keep the plain square hitbox.
        }
        tables = map;
        return map;
    }
}
