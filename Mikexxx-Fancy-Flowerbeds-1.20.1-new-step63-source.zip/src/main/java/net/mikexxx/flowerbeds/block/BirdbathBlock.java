package net.mikexxx.flowerbeds.block;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Silver Birdbath: a shallow water bowl on a pillar. Birdbaths next to each other join into one wide bowl, a
 * birdbath on top of another stacks on a thin pillar, and redstone makes the top bowl play a fountain.
 * It takes every liquid and every substrate like any other pot: water first, then a thin layer of substrate
 * on the bowl floor under the water. It has no light state, which keeps its block state count small.
 */
public class BirdbathBlock extends RoundPotBlock {

    public static final BooleanProperty UP = BlockStateProperties.UP;
    public static final BooleanProperty DOWN = BlockStateProperties.DOWN;
    public static final BooleanProperty POWERED = BlockStateProperties.POWERED;
    /** Round-bowl cell or foot holder of the group; replaces round3 so the state count stays small. */
    public static final EnumProperty<BathGroup> GROUP = EnumProperty.create("group", BathGroup.class);

    /** Groups wider than this (or with more blocks) just get a slim foot under every block. */
    private static final int MAX_SPAN = 9;
    private static final int MAX_BLOCKS = 81;
    /** Most birdbaths one redstone network reaches. */
    private static final int MAX_NETWORK = 1024;

    /** The bowl occupies the top three sixteenths; the pillar is under it. */
    private static final VoxelShape BOWL = Block.box(0, 13, 0, 16, 16, 16);

    public BirdbathBlock(BlockBehaviour.Properties properties) {
        super(properties, false, true);
        registerDefaultState(this.defaultBlockState()
                .setValue(UP, false).setValue(DOWN, false).setValue(POWERED, false)
                .setValue(GROUP, BathGroup.NONE));
    }

    @Override
    protected boolean hasRoundProperty() {
        return false;
    }

    @Override
    protected int refreshRadius() {
        return MAX_SPAN - 1;
    }

    /** Key into the water table: round cell, or the neighbour mask. */
    public static String waterKey(BlockState state) {
        BathGroup group = state.getValue(GROUP);
        if (group.isQuad()) {
            return "q:" + (group.quadIndex() % 4) + (group.quadIndex() / 4);
        }
        if (group.isPenta()) {
            return "p:" + (group.pentaIndex() % 5) + (group.pentaIndex() / 5);
        }
        Round3 round = round(state);
        return round != Round3.NONE ? "r:" + round.getSerializedName() : "m:" + maskOf(state);
    }

    /** Round-bowl cell of this state, for the code that draws the water. */
    public static Round3 round(BlockState state) {
        return state.getValue(GROUP).round();
    }

    @Override
    protected boolean hasFillProperties() {
        return false;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(UP, DOWN, POWERED, GROUP);
    }

    /** Water sits in the bowl, just under the rim. */
    @Override
    public float waterTop() {
        return 15.2F / 16.0F;
    }

    @Override
    public float fillBottom() {
        return 14.2F / 16.0F;
    }

    @Override
    protected BlockState finishState(LevelAccessor level, BlockPos pos, BlockState state) {
        return super.finishState(level, pos, state)
                .setValue(GROUP, groupOf(level, pos))
                .setValue(UP, level.getBlockState(pos.above()).is(this))
                .setValue(DOWN, level.getBlockState(pos.below()).is(this));
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        BlockState state = super.getStateForPlacement(context);
        return state == null ? null
                : state.setValue(POWERED, context.getLevel().hasNeighborSignal(context.getClickedPos()));
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState,
                                  LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (direction == Direction.UP) {
            return state.setValue(UP, neighborState.is(this));
        }
        if (direction == Direction.DOWN) {
            return state.setValue(DOWN, neighborState.is(this));
        }
        return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos,
                                boolean isMoving) {
        super.neighborChanged(state, level, pos, block, fromPos, isMoving);
        if (!level.isClientSide) {
            syncPower(level, pos);
        }
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);
        if (!level.isClientSide && !state.is(oldState.getBlock())) {
            syncPower(level, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        super.onRemove(state, level, pos, newState, isMoving);
        if (!level.isClientSide && !state.is(newState.getBlock())) {
            // The network may have fallen apart: every piece re-reads its own power.
            for (Direction direction : Direction.values()) {
                BlockPos next = pos.relative(direction);
                if (level.getBlockState(next).getBlock() instanceof BirdbathBlock) {
                    syncPower(level, next);
                }
            }
        }
    }

    /**
     * Redstone runs through the whole bath: birdbaths that touch each other (side by side or stacked) are one
     * network. If any block of it gets power, every block is powered and every fountain plays; when the last power
     * is gone, they all stop.
     */
    private static void syncPower(Level level, BlockPos start) {
        if (!(level.getBlockState(start).getBlock() instanceof BirdbathBlock)) {
            return;
        }
        Set<BlockPos> network = new HashSet<>();
        ArrayDeque<BlockPos> open = new ArrayDeque<>();
        network.add(start);
        open.add(start);
        boolean powered = false;
        while (!open.isEmpty()) {
            BlockPos current = open.poll();
            powered |= level.hasNeighborSignal(current);
            for (Direction direction : Direction.values()) {
                BlockPos next = current.relative(direction);
                if (network.size() < MAX_NETWORK && !network.contains(next)
                        && level.getBlockState(next).getBlock() instanceof BirdbathBlock) {
                    network.add(next);
                    open.add(next);
                }
            }
        }
        for (BlockPos p : network) {
            BlockState current = level.getBlockState(p);
            if (current.getValue(POWERED) != powered) {
                level.setBlock(p, current.setValue(POWERED, powered), Block.UPDATE_CLIENTS);
            }
        }
    }

    /** Foot footprints {x0, z0, x1, z1} in sixteenths per group (as drawn by the foot models), then stacked. */
    private static VoxelShape footShape(BathGroup group, boolean stacked) {
        double[] f;
        switch (group) {
            case THIN -> f = stacked ? new double[] {6.5, 6.5, 9.5, 9.5} : new double[] {4, 4, 12, 12};
            case M_OO -> f = stacked ? new double[] {6, 6, 10, 10} : new double[] {2, 2, 14, 14};
            case M_EO -> f = stacked ? new double[] {14, 6, 18, 10} : new double[] {10, 2, 22, 14};
            case M_OE -> f = stacked ? new double[] {6, 14, 10, 18} : new double[] {2, 10, 14, 22};
            case M_EE -> f = stacked ? new double[] {14, 14, 18, 18} : new double[] {10, 10, 22, 22};
            case L_OO, C, P_22 -> f = stacked ? new double[] {5.5, 5.5, 10.5, 10.5} : new double[] {0, 0, 16, 16};
            case L_EO -> f = stacked ? new double[] {13.5, 5.5, 18.5, 10.5} : new double[] {8, 0, 24, 16};
            case L_OE -> f = stacked ? new double[] {5.5, 13.5, 10.5, 18.5} : new double[] {0, 8, 16, 24};
            case L_EE, Q_11 -> f = stacked ? new double[] {13.5, 13.5, 18.5, 18.5} : new double[] {8, 8, 24, 24};
            default -> {
                return Shapes.empty();
            }
        }
        double x0 = Math.max(0, f[0]);
        double z0 = Math.max(0, f[1]);
        double x1 = Math.min(16, f[2]);
        double z1 = Math.min(16, f[3]);
        return x0 < x1 && z0 < z1 ? Block.box(x0, 0, z0, x1, 13, z1) : Shapes.empty();
    }

    /**
     * The bowl is always the full block, so a big or round bath is easy to fill. A pillar is only there where the
     * block really has a foot, and it is as wide as that foot.
     */
    @Override
    protected VoxelShape baseShape(BlockState state) {
        return Shapes.or(footShape(state.getValue(GROUP), state.getValue(DOWN)), BOWL);
    }

    @Override
    public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return baseShape(state);
    }

    /**
     * Flood fills the group of joined birdbaths. A finished 3x3, 4x4 or 5x5 is the round bath. A single row or any
     * shape that is not a filled rectangle (an L of any direction and size) keeps a slim foot under every block.
     * A filled rectangle has one shared foot at the block nearest the middle; it gets thicker as the group widens.
     */
    private BathGroup groupOf(LevelAccessor level, BlockPos pos) {
        Set<BlockPos> group = new HashSet<>();
        ArrayDeque<BlockPos> open = new ArrayDeque<>();
        group.add(pos);
        open.add(pos);
        while (!open.isEmpty()) {
            BlockPos current = open.poll();
            for (BlockPos next : new BlockPos[] {current.north(), current.east(), current.south(), current.west()}) {
                if (!group.contains(next) && connects(level.getBlockState(next))) {
                    group.add(next);
                    if (group.size() > MAX_BLOCKS) {
                        return BathGroup.THIN;
                    }
                    open.add(next);
                }
            }
        }
        int minX = Integer.MAX_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxZ = Integer.MIN_VALUE;
        for (BlockPos p : group) {
            minX = Math.min(minX, p.getX());
            maxX = Math.max(maxX, p.getX());
            minZ = Math.min(minZ, p.getZ());
            maxZ = Math.max(maxZ, p.getZ());
        }
        int w = maxX - minX + 1;
        int d = maxZ - minZ + 1;
        if (w > MAX_SPAN || d > MAX_SPAN) {
            return BathGroup.THIN;
        }
        if (w == 1 || d == 1) {
            // A single row: every birdbath keeps its own small normal foot, no shared foot.
            return BathGroup.THIN;
        }
        if (group.size() != w * d) {
            // An L, a T, a plus or any other shape that is not a filled rectangle: the middle of it may be empty
            // air, so no single foot would make sense. Every block keeps its own slim foot, like a row does.
            return BathGroup.THIN;
        }
        if (w == 5 && d == 5 && group.size() == 25) {
            return BathGroup.ofPenta(pos.getX() - minX, pos.getZ() - minZ);
        }
        if (w == 4 && d == 4 && group.size() == 16) {
            return BathGroup.ofQuad(pos.getX() - minX, pos.getZ() - minZ);
        }
        if (w == 3 && d == 3 && group.size() == 9) {
            return BathGroup.ofRound(Round3.at(pos.getX() - minX, pos.getZ() - minZ));
        }
        int size = group.size() == 1 ? 0 : Math.max(w, d) >= 4 ? 2 : 1;
        // The middle of the group in half blocks; the foot block is the nearest one, west/north first.
        int mx = minX + maxX;
        int mz = minZ + maxZ;
        BlockPos holder = null;
        long best = Long.MAX_VALUE;
        for (BlockPos p : group) {
            long dx = 2L * p.getX() - mx;
            long dz = 2L * p.getZ() - mz;
            long dist = dx * dx + dz * dz;
            if (dist < best || dist == best && (p.getX() < holder.getX()
                    || p.getX() == holder.getX() && p.getZ() < holder.getZ())) {
                best = dist;
                holder = p;
            }
        }
        if (!pos.equals(holder)) {
            return BathGroup.NONE;
        }
        // On the seam of an even group the foot sits half a block east / south of the holder's middle. If the
        // group has a hole there, the foot just stands in the middle of the holder.
        boolean evenX = w % 2 == 0 && holder.getX() == minX + (w - 1) / 2;
        boolean evenZ = d % 2 == 0 && holder.getZ() == minZ + (d - 1) / 2;
        return BathGroup.foot(size, evenX, evenZ);
    }
}
