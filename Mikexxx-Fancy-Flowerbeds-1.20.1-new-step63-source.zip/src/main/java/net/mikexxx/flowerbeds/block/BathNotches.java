package net.mikexxx.flowerbeds.block;

import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/**
 * Where the rim of a birdbath bowl has its notches (the indents water runs out of when the bath is powered).
 * Mirrors tools/notch_models.py. Each spot is {x, z, outX, outZ}: position in blocks inside the block and the
 * outward direction.
 */
public final class BathNotches {
    private BathNotches() {
    }

    public static List<float[]> spots(BlockState st) {
        List<float[]> out = new ArrayList<>();
        BathGroup group = st.getValue(BirdbathBlock.GROUP);
        if (group.isQuad()) {
            ring(out, group.quadIndex() % 4, group.quadIndex() / 4, 32.0F, 31.2F, 15.0F, 30.0F, 12);
            return out;
        }
        if (group.isPenta()) {
            ring(out, group.pentaIndex() % 5, group.pentaIndex() / 5, 40.0F, 39.2F, 11.25F, 22.5F, 16);
            return out;
        }
        Round3 round = BirdbathBlock.round(st);
        if (round != Round3.NONE) {
            if (round != Round3.C) {
                int i = switch (round) {
                    case NW, W, SW -> 0;
                    case N, C, S -> 1;
                    default -> 2;
                };
                int j = switch (round) {
                    case NW, N, NE -> 0;
                    case W, C, E -> 1;
                    default -> 2;
                };
                ring(out, i, j, 24.0F, 23.2F, 0.0F, 45.0F, 8);
            }
            return out;
        }
        if (!st.getValue(LargePotBlock.NORTH)) out.add(new float[] {0.5F, 0.03F, 0, -1});
        if (!st.getValue(LargePotBlock.SOUTH)) out.add(new float[] {0.5F, 0.97F, 0, 1});
        if (!st.getValue(LargePotBlock.WEST)) out.add(new float[] {0.03F, 0.5F, -1, 0});
        if (!st.getValue(LargePotBlock.EAST)) out.add(new float[] {0.97F, 0.5F, 1, 0});
        return out;
    }

    private static void ring(List<float[]> out, int i, int j, float c, float r, float start, float step, int count) {
        for (int k = 0; k < count; k++) {
            double a = Math.toRadians(start + k * step);
            float x = (float) (c + r * Math.cos(a)) - 16 * i;
            float z = (float) (c + r * Math.sin(a)) - 16 * j;
            if (x >= 0.5F && x < 15.5F && z >= 0.5F && z < 15.5F) {
                out.add(new float[] {x / 16.0F, z / 16.0F, (float) Math.cos(a), (float) Math.sin(a)});
            }
        }
    }
}
