package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.client.particle.FountainSpray;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The spray of a powered birdbath that has no birdbath on top: coloured drops shot up from the spout in the
 * middle of its group, with vanilla splashes at the spout. Water is dark blue, dyed water has its dye colour,
 * aromatized water its pink or violet, lava glows orange and milk is white.
 */
public final class FountainEffects {
    private static final double RANGE = 32.0;
    /** Where the spray leaves the spout, in blocks above the block (just over the water line). */
    private static final double NOZZLE_TOP = 15.2 / 16.0;

    private FountainEffects() {
    }

    /** The colour (0xRRGGBB) of the spray for what is in this bowl. */
    public static int colorOf(LargePotBlockEntity pot) {
        LargePotBlockEntity source = pot.liquidSource();
        switch (pot.effectiveLiquid()) {
            case LAVA:
                return 0xFF6A12;
            case MILK:
                return 0xF6F3EC;
            default:
                int dye = source.getDyeColor();
                if (dye < 0) {
                    return 0x2B58D8;
                }
                if (source.isAromatic()) {
                    // A little lighter, so the pink and the violet sparkle.
                    int r = Math.min(255, (dye >> 16 & 255) + 30);
                    int g = Math.min(255, (dye >> 8 & 255) + 30);
                    int b = Math.min(255, (dye & 255) + 30);
                    return r << 16 | g << 8 | b;
                }
                return dye;
        }
    }

    public static void clientTick(Level level, BlockPos pos, BlockState state, LargePotBlockEntity pot) {
        if (!(state.getBlock() instanceof BirdbathBlock) || !state.getValue(BirdbathBlock.POWERED)
                || state.getValue(BirdbathBlock.UP) || !state.getValue(BirdbathBlock.GROUP).holdsFoot()
                || pot.effectiveLiquid() == LargePotBlock.Liquid.NONE) {
            return;
        }
        if (level.getNearestPlayer(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, RANGE, false) == null) {
            return;
        }
        BathGroup group = state.getValue(BirdbathBlock.GROUP);
        double x = pos.getX() + (group.evenX() ? 1.0 : 0.5);
        double z = pos.getZ() + (group.evenZ() ? 1.0 : 0.5);
        double y = pos.getY() + NOZZLE_TOP;
        RandomSource random = level.random;
        int rgb = colorOf(pot);
        boolean lava = pot.effectiveLiquid() == LargePotBlock.Liquid.LAVA;
        int count = 2 + random.nextInt(2);
        for (int i = 0; i < count; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double spread = 0.012 + random.nextDouble() * 0.022;
            FountainSpray.drop(x, y, z, Math.cos(angle) * spread, 0.25 + random.nextDouble() * 0.03,
                    Math.sin(angle) * spread, rgb, lava);
        }
        // The vanilla splash at the spout, in the same colour.
        if (random.nextInt(2) == 0) {
            FountainSpray.tinted(ParticleTypes.SPLASH, x + (random.nextDouble() - 0.5) * 0.1, y,
                    z + (random.nextDouble() - 0.5) * 0.1, (random.nextDouble() - 0.5) * 0.06,
                    0.04 + random.nextDouble() * 0.04, (random.nextDouble() - 0.5) * 0.06, rgb);
        }
        if (lava && random.nextInt(6) == 0) {
            FountainSpray.tinted(ParticleTypes.LAVA, x, y, z, 0.0, 0.0, 0.0, 0xFFFFFF);
        }
    }
}
