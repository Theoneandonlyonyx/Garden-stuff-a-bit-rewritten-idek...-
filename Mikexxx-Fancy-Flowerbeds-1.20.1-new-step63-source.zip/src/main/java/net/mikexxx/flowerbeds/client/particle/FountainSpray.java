package net.mikexxx.flowerbeds.client.particle;

import net.mikexxx.flowerbeds.registry.ModParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.core.particles.ParticleOptions;

/** Client side: spawns one coloured fountain particle (a drop, or a vanilla splash / lava spark). */
public final class FountainSpray {
    private FountainSpray() {
    }

    /** A drop of the fountain in this colour (0xRRGGBB). Lava drops glow and do not splash. */
    public static void drop(double x, double y, double z, double vx, double vy, double vz, int rgb, boolean lava) {
        Particle p = Minecraft.getInstance().particleEngine.createParticle(ModParticles.FOUNTAIN_DROP.get(),
                x, y, z, vx, vy, vz);
        if (p instanceof FountainParticle drop) {
            drop.setColor((rgb >> 16 & 255) / 255.0F, (rgb >> 8 & 255) / 255.0F, (rgb & 255) / 255.0F);
            drop.setLiquid(lava, !lava);
            Minecraft.getInstance().particleEngine.add(drop);
        }
    }

    /** Any vanilla particle, tinted. */
    public static void tinted(ParticleOptions options, double x, double y, double z, double vx, double vy, double vz,
                              int rgb) {
        Particle p = Minecraft.getInstance().particleEngine.createParticle(options, x, y, z, vx, vy, vz);
        if (p != null) {
            p.setColor((rgb >> 16 & 255) / 255.0F, (rgb >> 8 & 255) / 255.0F, (rgb & 255) / 255.0F);
            Minecraft.getInstance().particleEngine.add(p);
        }
    }
}
