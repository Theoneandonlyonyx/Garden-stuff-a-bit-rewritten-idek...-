package net.mikexxx.flowerbeds.client.particle;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;

/**
 * A round drop of fountain liquid: shot up, falls in an arc and, when it is back at the height it started, bursts
 * into the vanilla splash in the same colour. The colour is set by the fountain from the liquid (water, dyed
 * water, aromatized water, lava, milk), the sprite is grey so that it takes any colour.
 */
public class FountainParticle extends TextureSheetParticle {
    private final double startY;
    private boolean glow;
    private boolean splashes = true;

    private FountainParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz,
                             SpriteSet sprites) {
        super(level, x, y, z, vx, vy, vz);
        this.startY = y;
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.hasPhysics = false;
        this.lifetime = 44;
        this.quadSize = 0.05F + random.nextFloat() * 0.04F;
        setColor(0.17F, 0.36F, 0.86F);
        setAlpha(0.92F);
        pickSprite(sprites);
    }

    /** Lava drops glow and do not splash like water. */
    public void setLiquid(boolean glowing, boolean splash) {
        this.glow = glowing;
        this.splashes = splash;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        if (this.yd < 0 && this.y <= this.startY - 0.02) {
            if (splashes) {
                Particle splash = Minecraft.getInstance().particleEngine.createParticle(ParticleTypes.SPLASH,
                        this.x, this.startY, this.z, 0.0, 0.0, 0.0);
                if (splash != null) {
                    splash.setColor(this.rCol, this.gCol, this.bCol);
                    Minecraft.getInstance().particleEngine.add(splash);
                }
            }
            this.remove();
            return;
        }
        this.yd -= 0.04;
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.99;
        this.zd *= 0.99;
    }

    @Override
    protected int getLightColor(float partialTick) {
        if (glow) {
            return 0xF000F0;
        }
        int base = super.getLightColor(partialTick);
        return (base & 0xFFFF0000) | Math.max(base & 0xFFFF, 0xA0);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z,
                                       double vx, double vy, double vz) {
            return new FountainParticle(level, x, y, z, vx, vy, vz, sprites);
        }
    }
}
