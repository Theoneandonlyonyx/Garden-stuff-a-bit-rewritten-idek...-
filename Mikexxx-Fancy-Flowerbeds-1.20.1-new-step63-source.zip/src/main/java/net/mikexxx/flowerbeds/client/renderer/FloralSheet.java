package net.mikexxx.flowerbeds.client.renderer;

import net.minecraft.resources.ResourceLocation;

/**
 * The floating petals and the waterlily parts live in one small sheet that is NOT part of the block atlas, so
 * the game never mip-maps it: small petals stay crisp and have no pale square around them. 16 px cells, 8 per row.
 */
public final class FloralSheet {
    public static final ResourceLocation TEXTURE =
            new ResourceLocation("mikexxx_flowerbeds", "textures/misc/floral_sheet.png");

    private static final String[] NAMES = {
            "aroma_petal_0", "aroma_petal_1", "aroma_petal_2", "aroma_violet_0", "aroma_violet_1", "aroma_violet_2",
            "lily_petal_cream", "lily_petal_lilac", "lily_petal_pink", "lily_petal_white",
            "lily_bud_cream", "lily_bud_lilac", "lily_bud_pink", "lily_bud_white",
            "lily_sepal", "lily_stamen", "lily_pad_0", "lily_pad_1", "lily_pad_2"};

    /** The texture coordinates of one cell. */
    public record Tex(float u0, float u1, float v0, float v1) {
        public float getU0() {
            return u0;
        }

        public float getU1() {
            return u1;
        }

        public float getV0() {
            return v0;
        }

        public float getV1() {
            return v1;
        }
    }

    private static final Tex[] CELLS = new Tex[NAMES.length];

    static {
        for (int i = 0; i < NAMES.length; i++) {
            float u = (i % 8) * 16 / 128.0F;
            float v = (i / 8) * 16 / 128.0F;
            CELLS[i] = new Tex(u, u + 16 / 128.0F, v, v + 16 / 128.0F);
        }
    }

    private FloralSheet() {
    }

    private static final java.util.Map<ResourceLocation, Tex> BY_LOCATION = new java.util.concurrent.ConcurrentHashMap<>();

    /** Looks a sprite up by its old atlas name, for example "block/lily_pad_1". Remembered, so no per-frame work. */
    public static Tex lookup(ResourceLocation location) {
        return BY_LOCATION.computeIfAbsent(location, FloralSheet::find);
    }

    private static Tex find(ResourceLocation location) {
        String path = location.getPath();
        String name = path.substring(path.lastIndexOf('/') + 1);
        for (int i = 0; i < NAMES.length; i++) {
            if (NAMES[i].equals(name)) {
                return CELLS[i];
            }
        }
        return CELLS[0];
    }
}
