# Mikexxx Fancy Flowerbeds

Forge 1.20.1 (47.3.0), Java 17, official mappings.

## Build

    ./gradlew build          (jar: build/libs/Mikexxx-Fancy-Flowerbeds-<version>.jar)
    ./gradlew runClient

`build.gradle`, `settings.gradle` and `gradle.properties` are in the project root. The Gradle wrapper
(`gradlew`, `gradle/wrapper/`) is not part of this zip: copy it from your project, or run `gradle wrapper`.

## What is in it

- Large pots (coloured, terracotta, quartz, calcite, glass), Blue-White China Pot, Quartz Amphora Pot,
  Silver Birdbath, window boxes, soil block, garden trowel.
- Fine China block (2x2: 2 quartz + 2 lapis -> 3); the china pot is made from it.
- Pots join to their neighbours (never diagonally); a 3x3 of china pots or amphoras turns round,
  a 3x3, 4x4 or 5x5 of birdbaths turns into one round bowl.
- Birdbaths: one powered bath powers every connected bath, water fountains (bigger on bigger baths),
  notches and water sheets on stacked baths, water lilies.
- Aromatized water with bathbombs (Sakura, Violet) and its particles.
- Substrate and liquid follow the inside shape of amphoras, china pots and birdbaths.
- Optional link to Ornamental Trees (trees can stand in pots and beds).

## Tools

`tools/` holds the Python scripts that generated models and textures (china bake, pot hitboxes, bathbombs, viola designs, notch models,
lily and cherry flower textures). They are only needed to regenerate those files.
