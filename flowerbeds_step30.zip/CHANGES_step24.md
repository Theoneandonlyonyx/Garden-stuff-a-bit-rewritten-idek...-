# Step 24 (on step 23)
- Ornamental Trees support (mikexxx_ornamental_trees, optional - nothing breaks without it):
  - the five trees (cherry, magnolia, hydrangea, lemon, orange) can be planted in soil, beds and pots like any plant (item tag `extra_placeable`, entries are optional),
  - they are drawn small ("bonsai", 0.15 block per tree block) as two crossed planes using the trees mod's own textures, so they look like the real ones.
  - the trees mod is declared as an optional AFTER-dependency in mods.toml.
- Scale is `OrnamentalTrees.POT_SCALE` if you want them bigger or smaller.
