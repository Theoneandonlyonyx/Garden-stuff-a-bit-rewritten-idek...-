# Step 22 (on step 21)
- Added the Blue-White China Pot, the Quartz Amphora Pot (replaces the old quartz pot look) and the Silver Birdbath, with your models/textures from Pots-And-Birdbath-v2.
- China pot turns round only when its connected group is exactly a 3x3. Quartz never turns round (square corners kept).
- Birdbath: water only, holds water in its bowl (water drawn as one sheet that follows the rounded rim), stacks on pillars (up/down), redstone sets `powered` (jet model from your pack).
- Birdbath and pots have no extra light/soil states for the birdbath, to keep the state count at ~20k.
- Recipes: china pot (white terracotta + blue dye), birdbath (smooth stone + iron ingot).
