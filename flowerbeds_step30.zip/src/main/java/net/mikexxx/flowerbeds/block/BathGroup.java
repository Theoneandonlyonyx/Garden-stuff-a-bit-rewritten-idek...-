package net.mikexxx.flowerbeds.block;

import net.minecraft.util.StringRepresentable;

/**
 * What a birdbath is inside its group of joined birdbaths.
 * NONE: part of a group but not holding the foot. NW..SE: part of a finished 3x3 round bath (C also holds the foot).
 * THIN: a lone birdbath on a slim foot. M_xy / L_xy: the block that holds the one shared foot of a bigger group;
 * M is medium (2 or 3 wide), L is large (4 or more); x/y tell whether the group is odd (O) or even (E) wide in x / z,
 * because an even group has its foot on the seam between two blocks, so the foot is drawn half a block over.
 */
public enum BathGroup implements StringRepresentable {
    NONE("none"), NW("nw"), N("n"), NE("ne"), W("w"), C("c"), E("e"), SW("sw"), S("s"), SE("se"),
    THIN("thin"),
    M_OO("m_oo"), M_EO("m_eo"), M_OE("m_oe"), M_EE("m_ee"),
    L_OO("l_oo"), L_EO("l_eo"), L_OE("l_oe"), L_EE("l_ee");

    private final String name;

    BathGroup(String name) {
        this.name = name;
    }

    @Override
    public String getSerializedName() {
        return name;
    }

    /** The round-bowl position this stands for (NONE unless it is one of the 3x3 cells). */
    public Round3 round() {
        return ordinal() <= SE.ordinal() && this != NONE ? Round3.valueOf(name()) : Round3.NONE;
    }

    public static BathGroup ofRound(Round3 round) {
        return round == Round3.NONE ? NONE : valueOf(round.name());
    }

    /** True for the block that carries the shared foot (and so the fountain nozzle). */
    public boolean holdsFoot() {
        return this == THIN || this == C || ordinal() >= M_OO.ordinal();
    }

    /** The foot sits half a block east of this block's middle (an even-wide group). */
    public boolean evenX() {
        return ordinal() >= M_OO.ordinal() && ((ordinal() - M_OO.ordinal()) & 1) != 0;
    }

    /** The foot sits half a block south of this block's middle (an even-deep group). */
    public boolean evenZ() {
        return ordinal() >= M_OO.ordinal() && (((ordinal() - M_OO.ordinal()) >> 1) & 1) != 0;
    }

    /** size: 0 = lone, 1 = medium, 2 = large. */
    public static BathGroup foot(int size, boolean evenX, boolean evenZ) {
        if (size == 0) {
            return THIN;
        }
        int i = (evenX ? 1 : 0) + (evenZ ? 2 : 0);
        return values()[(size == 1 ? M_OO : L_OO).ordinal() + i];
    }
}
