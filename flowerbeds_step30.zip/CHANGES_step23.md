# Step 23 (on step 22)
- Aromatized water: right-click a pot or birdbath holding PINK-dyed water with pink petals. The water now keeps giving off, 24/7:
  - rosy-pink sparkles that shrink away (like the green happy-villager sparkle),
  - lighter, paler pink bubbles,
  - sakura petals of different sizes.
- Pots: spread evenly over the water. Birdbaths: favoured toward the open rim (sides not joined to another bath).
- Re-dyeing with another colour, or emptying the water, ends it. Saved with the block and synced to the client.
- Pink petals are only used up if the water is pink and not yet aromatic; otherwise they can be planted as before.
