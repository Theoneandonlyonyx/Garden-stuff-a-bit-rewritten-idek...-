# Step 25 (on step 24)
- Glass pots rebuilt so the glass connects with no double lines:
  - no model draws a face that touches another model (wall/post seams, floor/wall, pot/pot, stacked tank joints), so nothing overlaps or z-fights;
  - the vanilla glass border texture (the cause of the doubled lines at every seam) is replaced by three borderless textures: clear glass with a few shine pixels, a pale rim for the top edge and floor edge, a slightly stronger tint for corner posts;
  - posts and walls are chosen per open/closed side, so L-shapes, 2x2, big beds and stacked tanks show only the outer silhouette.
- Pots are solid blocks that no fluid can replace, and nothing in the mod reacts to water, so water never washes a pot away (unlike torches).
